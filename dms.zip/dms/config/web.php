<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'defaultRoute'=>'c_index',
    'bootstrap' => ['log'],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'rwVdxAxXLVoMNzwKd9jr0wDsyhABzLbr',
            'enableCsrfValidation'=>false,
        ],
        'cache' => [
            // 'class' => 'yii\caching\FileCache',
            'class' => 'yii\caching\MemCache',
            'servers' => [
                [
                    'host' => '121.42.248.249',
                    'port' => 11211,
                    'weight' => 100,
                ]
            ],
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
            'transport' => [  
               'class' => 'Swift_SmtpTransport',  
               'host' => 'smtp.ym.163.com',  //每种邮箱的host配置不一样
               'username' => 'join@dsjyw.net',  
               'password' => 'hellojoin',  
               'port' => '25',  
               'encryption' => 'tls',  
                                   
                           ],   
           'messageConfig'=>[  
               'charset'=>'UTF-8',  
               'from'=>['join@dsjyw.net'=>'东北师范大学学生就业指导服务中心']  
               ],
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
        'db2'=>[
                'class' => 'yii\db\Connection',
                'dsn' => 'mysql:host=60.205.189.30;dbname=test',
                'username' => 'root',
                'password' => '159753',
                'charset' => 'utf8',
            ],
        
        // 'urlManager' => [
        //     'enablePrettyUrl' => true,
        //     'showScriptName' => false,
        //     'rules' => [
        //         '<controller:\w+>/<id:\d+>'=>'<controller>/view',
        //         '<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
        //         '<controller:\w+>/<action:\w+>'=>'<controller>/<action>'
        //     ],
        // ],
        
        'urlManager' => [
            'enablePrettyUrl' => true, 
            'enableStrictParsing' => false,
            'showScriptName' => false,
            'rules' => [
                // '<module:\w+>/<controller:\w+>/<id:\d+>' => '<module>/<controller>/view',
                '<controller:\w+>/<id:\d+>' => '<controller>/view',
            ],
        ],
        
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
