<!DOCTYPE html>
<html lang="en">
  <head> 
    <title>典牧署</title>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="screen-orientation" content="portrait">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="x5-orientation" content="portrait">
    <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
    <link rel="stylesheet" href="/assets/c/css/passport.css">
  </head>
  <body>
    <div class="header"><a href="#"><img src="/assets/c/images/passport/passport-logo.png" alt="典牧署"></a></div>
    <div class="main-bg">
      <div class="main"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
        <p class="intro">
          城市丛林太无趣，肉类吃得不放心？典牧署帮你养殖健康肉
          
        </p>
        <div class="login-modal">
          <div class="reg" style="display: block;">
            <p class="step">修改密码 Step.2</p>
            <form action="<?php echo Yii::$app->request->hostInfo.'/c_pass/change' ?>" method="post">
              <div class="phone-box">
                <input type="number" name="phone" value="<?php echo $phone ?>" disabled="true" placeholder="手机号" class="phone"><span class="tip"></span>
              </div>
              <div class="password-box">
                <input type="password" name="password" placeholder="设置新密码" class="password"><span class="tip"></span>
              </div>
              <input type="submit" value="确认修改" class="submit">
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
    <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
    <script src="http://cdn.bootcss.com/jquery.form/3.51/jquery.form.min.js"></script>
    <script src="/assets/c/js/edit-common.js"></script>
    <script src="/assets/c/js/edit_pass_two.js"></script>
    <script type="text/javascript">
      $(function(){
         var form = $("form");
         form.submit(function(){
            $('.phone').removeAttr('disabled');
         })
      })
    </script>
  </body>
</html>