<!DOCTYPE html>
<html lang="en">
  <head> 
    <title>典牧署</title>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="screen-orientation" content="portrait">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="x5-orientation" content="portrait">
    <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
    <link rel="stylesheet" href="/assets/c/css/passport.css">
  </head>
  <body>
    <div class="header"><a href="#"><img src="/assets/c/images/passport/passport-logo.png" alt="典牧署"></a></div>
    <div class="main-bg">
      <div class="main"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
        <p class="intro">
          城市丛林太无趣，肉类吃得不放心？典牧署帮你养殖健康肉
          
        </p>
        <div class="login-modal">
          <div style="display: block;" class="reg edit-pass-one">
            <p class="step">修改密码 Step.1</p>
            <form method="post" action="<?php echo Yii::$app->request->hostInfo.'/c_pass/tochange' ?>">
              <div class="phone-box">
                <input type="number" name="phone" placeholder="手机号" class="phone"><span class="tip"></span>
              </div>
              <!-- 短信验证码-->
              <div class="smscode-box">
                <input type="text" name="code" placeholder="短信验证码" class="smscode"><a href="javascript:;" class="sendcode">发送验证码</a>
                <?php if (isset($check_fail)): ?>
                  <span class="tip error" style="visibility: visible; left: 410px;">验证码错误</span>
                <?php endif ?>
              </div>
              <input type="submit" value="下一步" class="submit">
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
    <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
    <script src="http://cdn.bootcss.com/jquery.form/3.51/jquery.form.min.js"></script>
    <script src="/assets/c/js/edit-common.js"></script>
    <script src="/assets/c/js/edit-pass.js"></script>
    <!-- <script src="/assets/c/js/validator.js"></script> -->
  </body>
</html>