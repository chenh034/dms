  <link rel="stylesheet" href="/assets/c/css/share_pig.css">
  <link rel="stylesheet" href="/assets/c/css/person_center.css">
  <div class="main">
    <div class="pig-package"><img src="<?php echo 'http://'.$product['img_url'] ?>" alt="">
      <p class="number">猪种编号<span><?php echo $product['name'] ?></span></p>
      <p class="detail">养殖详情
        <span>
           &nbsp;品种：<?php echo $product['species'] ?>; 
           &nbsp;身份证：<?php echo $product['name'] ?>; 
           &nbsp;养殖时间：<?php echo $product['start_time'] ?> 至 <?php echo $product['end_time'] ?>; 
           &nbsp;选择饲料：<?php echo $product['forage'] ?>;  
        </span>
      </p>
      <p class="money" style="color: red;">消息提醒 <span style="color: red;"><?php echo $product['message'] ?>  </span></p>
    </div>
    <div class="pay">   
      <a href="confirm?id=<?php echo $product['mid'] ?>" class="save confirm-pay">确认消息</a>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
</body>