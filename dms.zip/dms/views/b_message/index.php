  <link rel="stylesheet" href="/assets/b/css/mess_center.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="main">
    <p class="top-title">消息中心</p>
    <!-- <ul class="nav">
      <li class="active">全部消息</li>
      <li>典牧署消息</li>
      <li>物流消息</li>
    </ul> -->
    <div class="mess mess-all">
      <ul id="list">
        <!-- <li> 
          <p class="mess-group">物流消息: <span>你的猪肉有新动态</span></p><img src="/assets/b/images/common/pig.png" alt="">
          <p class="title">三元猪</p>
          <p class="id">典牧署身份证: <span>JL0122016022202</span></p>
          <p class="date">
            养殖时间: 
            <span class="from">2016-06-22</span> 至 <span class="to">2017-05-22</span>
          </p>
          <div class="clear"></div>
          <div class="more">
            <p class="time">2016-05-22 13:12:01</p><a href="#" class="detail">查看详情</a>
          </div>
        </li> -->
        
      </ul>
      <div class="pagelist"></div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script>
    $(function(){

      query(1,10,function(total){
          $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
              query(page,size,total);
          }}); 
      });

      function query(page,size,callback){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size,
              dataType:"json",
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = '';
                $.each(data.data,function(index,item){
                  content+="<li> <p class='mess-group'><span>你的商品有新动态</span></p><img src=http://"+item.img_url+"><p class='title'>"+item.species+"</p><p class='id'>典牧署身份证: <span>"+item.name+"</span></p><p class='date'>"+item.content+"</p><div class='clear'></div><div class='more'><p class='time'>"+item.update_time+"</p><a href=detail?id="+item.id+" class='detail'>查看详情</a></div></li>";
                })
                $("#list").html(content);
                callback && callback(data.total);
              }
          })
      }
    })
    
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
  <script src="/assets/b/js/mess_center.js"></script>
</body>