  <link rel="stylesheet" href="/assets/b/css/pigs_add.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">所在位置：<a href="./pigs.html">库存幼崽</a><a href="./pigs_add.html">上架新幼崽</a></div>
      <div class="tab-main pigs-repo">
        <!-- 上架新幼崽-->
        <div class="newpigs-add">
          <?php if (Yii::$app->session->getFlash('status')): ?>
            <script type="text/javascript">
              alert('修改成功');
            </script>
          <?php endif ?>
          <form action="<?php echo Yii::$app->request->hostInfo;?>/b_product/edit?id=<?php echo $product['id']; ?>" name="pigs-edit" method="post" enctype="multipart/form-data">
            <!-- 上传照片-->
            <div class="imgupload">
              <span class="tip">点击图片上传头像<br>(保存后生效)</span>
              <img src="http://<?php echo $product['img_url']; ?>" alt="" class="photo">
              <input type="file" name="file" accept="image/*" class="file">
              <p class="size">图片尺寸: 800 * 600 以上</p>
            </div>
            <div class="basic-mess">               
              <div class="mess">
                <p>物种&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <select name="species_id">
                     <?php foreach ($species as $key => $value): ?>
                       <?php if ($value['id']==$product['species_id']): ?>
                          <option value="<?php echo $value['id']; ?>" selected="selected"><?php echo $value['name'] ;?></option>
                       <?php else: ?>
                          <option value="<?php echo $value['id']; ?>"><?php echo $value['name'] ;?></option>
                       <?php endif ?>
                     <?php endforeach ?>
                  </select>
                </p>
                <p class="number">编号&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <!-- <span>JL012</span> -->
                  <input type="text" name="name" value="<?php echo $product['name'] ;?>">
                </p>
                <p class="birthday">出生日期
                <input id="birth" type="text" name="birthday" placeholder="请选择出生日期" value="<?php echo $product['birthday'] ?>">
                </p>
                <p class="weight">当前体重
                  <input type="text" name="foundation_weight" class="num" value="<?php echo $product['foundation_weight'] ?>"><span>kg</span>
                </p>
                <p class="time">养殖时间
                <span>/天</span>
                <input class="num" type="number" name="feed_time" value="<?php echo $product['feed_time'] ?>">
              </p>
                <p class="output">预计出肉
                  <input type="text" name="pre_weight" class="num" value="<?php echo $product['pre_weight'] ?>"><span>kg</span>
                </p>
                <p>选择饲料
                  <select name="forage_id">
                     <?php foreach ($forage as $key => $value): ?>
                       <?php if ($value['id']==$product['forage_id']): ?>
                          <option value="<?php echo $value['id']; ?>" selected="selected"><?php echo $value['name'] ;?></option>
                       <?php else: ?>
                          <option value="<?php echo $value['id']; ?>"><?php echo $value['name'] ;?></option>
                       <?php endif ?>
                     <?php endforeach ?>
                  </select>
                </p>
                
              </div>
              <div class="desc">
                <p class="title">物种简介</p>
                <textarea name="introduce" rows="8" cols="40"><?php echo $product['introduce'] ?></textarea>
              </div>
              <div class="clear"></div>
              <hr class="gap">
            </div>
            <div class="clear"></div>
            <div class="adopt-way">养殖属性
              <label for="认养">
                <input type="text" name="type" value="adopt" style="display: none;">
                <span>认养</span>
              </label>
            </div>
            <div class="adopt">
              <!-- <p class="time">养殖时间
                <span>/天</span>
                <input class="num" type="number" name="feed_time">
              </p> -->
              <p>幼崽定价<span>¥ </span>
                <input type="text" name="foundation_price" class="num" value="<?php echo $product['foundation_price'] ?>">
              </p>
              <p class="costs">逾期费用<span>¥／天</span>
                <input type="text" name="feed_price" class="num" value="<?php echo $product['feed_price'] ?>">
              </p>
              <!-- <a href="<?php //echo Yii::$app->request->hostInfo.'/b_index/forage' ?>" class="food-price" target="_blank">设置饲料价格</a> -->
            </div>
            <input type="submit" value="确认提交" class="submit save">
            <div class="clear"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
  <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/pigs_add.js"></script>
  <!-- <script src="/assets/b/js/validator.js"></script> -->
</body>