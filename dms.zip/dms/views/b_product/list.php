  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
  .query_hint{
      display: none;
      border:5px solid #939393;
      width:250px;
      height:50px;
      line-height:55px;
      padding:0 20px;
      position:fixed;
      left:50%;
      margin-left:-140px;
      top:50%;
      margin-top:-40px;
      font-size:15px;
      color:#333;
      font-weight:bold;
      text-align:center;
      background-color:#f9f9f9;
  }
  .query_hint img{position:relative;top:10px;left:-8px;}
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs.html">库存幼崽</a>
         
      </div>
      <div class="tab-main pigs-repo"><a href="<?php echo Yii::$app->request->hostInfo;?>/b_product/toadd" class="pig-add">上新幼崽</a>
        <div class="clear"></div>
        <ul class="tabs">
          <li class="now"><a href="javascript:;" rel="1">审核通过</a></li>
          <li><a href="javascript:;" rel="0">待审核</a></li>
          <li><a href="javascript:;" rel="2">审核未通过</a></li>
        </ul>
        <form action="<?php echo Yii::$app->request->hostInfo.'/b_product/batchdel' ?>" method="post">
          <div class="pass-mess passed">
            <input type="submit" name="" class="pigs-del" value="批量下架">
            <div class="clear"></div>
            <table id="pigs-passed">
              <thead>
                <tr>
                  <th class="checkbox allChecked"> 
                    <label for="allchecked">
                      <input type="checkbox" name="allcheckd">
                      全选
                    </label>
                  </th>
                  <th class="img">图片</th>
                  <th class="kind">物种</th>
                  <th class="id">典牧署身份证</th>
                  <th class="weight">30天时体重</th>
                  <th class="price">价格</th>
                  <th class="output">预计出肉</th>
                  <th class="operate">操作</th>
                </tr>
              </thead>
              <tbody id="list">
                
              </tbody>
            </table>
            <div class="pagelist"></div>
          </div>
        </form>

      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
  <script src="/assets/b/js/index.js"></script>
  <script>
    $(function () {
      // var total;
      // var status = getUrlParam('status');
      var page = 1;
      var size = 10;
      var is_ok = $(".main .right .tabs a").first().attr('rel');
      setCookie('product_is_ok',is_ok);
      
      query(1,10,is_ok,function(total){
          $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('product_is_ok'));
          }});
      });
      // total = getCookie('total');

      $(".main .right .tabs a").on('click',function(){
          is_ok = $(this).attr('rel');
          setCookie('product_is_ok',is_ok);
          query(1,10,is_ok,function(total){
              $('.pagelist').html('');
              $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
                  query(page,size,getCookie('product_is_ok'));
              }});
          });
      }) 

      function query(page,size,is_ok,callback){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size+"&is_ok="+is_ok,
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = '';
                var op = '';
                $.each(data.data,function(index,item){
                  if (item.is_ok==0) {
                    op = "<a href='javascript:;'>下架</a><a href=toedit?id="+item.id+" class='edit'>修改 </a>";
                    $(".pigs-del").val("批量下架");
                  }else if(item.is_ok==1){
                    op = "<a href='javascript:;'>下架</a>";
                    $(".pigs-del").val("批量下架");
                  }else{
                    op = '';
                    $(".pigs-del").val("");
                  }
                  content+="<tr><td class='select'><input type='checkbox' name=select["+item.id+"]></td><td><img src=http://"
                  +item.img_url+"-small.70.50"
                  +"></td><td>"
                  +item.species.name
                  +"</td><td class='id'>"
                  +item.name
                  +"</td><td>"
                  +item.foundation_weight
                  +"kg</td><td>¥"
                  +item.foundation_price
                  +"</td><td>"
                  +item.pre_weight
                  +"kg</td><td>"+op+"</td></tr>"
                })
                
                $("#list").html(content);
                callback && callback(data.total);
              },
              error:function(data){
                 alert('请求超时');
                 $('#query_hint').css("display","none");
              }
          })
      }



    });
    
  </script>
</body>