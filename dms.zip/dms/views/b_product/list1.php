  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
  .query_hint{
      display: none;
      border:5px solid #939393;
      width:250px;
      height:50px;
      line-height:55px;
      padding:0 20px;
      position:fixed;
      left:50%;
      margin-left:-140px;
      top:50%;
      margin-top:-40px;
      font-size:15px;
      color:#333;
      font-weight:bold;
      text-align:center;
      background-color:#f9f9f9;
  }
  .query_hint img{position:relative;top:10px;left:-8px;}
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs.html">库存幼崽</a>
         
      </div>
      <div class="tab-main pigs-repo"><a href="<?php echo Yii::$app->request->hostInfo;?>/b_product/toadd" class="pig-add">上新幼崽</a>
        <div class="clear"></div>
        <ul class="tabs">
          <li><a href="list">审核通过</a></li>
          <li class="now"><a href="list1">待审核</a></li>
          <li><a href="list2">审核未通过</a></li>
        </ul>
        <div class="pass-mess passed"><a href="javascript;" class="pigs-del">批量下架</a>
          <div class="clear"></div>
          <table id="pigs-passed">
            <thead>
              <tr>
                <th class="checkbox allChecked"> 
                  <label for="allchecked">
                    <input type="checkbox" name="allcheckd">
                    全选
                  </label>
                </th>
                <th class="img">图片</th>
                <th class="kind">物种</th>
                <th class="id">典牧署身份证</th>
                <th class="weight">30天时体重</th>
                <th class="price">价格</th>
                <th class="output">预计出肉</th>
                <th class="operate">操作</th>
              </tr>
            </thead>
            <tbody id="list">
              
            </tbody>
          </table>
          <div class="pagelist"></div>
        </div>

      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
  <script src="/assets/b/js/index.js"></script>
  <script>
    $(function () {
      var total1;
      $.ajax({
          type:'post',
          url:"json?page=1&size=10&is_ok=0",
          success:function(data){
            var content = '';
            $.each(data.data,function(index,item){
              content+="<tr><td class='select'><input type='checkbox' name=select["+item.id+"]></td><td><img src=http://"
              +item.img_url+"-small.70.50"
              +"></td><td>"
              +item.species.name
              +"</td><td class='id'>"
              +item.name
              +"</td><td>"
              +item.foundation_weight
              +"kg</td><td>¥"
              +item.foundation_price
              +"</td><td>"
              +item.pre_weight
              +"kg</td><td><a href=del?id="+item.id+">下架</a><a href=toedit?id="+item.id+" class='edit'>修改 </a></td></tr>"
            })
            setCookie('total1',data.total1);
            $("#list").html(content);
          }
      })
      total1 = getCookie('total1')
      $('.pagelist').Paging({pagesize:10,count:total1,toolbar: true,callback:function(page,size,count){
            $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size+"&is_ok=0",
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
            
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = '';
                $.each(data.data,function(index,item){
                  content+="<tr><td class='select'><input type='checkbox' name='select'></td><td><img src=http://"
                  +item.img_url+"-small.70.50"
                  +"></td><td>"
                  +item.species.name
                  +"</td><td class='id'>"
                  +item.name
                  +"</td><td>"
                  +item.foundation_weight
                  +"kg</td><td>¥"
                  +item.foundation_price
                  +"</td><td>"
                  +item.pre_weight
                  +"kg</td><td><a href='javascript:;'>下架</a><a href='pigs_add.html' class='edit'>修改 </a></td></tr>"
                })
                $("#list").html(content);
              }
          })
      }}); 



    });
    
  </script>
</body>