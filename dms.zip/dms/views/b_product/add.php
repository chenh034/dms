  <link rel="stylesheet" href="/assets/b/css/pigs_add.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">所在位置：<a href="./pigs.html">库存幼崽</a><a href="./pigs_add.html">上架新幼崽</a></div>
      <div class="tab-main pigs-repo">
        <!-- 上架新幼崽-->
        <div class="newpigs-add">
          <?php if (Yii::$app->session->getFlash('status')): ?>
            <script type="text/javascript">
              alert('添加成功');
            </script>
          <?php endif ?>
          <form action="<?php echo Yii::$app->request->hostInfo;?>/b_product/add" name="pigs-edit" method="post" enctype="multipart/form-data">
            <!-- 上传照片-->
            <div class="imgupload">
              <span class="tip">点击图片上传头像<br>(保存后生效)</span>
              <img src="/assets/b/images/pig.png" alt="" class="photo">
              <input type="file" name="file" accept="image/*" class="file">
              <p class="size">图片尺寸: 800 * 600 以上</p>
            </div>
            <div class="basic-mess">               
              <div class="mess">
                <p>物种&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <select name="species_id">
                     <?php foreach ($species as $key => $value): ?>
                       <option value="<?php echo $value['id']; ?>"><?php echo $value['name'] ;?></option>
                     <?php endforeach ?>
                  </select>
                </p>
                <p class="number">编号&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <!-- <span>JL012</span> -->
                  <input type="text" name="name">
                </p>
                <p class="birthday">出生日期
	            	<input id="birth" type="text" name="birthday" placeholder="请选择出生日期">
                </p>
                <p class="weight">当前体重
                  <input type="text" name="foundation_weight" class="num"><span>kg</span>
                </p>
                <p class="time">养殖时间
	              <span>/天</span>
	              <input class="num" type="number" name="feed_time">
	            </p>
                <p class="output">预计出肉
                  <input type="text" name="pre_weight" class="num"><span>kg</span>
                </p>
                <p>选择饲料
                  <select name="forage_id">
                     <?php foreach ($forage as $key => $value): ?>
                       <option value="<?php echo $value['forage_id']; ?>"><?php echo $value['forage']['name'] ;?></option>
                     <?php endforeach ?>
                  </select>
                </p>
                
              </div>
              <div class="desc">
                <p class="title">物种简介</p>
                <textarea name="introduce" rows="8" cols="40"> </textarea>
              </div>
              <div class="clear"></div>
              <hr class="gap">
            </div>
            <div class="clear"></div>
            <div class="adopt-way">养殖属性
              <label for="认养">
                <input type="radio" name="type" checked="checked" value="adopt">
                <span>认养</span>
              </label>
              <label for="共筹">
                <input type="radio" name="type" value="raise">
                <span>共筹</span>
                
              </label>
            </div>
            <div class="adopt">
              <!-- <p class="time">养殖时间
              	<span>/天</span>
              	<input class="num" type="number" name="feed_time">
              </p> -->
              <p>幼崽定价<span>¥ </span>
                <input type="text" name="foundation_price" class="num">
              </p>
              <p class="costs">逾期费用<span>¥／天</span>
                <input type="text" name="feed_price" class="num">
              </p>
              <!-- <a href="<?php //echo Yii::$app->request->hostInfo.'/b_index/forage' ?>" class="food-price" target="_blank">设置饲料价格</a> -->
            </div>
            <div class="share">
              <div class="groups">
              	<p>套餐介绍</p>
              	<span class="tip">形如 猪蹄: 约4kg, 心脏: 约3kg</span>
              	<textarea class="group" name="setmeal_info"></textarea>
              </div>
              <!-- <div class="adopt-date">养殖时间
	            <input type="text" name="start_time" id="start" class="laydate-icon">
	            <input type="text" name="end_time" id="end" class="laydate-icon">
              </div> -->
              <div class="packages">
                <div class="package">
                  <p class="title">套餐<span>一</span></p>
                  <p class="set-price">设置总价<span>¥</span>
                    <input type="text" name="setmeal[1][price]" class="nonum">
                  </p>
                  <p class="content"><span>套餐内容</span>
                    <textarea name="setmeal[1][name]" rows="8" cols="40"></textarea>
                  </p><span class="tip">内容格式为：肉种*数量+单位，两类肉用分号隔开。如：前腿*1只；护心肉*1只</span><a href="javascript:;" class="delete">删除此套餐</a>
                </div>
                <div class="package">
                  <p class="title">套餐<span>二</span></p>
                  <p class="set-price">设置总价<span>¥</span>
                    <input type="text" name="setmeal[2][price]" class="nonum">
                  </p>
                  <p class="content"><span>套餐内容</span>
                    <textarea name="setmeal[2][name]" rows="8" cols="40"></textarea>
                  </p><span class="tip">内容格式为：肉种*数量+单位，两类肉用分号隔开。如：前腿*1只；护心肉*1只</span><a href="javascript:;" class="delete">删除此套餐</a>
                </div>
              </div>
              <li class="add-package">+ 添加套餐选项</li>
            </div>
            <input type="submit" value="确认提交" class="submit save">
            <div class="clear"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
  <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/pigs_add.js"></script>
  <script src="/assets/b/js/validator2.js"></script>
</body>