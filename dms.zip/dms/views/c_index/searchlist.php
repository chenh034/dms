  <link rel="stylesheet" href="/assets/c/css/share_pig_list.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="#">商品搜索</a></div>
  <div class="main">
    <div class="piglist">
      <ul id="list">
        
      </ul>
    </div>
    <div class="pagelist">
     
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/js/share_pig.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script type="text/javascript">
  $(function(){
      var page=1;
      var size=12;

      query(page,size,function(total){
          $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
              query(page,size);
          }});
      });
      

      function query(page,size,callback){
         var keyword = $(".search-input").val();
         $.ajax({
            type:'post',
            url:"searchjson?page="+page+"&size="+size+"&keyword="+keyword,
            dataType:'json',
            beforeSend:function() {  
             $('#query_hint').css("display","block");        
            },
            complete:function(){
               $('#query_hint').css("display","none");
            },
            success:function(data){
              var content = '';
              var op = '';
              var forage = '';
              $.each(data.data,function(index,item){
                if (item.type==2) {
                  op = "<p class='cur'>已共筹<span class='curnum'>"
                      +item.rate*100
                      +"<span>%</span></span></p><p class='time'> <span>7天0小时</span>后截止</p><div class='clear'></div><a href=../c_raise/detail?id="+item.id+" class='join'>我要共筹</a></li>";
                  forage = item.forage;
                }else if (item.type==1) {
                  op = "<p class='cur'>定价：¥"+item.foundation_price+"</p><div class='clear'></div><a href=../c_adopt/detail?id="+item.id+" class='join'>我要认养</a></li>";
                  forage = item.forage;
                }
                content+="<li><img src=http://"+item.img_url+" alt=''><p class='title'>"+item.species+"<span class='address'>("
                +item.farm_name
                +")</span></p><p>类型：<span>"+item.product_type+"</span></p><p class='birth'>出生日期: <span class='date'>"+item.birthday+"</span></p><p>饲料：<span>"+forage+"</span></p><p class='birth'>当前体重：<span class='num'>"
                +item.foundation_weight
                +"<span>kg</span></span></p><p class='weight'>养殖场地址：<span class='num'>"
                +item.farm_place
                +"</span></p>"
                +op;
              })
              $("#list").html(content);

              callback && callback(data.total);
            },
            error:function(data){
              $('#query_hint').css("display","none");
              alert('请求超时');
            }
          })
      }

  })
    
  </script>
</body>