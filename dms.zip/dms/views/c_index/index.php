  <link rel="stylesheet" href="/assets/c/css/index.css">
  <link rel="stylesheet" href="/assets/c/public/lib/lightbox/lightbox.min.css">
  <!-- 图片轮播展示部分-->
  <div class="banner">
    <div class="tab-btn"><span class="btn prev"> </span><span class="btn next"></span></div>
    <div class="tab-block"><span></span><span></span><span></span>
    </div>
    <ul class="fix">
      <?php foreach ($data['IndexImg'] as $key => $value): ?>
        <?php if ($value['target']): ?>
          <li><a href="<?php echo $value['target'] ?>"><img src="<?php echo 'http://'.$value['img_url'] ?>" alt=""></a></li>
        <?php else: ?>
          <li><a href="javascript:;"><img src="<?php echo 'http://'.$value['img_url'] ?>" alt=""></a></li>
        <?php endif ?>
      <?php endforeach ?>
    </ul>
  </div>
  <!-- 认养和共筹介绍和入口-->
  <div class="entry">
    <div class="adopt"><a href="<?php echo Yii::$app->request->hostInfo.'/c_adopt/specieslist';?>">去认养</a>
      <p>
        您可以自由选择牲畜品种、饲养期限以及饲料等，并且您将拥有其所有权。牲畜饲养到期后将由养殖者进行宰杀包装，并且将得到的肉类全部寄送给您。
        
      </p>
    </div>
    <p class="gap">- 或 -</p>
    <div class="share"><a href="<?php echo Yii::$app->request->hostInfo.'/c_raise/list';?>">去共筹</a>
      <p>
        您和其他用户共筹一牲畜，您将选择其中一部分，并且占有相应的所有权。共筹的用户无法更改养殖时间和饲料，牲畜饲养到期后将由养殖者进行宰杀，并且将得到的相应肉类寄送给您。
        
      </p>
    </div>
  </div>
  <!-- 共筹猪列表-->
  <!-- <div class="piglist"> -->
    <!-- <ul> -->
      <?php //foreach ($data['product'] as $key => $value): ?>
        <!-- <li><img src="<?php //echo 'http://'.$value['img_url'] ?>" alt="">
          <p class="title"><?php// echo $value['species'] ?><span class="address"><?php// echo $value['farm_place'] ?></span></p>
          <p class="birth">出生日期: <span class="date"><?php //echo $value['start_time'] ?></span></p>
          <p class="weight">30天体重：<span class="num"><?php// echo $value['foundation_weight'] ?><span>kg</span></span></p>
          <p class="cur">已共筹<span class="curnum"><?php// echo $value['rate']*10 ?><span>%</span></span></p>
          <p class="time"> <span>7天0小时</span>后截止</p>
          <div class="clear"></div><a href="#" class="join">我要共筹</a>
        </li> -->
      <?php //endforeach ?>
      
    <!-- </ul> -->
  <!-- </div> -->
  <!-- 目前养殖户数量和养殖数量-->
  <div class="curbusiness-num">
    <div class="business-num">
      <p class="business"><span class="num"><?php echo $data['farm_num'] ?></span><br><span>养殖户</span></p>
      <p class="pigs"><span class="num"><?php echo $data['product_num'] ?></span><br><span>养殖数量 </span></p>
    </div>
  </div>
  <!-- 养猪者说-->
  <div class="business-say">
    <h2>养殖者说</h2><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/commentlist' ?>" class="more">查看全部</a>
    <ul>
    <?php foreach ($data['Comment'] as $key => $value): ?>
      <li>
        <div class="evalution">
          <p class="quality"></p>
          <p class="fresh"></p>
          <p class="trans"></p>
          <p><?php echo $value['content'] ?></p>
          <div class="evalution-img">
          <?php if ($value['pic']!=null): ?>
            <?php foreach ($value['pic'] as $k => $v): ?>
              <a href="<?php echo 'http://'.$v ?>" data-lightbox="evalimg-1"><img src="<?php echo 'http://'.$v ?>" alt=""></a>
            <?php endforeach ?>
          <?php endif ?>
          </div>
        </div>
        <div class="pig-info">
          <p class="kind">物种：<span><?php echo $value['species'] ?></span></p>
          <p class="time">饲养时间：<span class="day"><?php echo $value['feed_time'] ?>天</span></p>
          <p class="weight">出肉量:<span><?php echo $value['output'] ?></span></p>
          <span class="qualityscore"><?php echo $value['main_level'] ?></span>
          <span class="freshscore"><?php echo $value['fresh_level'] ?></span>
          <span class="transscore"><?php echo $value['log_level'] ?></span>
        </div>
        <div class="user">
          <p class="username">用户：<?php echo $value['nickname'] ?></p>
          <p class="place">养殖场：<?php echo $value['farm']['farm_name'] ?></p>
          <p class="date">发布时间：<?php echo date('Y年m月d日',$value['createtime']) ?></p>
        </div>
      </li>
    <?php endforeach ?>
      
    </ul>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/js/index.js"></script>
  <script src="/assets/c/public/lib/lightbox/lightbox.min.js"></script>
</body>