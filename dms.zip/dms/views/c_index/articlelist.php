<!DOCTYPE html><!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<!--[if IE]>    <html class="ie8 woldie" lang="en"> <![endif]--> 
<head>
  <title>典牧署</title>
  <meta charset="utf-8">
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
  <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
  <link rel="stylesheet" href="/assets/c/public/fonts/iconfont.css">
  <link rel="stylesheet" href="/assets/c/css/common.css">
  <link rel="stylesheet" href="/assets/c/css/article.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <style type="text/css">
    .now_active{
      background-color: #8fc31f;
    }
    #header-menu .nav .now_active .title{
      color: #fff;
    }
    #header-menu .nav .now_active .detail{
      color: #fff;
    }
  </style>
</head>
<body>
<div id="header-top">
    <div class="header-main"> 
      <ul class="header-info">
        <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>"><i class="iconfont icon-muchang"></i> 我的牧业</a></li>
        <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_result/index' ?>"><i class="iconfont icon-rou"></i> 养殖收获</a></li>
      </ul>
      <ul class="login">
        <?php if (isset(Yii::$app->session['font_user'])): ?>
          <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_message/index' ?>" class="mess"><i class="iconfont icon-youxiang"></i> 消息中心</a></li>
          <li class="person"><a id="person-center" href="javascript:;" class="person-center"><img style="width: 35px;height: 35px;border-radius: 18px;" src="<?php echo Yii::$app->request->cookies->get('head_url') ?>" alt="个人中心"></a>
            <ul class="person-data">
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_user/index'; ?>">个人资料</a></li>
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_user/index'; ?>">收货地址</a></li>
              <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_login/logout'; ?>">退出 </a></li>
            </ul>
          </li>
        <?php else: ?>
          <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_login/tologin'; ?>" class="mess"><i class="iconfont icon-shouji"></i> 登陆</a></li>
        <?php endif ?>
        
      </ul>
    </div>
  </div>
  <!-- 导航部分     -->
  <div id="header-menu" class="fix"><a href="<?php echo Yii::$app->request->hostInfo; ?>" class="logo"> <img src="/assets/c/images/common/logo.png" alt="典牧署"></a>
    <div class="search"><i class="iconfont icon-sousuo"></i>
      <form action="<?php echo Yii::$app->request->hostInfo.'/c_index/searchlist' ?>">
        <?php if (isset($_GET['keyword'])): ?>
          <input type="text" name="keyword" value="<?php echo $_GET['keyword'] ?>" placeholder="请输入相关商品信息......" class="search-input">
        <?php else: ?>
          <input type="text" name="keyword" placeholder="请输入相关商品信息......" class="search-input">
        <?php endif ?>
        <input type="submit" value="搜索" class="submit">
      </form>
    </div>
    <ul class="nav">
      <li><a class="now_active" target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/articlelist' ?>"><span class="title">畜牧手册</span><br><span class="detail">啥叫一头好猪</span></a></li>
      <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/commentlist' ?>"><span class="title">养殖者说</span><br><span class="detail">过来人的说法</span></a></li>
      <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>"><span class="title">帮助中心</span><br><span class="detail">解答你的疑问</span></a></li>
    </ul>
  </div>
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="#">畜牧手册</a>><a href="#">列表</a></div>
  <div class="main">
    <ul class="article-list" id="list">
      
    </ul>
    <div class="adopt-read news-list">
      <p class="title">养殖必读</p>
      <ul>
        <?php foreach ($toplist as $key => $value): ?>
          <?php if ($key==0 || $key==1 || $key==2): ?>
            <li class="hot"><span class="num"><?php echo $key+1 ?></span><a href="<?php echo 'article?id='.$value['id'] ?>"><?php echo $value['title'] ?></a></li>
          <?php else: ?>
            <li><span class="num"><?php echo $key+1 ?></span><a href="<?php echo 'article?id='.$value['id'] ?>"><?php echo $value['title'] ?></a></li>
          <?php endif ?>
        <?php endforeach ?>
      </ul>
    </div>
    <div class="pagelist"></div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script type="text/javascript">
  $(function(){

    query(1,10,function(total){
        $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
           query(page,size);
        }});
    });

    function query(page,size,callback){
        $.ajax({
          type:'post',
          url:"articlejson?page="+page+"size="+size,
          dataType:'json',
          beforeSend:function() {  
             $('#query_hint').css("display","block");
        
          },
          complete:function(){
             $('#query_hint').css("display","none");
          },
          success:function(data){
            var content = '';
            $.each(data.data,function(index,item){
              content+="<li><img src=http://"+item.img_url+"><a href=article?id="+item.id+" class='title'>"
              +item.title
              +"</a><p class='time'>"+item.update_time+"</p><p class='desc'>"+item.content+"……</p></li>";
            })
            $("#list").html(content);
            callback && callback(data.total);
          },
          error:function(data){
            $('#query_hint').css("display","none");
            alert('请求超时');
          }
        })
    }
  })
  </script>
</body>