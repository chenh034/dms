  <link rel="stylesheet" href="/assets/c/css/article.css">
  <style type="text/css">
    .main .article-detail{
       width: 98%;
    }
  </style>
  <div class="main">
    <div class="article-detail">
      <h1 class="title"><?php echo $infos['name'] ?></h1>
      <div class="detail">
        <?php echo $infos['content']; ?>	
      </div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
</body>