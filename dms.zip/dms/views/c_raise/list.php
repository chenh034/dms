  <link rel="stylesheet" href="/assets/c/css/share_pig_list.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_raise/list' ?>">共筹</a>><a href="#">列表</a></div>
  <div class="main">
    <div class="sort">
      <select class="kind">
        <option value="0">全部</option>
        <?php foreach ($species as $key => $value): ?>
          <option value="<?php echo $value['id'] ?>"><?php echo $value['name'] ?></option>
        <?php endforeach ?>
      </select>
      <p class="sortby-time">按时间排序<a href="javascript:;" class="active up">&uarr;</a><a href="javascript:;" class="down">&darr;</a></p>
      <p class="sortby-share">按共筹度排序<a href="javascript:;" class="up">&uarr;</a><a href="javascript:;" class="down">&darr;</a></p>
    </div>
    <div class="piglist">
      <ul id="list">
        
      </ul>
    </div>
    <div class="pagelist">
     
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/js/share_pig.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script type="text/javascript">
  $(function(){
      var total;
      var page=1;
      var size=12;
      var species = $(".kind").val();
      var time = 'desc';
      var rate = 'asc';
      setCookie('raise_kind',$(".kind").val());
      setCookie('sortby-time','desc');
      setCookie('sortby-share','asc');

      query(page,size,species,time,rate);
      total = getCookie('raise_total');

      $(".kind").on('change',function(){
        species = $(this).val();
        setCookie('raise_kind',$(".kind").val());
        query(page,size,species,time,rate,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
            }});
         });
      })

      $(".sortby-time .up").on('click',function(){
         time = 'desc';
         setCookie('sortby-time','desc');
         query(page,size,species,time,rate,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
            }});
         });
      })

      $(".sortby-time .down").on('click',function(){
         time = 'asc';
         setCookie('sortby-time','asc');
         query(page,size,species,time,rate,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
            }});
         });
      })

      $(".sortby-share .up").on('click',function(){
         rate = 'desc';
         setCookie('sortby-share','desc');
         query(page,size,species,time,rate,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
            }});
         });
      })

      $(".sortby-share .down").on('click',function(){
         rate = 'asc';
         setCookie('sortby-share','asc');
         query(page,size,species,time,rate,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
            }});
         });
      })
      
      $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
          query(page,size,getCookie('raise_kind'),getCookie('sortby-time'),getCookie('sortby-share'));
      }});

      function query(page,size,species,time,rate,callback){
         $.ajax({
            type:'post',
            url:"json?page="+page+"&size="+size+"&species="+species+"&time="+time+"&rate="+rate,
            dataType:'json',
            beforeSend:function() {  
             $('#query_hint').css("display","block");        
            },
            complete:function(){
               $('#query_hint').css("display","none");
            },
            success:function(data){
              var content = '';
              $.each(data.data,function(index,item){
                content+="<li><img src=http://"+item.img_url+" alt=''><p class='title'>"+item.species+"<span class='address'>"
                +item.farm_place
                +"</span></p><p class='birth'>出生日期: <span class='date'>2016-09-09</span></p><p class='weight'>30天体重：<span class='num'>"
                +item.foundation_weight
                +"<span>kg</span></span></p><p class='cur'>已共筹<span class='curnum'>"
                +item.rate*100
                +"<span>%</span></span></p><p class='time'> <span>7天0小时</span>后截止</p><div class='clear'></div><a href=detail?id="+item.id+" class='join'>我要共筹</a></li>";
              })
              // setCookie('raise_total',data.total);
              $("#list").html(content);
              callback && callback(data.total);
            },
            error:function(data){
               alert('请求超时');  
               $('#query_hint').css("display","none");
            }
          })
      }

  })
    
  </script>
</body>