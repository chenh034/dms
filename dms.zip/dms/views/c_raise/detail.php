  <link rel="stylesheet" href="/assets/c/css/share_pig_select.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_raise/list' ?>">共筹</a>><a href="#">详情</a></div>
  <div class="main">
    <div class="pig-package-info"><img src="<?php echo 'http://'.$data['product']['img_url'] ?>" alt="猪">
      <div class="pig-info">
        <p class="title"><?php echo $data['product']['species'] ?></p>
        <p class="id">身份证：<span><?php echo $data['product']['name'] ?></span></p>
        <p class="place">饲养地: <span><?php echo $data['product']['farm_place'] ?></span></p>
        <p class="weight">当前体重: <span><?php echo $data['product']['foundation_weight'] ?>kg</span></p>
        <p class="note"><?php echo $data['product']['introduce'] ?></p>
        <div class="pig-life">
          <p class="time">饲养时间: <span><?php echo $data['product']['feed_time'] ?>天</span></p>
          <p class="eat">选择伙食: <span><?php echo $data['product']['forage'] ?></span></p>
          <p class="output">预计出肉: <span><?php echo $data['product']['pre_weight'] ?>kg</span></p>
        </div>
      </div>
      <div class="output-detail">
        <p class="title">肉类各部分估算</p>
        <div>
          <pre style="white-space: pre-line;">
          <?php echo $data['product']['setmeal_info']; ?>
          </pre>
        </div>
      </div>
    </div>
    <form action="<?php echo Yii::$app->request->hostInfo.'/c_order/add' ?>" method="post">
      <input type="text" name="product_id" value="<?php echo $data['product']['id'] ?>" style="display: none;">
      <input type="text" name="product_type" value="2" style="display: none;">
      <div class="package-select">
        <p class="title">选择套餐</p>
        <ul>
          <?php foreach ($data['setmeal'] as $key => $value): ?>
            <?php if ($value['buy']==1): ?>
               <li class="disabled">
                 套餐<?php echo $key+1 ?>
                 <span><?php echo $value['name'] ?></span>
                 <span class="price"><?php echo $value['price'] ?></span>
               </li>
            <?php else: ?>
               <li>
                  套餐<?php echo $key+1 ?>
                  <span><?php echo $value['name'] ?>  </span>
                  <span class="price"><?php echo $value['price'] ?></span>
                  <input type="checkbox" name="setmeals[]" style="display: none;" value="<?php echo $value['id'] ?>">
               </li>
            <?php endif ?>
          <?php endforeach ?>
        </ul>
      </div>
      <div class="pay-money">
        <p class="money">价格 : <span>¥488.00</span></p>
        <input type="submit" value="提交付款" class="save post-pay">
      </div>
    </form>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/js/share_pig.js"></script>
</body>