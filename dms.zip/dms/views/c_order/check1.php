  <link rel="stylesheet" href="/assets/c/css/share_pig.css">
  <link rel="stylesheet" href="/assets/c/css/person_center.css">
  <div class="main">
    <form action="<?php echo Yii::$app->request->hostInfo.'/c_order/confirm?order_id='.$data['order_id'] ?>" method="post">
    <div class="pig-package"><img src="<?php echo 'http://'.$data['product']['img_url'] ?>" alt="">
      <p class="number">猪种编号<span><?php echo $data['product']['name'] ?></span></p>
      <p class="detail">养殖详情
      <span>
         &nbsp;品种：<?php echo $data['product']['species'] ?>; 
         &nbsp;身份证：<?php echo $data['product']['name'] ?>; 
         &nbsp;养殖时间：<?php  echo $data['product']['feed_time'] ?>天  ; 
         &nbsp;选择饲料：<?php echo $data['product']['forage'] ?>; 
      </span></p>
      <p class="money">支付金额 <span>¥<?php echo $data['all_price']  ?>	</span></p>
      
    </div>
    <div class="pay">
      <!-- <label>
        <input type="radio" name="payway" value="wx"><img src="/assets/c/images/common/pay-wx.jpg" alt="微信支付">
      </label>
      <label>
        <input type="radio" name="payway" value="alipay"><img src="/assets/c/images/common/pay-alipay.jpg" alt="支付宝">
      </label> -->

      <div class="address-list"> 
        <p style="text-align: left;font-size: 20px;">选择收货地址</p>
        <ul>
          <?php foreach ($data['address'] as $key => $value): ?>
            <li><a class="person"><?php echo $value['name'] ?><span class="phone">(<?php echo $value['cellphone'] ?>)</span></a>
              <p class="place">
              <?php echo $value['province'].' '.$value['city'].' '.$value['area']['area'].' '.$value['detail_address'] ?>
              </p>
              <input type="radio" class="address_id" name="address_id" value="<?php echo $value['id'] ?>" style="display: none;">
            </li>
          <?php endforeach ?>
        </ul>
      </div>
      <input type="submit" value="确认支付" class="save confirm-pay">
    </div>
    </form>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script type="text/javascript">
    $(function(){
      $(".address-list li").on('click',function(){
         $(this).toggleClass("selected");
          if ($(this).attr('class')=="selected") {
              $(this).children("input").prop('checked',true)
          }else{
              $(this).children("input").prop('checked',false)
          }
      })
      $('form').submit(function () {
        var num = 0;
        for(var i = 0; i < $('.address_id').length; i++) {
          if ($('.address_id').is(':checked')) {
            num++;
          }
        }
        if (num === 0) {
          alert('请选择收货地址');
          return false;
        }
      })
    })
  </script>
</body>