  <link rel="stylesheet" href="/assets/c/css/person_center.css">
  <link rel="stylesheet" href="/assets/c/css/mark.css">
  <div class="main">
    <h2>修改收货地址</h2>
      <div class="address-add" style="display: block;">
        <form action="<?php echo Yii::$app->request->hostInfo.'/c_user/edit?id='.$address['id'] ?>" method="post">
          <label for="receiver">收件人
            <input type="text" name="name" class="receiver" value="<?php echo $address['name'] ?>">
          </label>
          <label for="phone">手机号码
            <input type="number" name="cellphone" class="number" value="<?php echo $address['cellphone'] ?>">
          </label>
          <!-- 后期需要引入脚本进行替换-->
          <div id="distpicker4">
            <label for="place">所在地区
              <select class="province" data-province="<?php echo $address['province'] ?>"></select>
              <select class="city" data-city="<?php echo $address['city'] ?>"></select>
              <select class="area" name="area_id" data-district="<?php echo $address['area']['area'] ?>"></select> 
            </label>
          </div>
          <label for="detail-address">详细地址
            <input type="text" name="detail_address" class="detail-address" value="<?php echo $address['detail_address'] ?>">
          </label>
          <div class="operation">
            <input type="submit" name="submit" value="保存" class="save">
            <input type="button" value="删除" class="del">
            <input type="reset" value="取消" class="cancel">
          </div>
        </form>
      </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <!-- <script src="/assets/c/js/person_center.js"></script> -->
  <script src="/assets/c/js/distpicker.data.js"></script>
  <script src="/assets/c/js/distpicker.js"></script>
  <script src="/assets/c/js/main.js"></script>
</body>