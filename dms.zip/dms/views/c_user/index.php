  <link rel="stylesheet" href="/assets/c/css/person_center.css">
  <link rel="stylesheet" href="/assets/c/css/mark.css">
  <div class="main">
    <h2>个人中心</h2>
    <div class="nav"><a href="javascript:;" class="active">个人资料</a><a href="javascript:;">收货地址</a></div>
    <div class="person-datas person-block">
      <form name="person-data" action="<?php echo Yii::$app->request->hostInfo.'/c_user/user'; ?>" method="post" enctype="multipart/form-data">
        <div class="left">
          <p>头像</p>
          <!-- <div class="imgupload"><img src="<?php echo 'http://'.$data['head_url'] ?>" alt="" class="photo">
            <input type="file" name="file" accept="image/*" class="file"><a href="javascript:;" class="upload">点击上传头像</a>
          </div> -->
          <div class="imgupload">
            <span class="tip">点击图片更换头像<br>(保存后生效)</span>
            <img src="<?php echo $data['head_url'] ?>" alt="" class="photo">
            <input type="file" name="file" accept="image/*" class="file">
          </div>
        </div>
        <div class="right">
          <?php if (Yii::$app->session->getFlash('status')): ?>
            <script type="text/javascript">
              alert('修改成功');
            </script>
          <?php endif ?>
          <label for="nickname">用户昵称
            <input type="text" name="nickname" class="nickname" value="<?php echo $data['nickname'] ?>">
          </label>
          <label for="phone">绑定手机
            <p><?php echo $data['username'] ?></p>
          </label>
          <label for="password">用户密码
            <p>*********<a href="<?php echo Yii::$app->request->hostInfo.'/c_pass/index' ?>">更改密码</a></p>
          </label>
          <input type="submit" value="保存" class="submit save">
        </div>
      </form>
    </div>
    <div class="address person-block">
      <div class="address-list"> 
        <ul>
        <?php foreach ($data['address'] as $key => $value): ?>
          <?php if ($value['is_default']==1): ?>
            <li><a href="toedit?id=<?php echo $value['id'] ?>" class="person"><?php echo $value['name'] ?><span class="phone">(<?php echo $value['cellphone'] ?>)</span><a href="javascript:;" class="default" rel="<?php echo $value['id'] ?>">默认</a></a>
            <p class="place"><?php echo $value['province'].' '.$value['city'].' '.$value['area']['area'].' '.$value['detail_address'] ?>   </p>
          </li>
          <?php else: ?>
            <li><a href="toedit?id=<?php echo $value['id'] ?>" class="person"><?php echo $value['name'] ?><span class="phone">(<?php echo $value['cellphone'] ?>)</span><a href="javascript:;" rel="<?php echo $value['id'] ?>" class="setdefault">设为默认</a></a>
              <p class="place"><?php echo $value['province'].' '.$value['city'].' '.$value['area']['area'].' '.$value['detail_address'] ?>  </p>
            </li>
          <?php endif ?>
        <?php endforeach ?>
        </ul><a href="javascript:;" class="new-address">+ 添加收货地址</a>
      </div>
      <div class="address-add">
        <form action="<?php echo Yii::$app->request->hostInfo.'/c_user/address' ?>" method="post">
          <label for="receiver">收件人
            <input type="text" name="name" class="receiver">
          </label>
          <label for="phone">手机号码
            <input type="number" name="cellphone" class="number">
          </label>
          <!-- 后期需要引入脚本进行替换-->
          <div id="distpicker4">
            <label for="place">所在地区
              <select class="province"></select>
              <select class="city"></select>
              <select class="area" name="area_id"></select> 
            </label>
          </div>
          <label for="detail-address">详细地址
            <input type="text" name="detail_address" class="detail-address">
          </label>
          <div class="operation">
            <input type="submit" name="submit" value="保存" class="save">
            <!-- <input type="button" value="删除" class="del"> -->
            <input type="reset" value="取消" class="cancel">
          </div>
        </form>
      </div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/js/person_center.js"></script>
  <script src="/assets/c/js/distpicker.data.js"></script>
  <script src="/assets/c/js/distpicker.js"></script>
  <script src="/assets/c/js/main.js"></script>
  <script type="text/javascript">
     $(".address-list a").on('click',function(){
        var _this = $(this);
        if (_this.attr('class')=='setdefault') {
          $.ajax({
              type:'get',
              url:"default?id="+this.rel,
              dataType:'json',
              async: false,
              success:function(data){
                if (data.code==0) {
                  $('.default').html('设为默认');
                  $('.default').attr('class','setdefault');
                  _this.attr('class','default');
                  _this.html('默认');
                }
              }
          })
        }
     });
  </script>
</body>