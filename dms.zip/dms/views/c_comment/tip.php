<!DOCTYPE html>
<html lang="en">
  <head> 
    <title>典牧署</title>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="screen-orientation" content="portrait">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="x5-orientation" content="portrait">
    <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
    <link rel="stylesheet" href="/assets/c/css/passport.css">
    <style>
      .main {
      	text-align: center;
      	padding-bottom: 100px;
      }
      p.success {
      	margin-top: 40px;
      	font-size: 24px;
      	color: #6f9c0d;
      }
      p.success img {
      	position: relative;
      	top: 6px;
      }
      .main a.tologin {
      	display: inline-block;
      	width: 120px;
      	padding: 8px 24px;
      	background: #8fc31f;
      	margin-top: 20px;
      	color: #fff;
      	margin-bottom: 20px;
      	box-sizing: border-box;
      	border-radius: 4px;
      
      }
      .main a.tologin:hover {
      	background: #6f9c0d;
      }
      .time {
      	margin-top: 30px;
      	color: #b5b5b5;
        /**/
      }
      
    </style>
  </head>
  <body>
    <div class="header"><a href="#"><img src="/assets/c/images/passport/passport-logo.png" alt="典牧署"></a></div>
    <div class="main-bg">
      <div class="main">
        <p class="success">
          <img src="/assets/c/images/common/ok.png" alt="ok">
          评价成功
        </p>
        <p class="time"><span id="num">5</span>秒后返回 </p><a href="index" class="tologin">立即返回</a>
      </div>
    </div>
    <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
    <script>
      window.onload = function () {
      	var oNum = document.getElementById('num');
      	var num = 5;
      	var timer = setInterval(function () {
      		oNum.innerHTML = num--;
      		if (num <= 0) {
      			clearInterval(timer);
      			timer = null;
      			window.location.href = 'index';
      			}					
      	}, 1000);
      
      };
    </script>
  </body>
</html>