  <link rel="stylesheet" href="/assets/b/css/transport_detail.css">
  <link rel="stylesheet" href="/assets/c/css/transport_detail.css">
  <div class="main">
    <?php foreach ($order as $key => $value): ?>
          <div class="detail">
          <p class="number">运单号码： <?php echo $value['express']->nu ?></p>
          <div class="detail-panel">
            <div class="panel-package">
              <div class="package-title">
                  <h3 class="title-text">
                      <?php if ($value['express']->state==0): ?>
                        您的包裹正在运送中
                      <?php endif ?>
                      <?php if ($value['express']->state==1): ?>
                        您的包裹已被快递公司揽件
                      <?php endif ?>
                      <?php if ($value['express']->state==2): ?>
                        您的包裹运送中出现问题
                      <?php endif ?>
                      <?php if ($value['express']->state==3): ?>
                        您的包裹已被签收
                      <?php endif ?>
                      <?php if ($value['express']->state==4): ?>
                        您的包裹已退签
                      <?php endif ?>
                      <?php if ($value['express']->state==5): ?>
                        您的包裹正在派件
                      <?php endif ?>
                      <?php if ($value['express']->state==6): ?>
                        您的包裹已被退回
                      <?php endif ?>
                  </h3>
                  <div class="title-en"></div>
              </div>
              <div class="package-status">
                  <div class="status-box" id="status_list">
                      <ul id="J_listtext2" class="status-list">
                          <?php if ($value['express']->message=='ok'): $weekarray=array("日","一","二","三","四","五","六"); ?>
                            <?php foreach ($value['express']->data as $k => $v): ?>
                              <li>
                                  <?php if ($k!=0 && substr($v->time, 0,10)==substr($value['express']->data[$k-1]->time, 0,10)): ?>
                                    <span class="date hidden"><?php echo substr($v->time, 0,10) ?></span>
                                    <span class="week hidden">周<?php echo $weekarray[date('w',strtotime(substr($v->time, 0,10)))] ;?></span>
                                  <?php else: ?>
                                    <span class="date"><?php echo substr($v->time, 0,10) ?></span>
                                    <span class="week">周<?php echo $weekarray[date('w',strtotime(substr($v->time, 0,10)))] ;?></span>
                                  <?php endif ?>
                                  <span class="time"><?php echo substr($v->time, 11,8) ?></span>
                                  <span class="text"><?php echo $v->context; ?></span>
                              </li>
                            <?php endforeach ?>
                          <?php else: ?>
                            <p style="text-align: center;font-size: 16px;">暂无物流消息</p>
                          <?php endif ?>          
                      </ul>
                      
                  </div>
              </div>
            </div>
          </div>
        </div>
    <?php endforeach ?>
    
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <!-- js-->
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/b/js/index.js"></script>
  <script>
    // 头部下拉

    $(function(){
      $(".hidden").html('');

      $('.login a').click(function (ev) {
        $('.login ul').toggle();
      });
    })
    
  </script>
</body>