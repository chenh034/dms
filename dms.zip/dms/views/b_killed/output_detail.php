  <link rel="stylesheet" href="/assets/b/css/output_detail.css">
  <div class="main">
    <div class="pig-info"><img src="<?php echo 'http://'.$product['img_url'].'-small.270.190' ?>" alt="">
      <p class="title"><?php echo $product['species']['name'] ?></p>
      <p class="id">典牧署身份证: <span><?php echo $product['name'] ?></span></p>
      <p class="place">饲养地: <span><?php echo $product['farm']['account_place'] ?></span></p>
      <p class="date">
        养殖时间:
        <span class='start'><?php echo $product['start_time'] ?></span> 到 <span class='end'><?php echo $product['end_time'] ?></span>
      </p>
      <p class="output">出肉量：<span><?php echo $product['output'] ?></span></p>
    </div>
    <div class="table meat-info">
      <table>
        <thead>
          <tr class="head">
            <th>肉种</th>
            <th>数量</th>
            <th>单位</th>
            <th>每单位重量</th>
            <th>共计重量</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($product['result']['content'] as $key => $value): ?>
            <tr>
              <td><?php echo $value['kind'] ?></td>
              <td><?php echo $value['number'] ?></td>
              <td><?php echo $value['unit'] ?></td>
              <td><?php echo $value['weight'] ?>kg</td>
              <td><?php echo $value['all'] ?>kg</td>
            </tr>
          <?php endforeach ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <!-- js-->
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/b/js/c_common.js"></script>
</body>