  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
    .query_hint{
        display: none;
        border:5px solid #939393;
        width:250px;
        height:50px;
        line-height:55px;
        padding:0 20px;
        position:fixed;
        left:50%;
        margin-left:-140px;
        top:50%;
        margin-top:-40px;
        font-size:15px;
        color:#333;
        font-weight:bold;
        text-align:center;
        background-color:#f9f9f9;
    }
    .query_hint img{position:relative;top:10px;left:-8px;}
    .main .right .tab-main table tbody td .k_name{
        border: none;
        color: #000;
        width: 120px;
        text-decoration: underline;
    }
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs_killed.html">已宰杀</a>
                     
      </div>
      <div class="tab-main pigs-killed">
        <ul class="tabs">
          <li id="null"><a href="javascript:;" rel="null">全部</a></li>
          <li id="4"><a href="javascript:;" rel="4">待发货</a></li>
          <li id="5"><a href="javascript:;" rel="5">待收货</a></li>
          <li id="6"><a href="javascript:;" rel="6">交易完成</a></li>
        </ul>
        <div class="all-mess pass-mess"> 
          <table>
            <thead>
              <tr>
                <th class="kind">物种</th>
                <th class="id">典牧署身份证</th>
                <th class="nature">养殖性质</th>
                <th class="time">宰杀时间</th>
                <th class="output">出肉量</th>
                <th class="status">交易状态</th>
              </tr>
            </thead>
            <tbody id="list">
              
              
            </tbody>
          </table>
          <div class="pagelist"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script src="/assets/b/js/index.js"></script>
  <script>
    // var total;
    // var status = getUrlParam('status');
    var page = 1;
    var size = 10;
    var status = $(".main .right .tabs a").first().attr('rel');
    setCookie('killed_status',status);

    query(1,10,status,function(total){
        $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
            query(page,size,getCookie('killed_status'));
        }});
    });
    
    $(".main .right .tabs a").on('click',function(){
        status = $(this).attr('rel');
        setCookie('killed_status',status);
        query(1,10,status,function(total){
            $('.pagelist').html('');
            $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size,getCookie('killed_status'));
            }});
        });
    })

    document.getElementById(status).className = 'now';

    function query(page,size,status,callback){
        $.ajax({
            type:'post',
            url:"json?page="+page+"&size="+size+"&status="+status,
            dataType:'json',
            beforeSend:function() {  
               $('#query_hint').css("display","block");
          
            },
            complete:function(){
               $('#query_hint').css("display","none");
            },
            success:function(data){
              var content = '';
              $.each(data.data,function(index,item){
                content+="<tr><td>"+item.species.name+"</td><td class='id'><a href=detail?id="+item.id+" class='k_name'>"+item.name+"</a></td><td>"+item.type+"</td><td>"+item.end_time+"</td><td>"+item.output+"</td><td><span>"+item.status+"</span><br><a href="+item.href+" class='operation'>"+item.op+"</a></td></tr>";
              })
              $("#list").html(content);
              callback && callback(data.total);
            }
        })
    }
    
    function getUrlParam(name)
    {
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
        var r = window.location.search.substr(1).match(reg);  //匹配目标参数
        if (r!=null) return unescape(r[2]); return null; //返回参数值
    }
    
  </script>
</body>