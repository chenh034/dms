  <link rel="stylesheet" href="/assets/b/css/index.css">
  <link rel="stylesheet" href="/assets/b/css/pigs_killed_transport.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs_killed.html">已宰杀</a>
        <a href="./pigs_killed_transport.html">分配发货</a>
                     
      </div>
      <p><?php echo Yii::$app->session->getFlash('log_status') ?></p>
      <div class="tab-main pigs-killed">      
        <div class="distribute-send">
          <div class="pig-mess"><img src="<?php echo 'http://'.$product['img_url'] ?>" alt="">
            <p class="title"><?php echo $product['species']['name'] ?></p>
            <p class="id">典牧署身份证：<span><?php echo $product['species']['name'] ?></span></p>
            <p class="time">养殖时间：<span class="start"><?php echo $product['start_time'] ?></span><span>至</span><span class="end"><?php echo $product['end_time'] ?></span></p>
          </div>
          <div class="clear"></div>
          <div class="transport-mess">
            <form action="<?php echo Yii::$app->request->hostInfo.'/b_killed/log' ?>" method="post" class="transport">       
              <table>
                <thead>
                  <th class="receiver-mess">送货信息</th>
                  <th class="transport-company">选择快递</th>
                  <th class="send-number">快递单号</th>
                </thead>
                <tbody> 
                  <?php foreach ($order as $key => $value): ?>
                    <tr>
                      <td class="receiver"> 
                        <p class="name"><?php echo $value['address']['name'] ?>
                          <span class="phone">(<?php echo $value['address']['cellphone'] ?>)</span>
                        </p>
                        <p class="address">
                          <?php echo $value['address']['address']['province'].$value['address']['address']['city'].$value['address']['address']['area'].$value['address']['detail_address'] ?>
                        </p>
                        <p class="nature"><?php echo $value['type'] ?>: 
                          <span><?php echo implode(',', $value['content']) ?></span>
                        </p>
                      </td>
                      <td>
                        <select name="<?php echo $value['id'] ?>[express]" class="company">
                          <?php foreach ($express as $k => $v): ?>
                              <?php if ($k==$value['express']): ?>
                                <option value="<?php echo $k ?>" selected><?php echo $v ?></option>
                              <?php else: ?>
                                <option value="<?php echo $k ?>"><?php echo $v ?></option>
                              <?php endif ?>
                          <?php endforeach ?>
                        </select>
                      </td>
                      <td>
                        <input name="<?php echo $value['id'] ?>[express_num]" type="text" class="send-number" value="<?php echo $value['express_num'] ?>">
                      </td>
                    </tr>
                  <?php endforeach ?>
                </tbody>
              </table>
              <input type="submit" value="确认提交" class="submit save">
              <div class="clear"> </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/js/index.js"></script>
</body>