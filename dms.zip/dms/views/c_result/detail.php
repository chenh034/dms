  <link rel="stylesheet" href="/assets/c/css/pork_detail.css">
  <div class="position">所在位置：<a href="index">养殖收获</a>><a href="#">订单详情</a>></div>
  <div class="main">
    <div class="pork_detail"><img src="<?php echo 'http://'.$order['product']['img_url'] ?>" alt="">
      <p class="title"><?php echo $order['product']['species']; ?></p>
      <p class="id">典牧署身份证: <span><?php echo $order['product']['name'] ?></span></p>
      <p class="date">
        养殖时间:
        <span class='start'><?php echo $order['product']['start_time'] ?></span> 到 <span class='end'><?php echo $order['product']['end_time'] ?></span>
      </p>
    </div>
    <div class="address">
      <p class="tit">送货地址:</p>
      <P class="info"> <span class="name"><?php echo $order['address']['name'] ?></span><span class="tel">(<?php echo $order['address']['cellphone'] ?>)</span></P>
      <p class="ad"><?php echo $order['address']['province'].$order['address']['city'].$order['address']['area'].$order['address']['detail_address'] ?></p><a href="#" class="check">查看物流</a>
    </div>
    <div class="clear"></div>
    <div class="nav"><a href="javascript:;" class="active">订单详情</a><a href="javascript:;">总出肉量</a></div>
    <div class="animal info">
      <div class="table meat-info"> 
        <table>
          <thead>
            <tr class="head">
              <th>订单号</th>
              <th>养殖性质</th>
              <th>养殖获得</th>
              <?php if ($order['product_type']==1): ?>
              	<th>所选饲料</th>
              <?php else: ?>
              	<th>获得明细</th>
              <?php endif ?>
              <th>费用</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><?php echo $order['id'] ?></td>
              <td><?php echo $order['type'] ?></td>
              <td class="kind"> 
                <p class="kind"><?php echo $order['result'] ?></p>
              </td>
              <td class="get">
                <p class="get"><?php echo $order['info'] ?></p>
              </td>
              <td>¥<?php echo $order['amount']; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="animal meat">
      <div class="table meat-detail1">
        <table>
          <thead>
            <tr class="head">
              <th>肉种</th>
              <th>数量</th>
              <th>单位</th>
              <th>每单位重量</th>
              <th>共计重量</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($output1 as $key => $value): ?>
              <tr>
                <td><?php echo $value['kind'] ?></td>
                <td><?php echo $value['number'] ?></td>
                <td><?php echo $value['unit'] ?></td>
                <td><?php echo $value['weight'] ?>kg</td>
                <td><?php echo $value['all'] ?>kg</td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
      <div class="table meat-detail2">
        <table>
          <thead>
            <tr class="head">
              <th>肉种</th>
              <th>数量</th>
              <th>单位</th>
              <th>每单位重量</th>
              <th>共计重量</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($output2 as $key => $value): ?>
              <tr>
                <td><?php echo $value['kind'] ?></td>
                <td><?php echo $value['number'] ?></td>
                <td><?php echo $value['unit'] ?></td>
                <td>每<?php echo $value['weight'] ?></td>
                <td><?php echo $value['all'] ?>kg</td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-08889999</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script>
    // 认养牛和认养猪切换
    $('.nav a').click(function () {
    	var index = $(this).index();
    	$('.animal').eq(index).fadeIn().siblings('.animal').fadeOut();
    	$(this).addClass('active').siblings('a').removeClass('active');
    });
    
  </script>
</body>