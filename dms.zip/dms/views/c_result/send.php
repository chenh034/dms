  <link rel="stylesheet" href="/assets/c/css/pork_adopt.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="main">
    <p class="title">自养猪肉</p>
    <div class="nav"><a href="index">全部</a><a href="wait">待发货</a><a class="active" href="send">待收货</a><a href="rec">待评价</a><a href="success">交易完成</a></div>
    <div class="table all">
      <table>
        <thead>
          <tr class="head">
            <th>猪肉信息</th>
            <th>养殖性质</th>
            <th>订单号</th>
            <th>价格</th>
            <th>交易状态</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody id="list">
          
        </tbody>
      </table>
      <div class="pagelist">
        
      </div>
    </div>

  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
  <script>
    $(function(){

      var page=1;
      var size=10;
      var total;
      query(page,size);
      total = getCookie("result_send_total");

      $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
          query(page,size);
      }});

      function query(page,size){
        $.ajax({
          type:'post',
          url:"sendjson?page="+page+"&size="+size,
          dataType:'json',
          beforeSend:function() {  
           $('#query_hint').css("display","block");        
          },
          complete:function(){
             $('#query_hint').css("display","none");
          },
          success:function(data){
            var content = '';
            $.each(data.data,function(index,item){
              var info = '';
              var status = '';
              var op = '';
              if (item.info=='整猪') {
                info = '整猪';
              }else{
                $.each(item.info,function(i,l){
                  info+='套餐'+l+'，';
                })
              }

              if (item.status=='202') {
                status = "<td>待发货<br><a href=detail?order_id="+item.id+" >订单详情</a></td>";
                op = "<td><a href='#' class='remind'>提醒发货</a></td>";
              }else if (item.status=='220') {
                status = "<td>待收货<br><a href=detail?order_id="+item.id+" >订单详情</a><br><a href=log?order_id="+item.id+">物流信息</a></td>";
                op = "<td><p class='time'>剩余14天2时32分</p><a href=confirm?order_id="+item.id+" class='remind'>确认收货</a></td>";
              }else if (item.status=='260') {
                status = "<td>交易成功<br><a href=detail?order_id="+item.id+" >订单详情</a></td>";
                op = "<td><a href=tocomment?order_id="+item.id+" class='remind'>去评价</a></td>";
              }

              content+="<tr><td class='special'><img src=http://"
              +item.product.img_url
              +"><p class='name'>"+item.species+"</p><p class='kind'>"+info+"</p></td><td>"
              +item.product_type+"</td><td>"
              +item.id
              +"</td><td>¥"+item.amount+"</td>"+status+op+"</tr>";
            })
            setCookie('result_send_total',data.total);
            $("#list").html(content);
          }
        })
      }

    })
  </script>
</body>