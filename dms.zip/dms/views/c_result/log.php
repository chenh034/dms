  <link rel="stylesheet" href="/assets/c/css/transport_detail.css">
  <div class="position">所在位置：<a href="#">首页</a>><a href="#">畜牧手册</a>><a href="#">具体内容</a></div>
  <div class="main">
    <div class="table">
      <table>
        <thead>
          <tr class="head">
            <th>订单号</th>
            <th>养殖性质</th>
            <th>养殖获得</th>
            <th>获得明细</th>
            <th>费用</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo $order['id'] ?></td>
            <td><?php echo $order['type'] ?></td>
            <td class="kind"> 
              <p class="kind"><?php echo $order['result'] ?></p>
            </td>
            <td class="get">
              <p class="get"><?php echo $order['info'] ?></p>
            </td>
            <td>¥<?php echo $order['amount'] ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="detail">
      <p class="number">运单号码： <?php echo $express->nu ?></p>
      <div class="detail-panel">
        <div class="panel-package">
          <div class="package-title">
              <h3 class="title-text">
                  <?php if ($express->state==0): ?>
                    您的包裹正在运送中
                  <?php endif ?>
                  <?php if ($express->state==1): ?>
                    您的包裹已被快递公司揽件
                  <?php endif ?>
                  <?php if ($express->state==2): ?>
                    您的包裹运送中出现问题
                  <?php endif ?>
                  <?php if ($express->state==3): ?>
                    您的包裹已被签收
                  <?php endif ?>
                  <?php if ($express->state==4): ?>
                    您的包裹已退签
                  <?php endif ?>
                  <?php if ($express->state==5): ?>
                    您的包裹正在派件
                  <?php endif ?>
                  <?php if ($express->state==6): ?>
                    您的包裹已被退回
                  <?php endif ?>
              </h3>
              <div class="title-en"></div>
          </div>
          <div class="package-status">
              <div class="status-box" id="status_list">
                  <ul id="J_listtext2" class="status-list">
                      <?php if ($express->message=='ok'): $weekarray=array("日","一","二","三","四","五","六"); ?>
                        <?php foreach ($express->data as $key => $value): ?>
                          <li>
                              <?php if ($key!=0 && substr($value->time, 0,10)==substr($express->data[$key-1]->time, 0,10)): ?>
                                <span class="date hidden"><?php echo substr($value->time, 0,10) ?></span>
                                <span class="week hidden">周<?php echo $weekarray[date('w',strtotime(substr($value->time, 0,10)))] ;?></span>
                              <?php else: ?>
                                <span class="date"><?php echo substr($value->time, 0,10) ?></span>
                                <span class="week">周<?php echo $weekarray[date('w',strtotime(substr($value->time, 0,10)))] ;?></span>
                              <?php endif ?>
                              <span class="time"><?php echo substr($value->time, 11,8) ?></span>
                              <span class="text"><?php echo $value->context; ?></span>
                          </li>
                        <?php endforeach ?>
                      <?php else: ?>
                        <p style="text-align: center;font-size: 16px;">暂无物流消息</p>
                      <?php endif ?>          
                  </ul>
                  
              </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-08889999</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script type="text/javascript">
    $(function(){
      $(".hidden").html('');
    })
  </script>
</body>