  <link rel="stylesheet" href="/assets/c/css/pig_evalution.css">
  <div class="position">所在位置：<a href="#">养殖收获</a>><a href="#">评论</a></div>
  <div class="main">
    <form action="<?php echo Yii::$app->request->hostInfo.'/c_comment/add' ?>" method="post" name="comment-upload" enctype="multipart/form-data">
      <div class="evalution">
        <div class="score">
          <p class="title">打分</p>
          <div class="rou">肉质情况<span class="star"><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i></span><span class="scores"></span> <input class="mark" type="text" name="main_level" value="0" style="display: none;"> </div>
          <div class="fresh">新鲜度<span class="star"><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i></span><span class="scores"></span> <input class="mark" type="text" name="fresh_level" value="0" style="display: none;"> </div>
          <div class="transport">物流速度<span class="star"><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i><i class="iconfont icon-kongxing"></i></span><span class="scores"></span> <input class="mark" type="text" name="log_level" value="0" style="display: none;"> </div>
        </div>
        <div class="comment">
          <p class="title">评价</p>
          <input type="text" name="product_id" value="<?php echo $order['product_id'] ?>" style="display: none;">
          <input type="text" name="order_id" value="<?php echo $order['id'] ?>" style="display: none;">
          <span class="tip">最多可以输入240个字</span>
            <textarea name="content" cols="122" rows="10" class="say"></textarea>
            <!-- <div class="img-uploader">
              <div class="small-img"></div>
              <div class="upload-btn">
                <input type="file" name="file[]" accept="image/gif, image/jpeg, image/jpg, image/png" multiple class="file"><a href="javascript:;" class="upload"><i class="iconfont icon-xiangji"></i></a>
              </div>
            </div> -->
            <div class="img-uploader">
              <div class="small-img"></div><span class="warning"></span>
              <div class="upload-btn iconfont icon-xiangji">
                <input type="file" name="file[]" accept="image/gif, image/jpeg, image/jpg, image/png" class="file">
              </div>
            </div>
            <input type="submit" value="发表评价" class="save evaluate">
        </div>
      </div>
    </form>
    <div class="table">
      <table>
        <thead>
          <tr class="head">
            <th>订单号</th>
            <th>养殖性质</th>
            <th>养殖获得</th>
            <th>获得明细</th>
            <th>费用</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo $order['id'] ?></td>
            <td><?php echo $order['type'] ?></td>
            <td class="kind"> 
              <p class="kind"><?php echo $order['result'] ?></p>
            </td>
            <td class="get">
              <p class="get"><?php echo $order['info'] ?></p>
            </td>
            <td>¥<?php echo $order['amount'] ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-08889999</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/c/public/lib/lightbox/lightbox.min.js"></script>
  <script src="/assets/c/js/pig_evalution.js"></script>
</body>