  <link rel="stylesheet" href="/assets/c/css/adoptkind_select.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="#">认养</a>><a href="#">选择物种</a></div>
  <div id="modal">
    <span class="b-close button">
      <span>X</span>
    </span>
    <div class="content"></div>
  </div>
  <div class="main">
    <div class="nav">
       <?php foreach ($species as $key => $value): ?>
         <?php if ($key==0): ?>
           <a href="?species_id=<?php echo $value['id'];?>" rel="<?php echo $value['id'];?>" class="active">认养<?php echo $value['name'];?></a>
         <?php else: ?>
           <a href="?species_id=<?php echo $value['id'];?>" rel="<?php echo $value['id'];?>" >认养<?php echo $value['name'];?></a>
         <?php endif ?>
       <?php endforeach ?>

    </div>
    <div class="animal pig">
      <ul class="animal-list" id="list">
        
      </ul>
      <div class="pagelist">
        
      </div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/public/lib/jquery.bpopup.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script src="/assets/c/js/adoptkind_select.js"></script>
  <script>
    $(function(){
      // var total;
      var page=1;
      var size=12;
      var species = GetQueryString('species_id');
      var list = $(".main .nav a");
      if (species==null) {
          species = $(".main .nav a").first().attr('rel')
      }
      $.each(list,function(i,l){
          if (l.rel==species) {
              list[i].className = 'active';
          }else{
              list[i].className = '';
          }
      })
      setCookie('adopt_species',species);
      query(page,size,species,function(total){
          $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
              query(page,size,getCookie('adopt_species'));
          }});
      });

      // $(".main .nav a").on('click',function(){
      //     $('.pagelist').html('');
      //     species = $(this).attr('rel');
      //     setCookie('adopt_species',species);
      //     query(1,12,species, function (adopt_total) {
      //       total = adopt_total;
      //       $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
      //           query(page,size,getCookie('adopt_species'));
      //       }});
      //     });
      // });


      function query(page,size,species,callback){
         $.ajax({
            type:'post',
            url:"speciesjson?page="+page+"&size="+size+"&species_id="+species,
            dataType:'json',
            beforeSend:function() {  
             $('#query_hint').css("display","block");        
            },
            complete:function(){
               $('#query_hint').css("display","none");
            },
            success:function(data){
              var content = '';
              $.each(data.data,function(index,item){
                content+="<li><img src=http://"+item.img_url+" alt='><p class='title'>"+item.name+"</p><p class='desc'>"+item.special+"</p><p class='intro'>"+item.introduce+"</p><a href=list?species_id="+item.id+" class='save adopt'>去认养</a></li>";
              })
              // setCookie('adopt_total',data.total);
              $("#list").html(content);
              callback && callback(data.total);
            },
            error:function(data){
               alert('请求超时');  
               $('#query_hint').css("display","none");
            }
          })
      }

      function GetQueryString(name)
      {
           var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
           var r = window.location.search.substr(1).match(reg);
           if(r!=null)return  unescape(r[2]); return null;
      }

    })
    
  </script>
</body>