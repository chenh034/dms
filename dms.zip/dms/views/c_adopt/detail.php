  <link rel="stylesheet" href="/assets/c/css/adopt_mess.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_adopt/specieslist' ?>">认养</a>><a href="#">详情</a></div>

  <div id="modal"> <span class="b-close button">X</span>
    <div class="content">
      <div class="ingredient-wrapper"><span class="title">原料：</span>
        <p class="ingredient"></p>
      </div>
      <div class="introduce-wrapper"><span class="title">简介</span>
        <p class="introduce"></p>
      </div>
      <div class="introduce-wrapper">
        <span style="vertical-align: top" class="title">图片 </span><br>
        <img style="margin-left: 40px;width: 245px;height: 174px" src="">
      </div>
    </div>
  </div>

  <div class="main">
    <div class="pig-info"><img src="<?php echo 'http://'.$data['product']['img_url'] ?>" alt="">
      <p class="title"><?php echo $data['product']['species'] ?></p>
      <p class="id">身份证: <span><?php echo $data['product']['name'] ?></span></p>
      <p class="id">出生日期: <span><?php echo $data['product']['birthday'] ?></span></p>
      <p class="place">饲养地: <span><?php echo $data['product']['farm_place'] ?></span></p>
      <p class="weight">当前体重: <span><?php echo $data['product']['foundation_weight'] ?>kg</span></p>
      <p class="desc">
        <?php echo $data['product']['introduce'] ?>
      </p>
    </div>
    <div class="adopt-info">
      <form action="<?php echo Yii::$app->request->hostInfo.'/c_order/add' ?>" method="post">

        <input type="text" name="product_id" value="<?php echo $data['product']['id'] ?>" style="display: none;">
        <input type="text" name="product_type" value="1" style="display: none;">

        <div class="eat">
          <span class="title">伙      食:</span>
          <a href="javascript:;" title="<?php echo $data['product']['forage']['id'] ?>"><?php echo $data['product']['forage']['name'] ?> </a>
        </div>
        <div class="date">
          <span class="title">饲养时间: </span>
          <p>
            <span class="basic_day">
              <span class="from"><?php echo $data['product']['birthday'] ?> </span>
              <span>到 </span>
              <span class="to"><?php echo $data['product']['end_time'] ?> </span>
              <span class="basic_days">(<?php echo $data['product']['feed_time'] ?>天)</span>
            </span>
          </p>
        </div>
        <p class="output">预计出肉:
          <span><?php echo $data['product']['pre_weight'] ?>kg</span>
        </p>
        <div class="gap first"></div>
        <p class="money">基础费用:
          <span class="all pig_price">¥<?php  echo $data['product']['foundation_price'] ?> </span>
          <br>
          <p class="add_money_include">
            <span class="add_money_detail">
              <span class="day_price">增加养殖时间费用：
                <span class="price">¥<?php echo $data['product']['feed_price'] ?></span>
                <span class="unit">/天</span>
              </span>
              <br>
              <span class="timeAdd">
                <label for="addTime"><input class="checkAddTime" type="checkbox"> 增加养殖时间</label>
                <span class="add_day">
                  <input type="number" name="feed_time" class="num">
                  <span class="tip">天</span>
                </span>
              </span>
            </span>
          </p>
          <div class="clear"></div>
        </p>
        <p class="money add_money">增加费用:
          <span class="all all_day_price">0</span>
        </p>
        <div class="gap"></div>
        <p id="all_money" class="money">饲养总价:
          <span class="all money multi_money"></span>
        </p>



        <input type="submit" value="提交付款" class="save pay">
      </form>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script type="text/javascript" src="/assets/c/public/lib/jquery.bpopup.js"></script>
  <script>

      $(function () {
          $('.checkAddTime').prop('checked', false);
          $('.timeAdd .num').val(0);
          var day = 0;
          var pigPrice = Number($('.pig_price').eq(0).text().substring(1));
          var dayPrice = Number($('.day_price .price').eq(0).text().substring(1));

          $('.multi_money').text('¥' + Number(pigPrice + dayPrice * day))

          // 显示增加养殖时间
          $('.checkAddTime').change(function () {
            if ($(this).is(':checked')) {
              $(this).parents('.timeAdd').find('.add_day').css('visibility', 'visible');
            } else {
              $(this).parents('.timeAdd').find('.add_day').css('visibility', 'hidden');
              day = 0;
              $('.timeAdd .num').val(0);
              $('.all_day_price').text(0)           
              $('.multi_money').text('¥' + Number(pigPrice + dayPrice * day))
            }
          });

          if ($('.timeAdd span.add_day').is(':visible')) {
            $('.timeAdd .num').keyup(function () {
              if (isNaN($(this).val()) || $(this).val() < 0) {
                alert('输入养殖时间有误，请重新输入');
                $(this).val(0);
                return false
              }
              if ($(this).val() % 1 !== 0) {
                alert('养殖时间必须为整天')
                $(this).val(Math.ceil($(this).val()));
              }
              day = Number($(this).val());
              $('.all_day_price').text('¥' + dayPrice * day)
              $('.multi_money').text('¥' + Number(pigPrice + dayPrice * day))
            });         
          }         

 
        
        var bPopup = null;  
        // 饲料详情
        $('.eat a').click(function () {
          if (bPopup !== null) {
            bPopup = $('#modal').bPopup();                          
            return false;
          }
          var id = $(this).attr('title');
          $.ajax({
            url: /*document.domain*/ 'http://'+document.domain+'/detail/forage?id=' +  id,
            dataType: 'json',
            success: function (res) {
              bPopup = $('#modal').bPopup();              
              $('#modal .ingredient').text(res.ingredient);
              $('#modal .introduce').text(res.introduce);
              $('#modal img').attr('src', 'http://' + res.img_url);
            }
          });
        });
        
        $('.b-close').click(function () {
          bPopup.close();
        });
        
        $('form').submit(function () {
          var regExp = new RegExp(/^\d+/);
          if ($('.checkAddTime').is(':checked')) {
            if(!regExp.test($('.num').val())) {
              alert('养殖时间请填写数字');
              return false;
            }
          }
        })

      })

  

    
  </script>
</body>