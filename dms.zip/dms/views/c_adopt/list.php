  <link rel="stylesheet" href="/assets/c/css/adopt_list.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo ?>">首页</a>><a href="javascript:history.back()">认养</a>><a href="#">列表</a></div>
  <div class="main">
    <!-- <p class="title">选择品种</p> -->
    <div class="pig-select">
     <!--  <select id="pig-kind" name="pig-kind">
        <option value="三元猪">三元猪</option>
        <option value="黑山猪">黑山猪</option>
      </select> -->
      <img src="<?php echo 'http://'.$species->img_url ?>" alt="">
      <p class="title"><?php echo $species->name ?></p>
      <p class="desc"><?php echo $species->introduce ?></p>
    </div>
    <div class="pig-list">
      <ul class="list" id="list">
        
      </ul>
      <div class="pagelist">
        
      </div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
  <script type="text/javascript">
    $(function(){
      var species_id = getUrlParam('species_id');

      query(1,12,species_id,function(total){
          $('.pagelist').Paging({pagesize:12,count:total,toolbar: true,callback:function(page,size,count){
              query(page,size,getUrlParam('species_id'));
          }});
      });


     function query(page,size,species,callback){
       $.ajax({
          type:'post',
          url:"json?page="+page+"&size="+size+"&species_id="+species,
          dataType:'json',
          beforeSend:function() {  
             $('#query_hint').css("display","block");        
          },
          complete:function(){
             $('#query_hint').css("display","none");
          },
          success:function(data){
            var content = '';
            $.each(data.data,function(index,item){
              content+="<li><img src=http://"+item.img_url+"><p class='title'>"+item.species+"<span class='address'>("+item.farm_name+")</span></p><p class='birth'>出生日期：<span class='date'>"+item.birthday+"</span></p><p class='birth'>饲料：<span class='date'>"+item.forage+"</span></p><p class='birth'>当前体重：<span class='num'>"+item.foundation_weight+"<span>kg</span></span></p><p class='weight'>养殖场地址：<span class='date'>"+item.farm_place+"</span></p><p class='cur'>定价：¥"+item.foundation_price+"</p><div class='clear'></div><a href=detail?id="+item.id+" class='join'>我要认养</a></li>";
            })
            $("#list").html(content);
            callback && callback(data.total);
          }
        })
    }

      function getUrlParam(name){
          var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
          var r = window.location.search.substr(1).match(reg);  //匹配目标参数
          if (r!=null) return unescape(r[2]); return null; //返回参数值
      }

    })
  </script>
</body>