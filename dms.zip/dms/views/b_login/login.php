<!DOCTYPE html>
<html lang="en">
  <head>
    <title>典牧署</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="/assets/b/public/reset.css">
    <link rel="stylesheet" href="/assets/b/css/login.css">
  </head>
  <body>
    <div class="header"><a href="#" class="logo"><img src="/assets/b/images/common/logo.png" alt="典牧署"></a>
      <p class="apply">申请入住电话: <span>0431-4801480</span></p>
    </div>
    <div class="main">
      <div class="banner"><img src="/assets/b/images/login-bg.jpg" alt="典牧署"></div>
      <div id="login">
        <form action="<?php echo Yii::$app->request->hostInfo;?>/b_login/login" method="post">
          <p class="title">养殖户登录</p>
          <input type="text" name="username" value="账户号" class="name">
          <input type="text" name="password" value="密码" class="password">
          <p style="position: relative;top:-8px;left: 5px;"><?php echo Yii::$app->session->getFlash("error") ;?></p>
          <input type="submit" value="立即登录" class="submit">
          <p class="forget">忘记密码请打电话：0431-4801480</p>
        </form>
      </div>
    </div>
    <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
    <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
    <script>
      $(function () {
        
        $('.name').focus(function () {
          if ($(this).val() && $(this).val() !== '账户号') {
            return false;
          }
          $(this).val('');
        }).blur(function () {
            if (!$(this).val()) {
              $(this).val('账户号');
            }
        });
        
        $('.password').focus(function () {
          if ($(this).val() && $(this).val() !== '密码') {
            return false;
          }
          $(this).attr('type', 'password');
          $(this).val('');
        }).blur(function () {
            if (!$(this).val()) {
              $(this).val('密码');              
              $(this).attr('type', 'text');
            }
        });
        
        $('form').submit(function (ev) {
          var event = event || window.event;
          
          if (ev.preventDefault) {
              // ev.preventDefault();
          } else {
              window.event.returnValue = false;
          }
          
          if ($('.name').val() == '' || $('.name').val() == '账户号') {
            alert('用户名不能为空');
            return false;
          }
          if ($('.password').val() == '' || $('.password').val() == '密码') {
            alert('密码不能为空');
            return false;
          }
          
          // alert('登录');
          return true;
        });
        
      });
      
      
      
      
        
    </script>
  </body>
</html>