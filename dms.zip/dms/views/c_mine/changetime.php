  <link rel="stylesheet" href="/assets/c/css/edit_adopttime.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">我的牧业</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">现养</a>><a href="#">更改养殖时间</a></div>
  <div class="main">
    <div class="pig-info"><img src="<?php echo 'http://'.$data['product']['img_url'] ?>" alt="">
      <p class="title"><?php echo $data['product']['species'] ?></p>
      <p class="id">身份证: <span><?php echo $data['product']['name'] ?></span></p>
      <p class="place">饲养地: <span><?php echo $data['product']['farm_place'] ?></span></p>
      <p class="weight">30天体重: <span><?php echo $data['product']['foundation_weight'] ?>kg</span></p>
      <p class="desc">
        <?php echo $data['product']['advice'] ?>
        
      </p>
    </div>
    <div class="adopt-info">
      <p class="part">
        目前时间:
        <span class='start'><?php echo $data['product']['start_time'] ?></span> 到 <span class='end'><?php echo $data['product']['end_time'] ?></span>
      </p>
      <form action="<?php echo Yii::$app->request->hostInfo.'/c_mine/timecheck' ?>" method="post">
        <input type="text" style="display: none;" name="product_id" value="<?php echo $data['product']['id'] ?>">
        <div class="date"> 
          <p>饲养时间到</p>
          <input id="start" class="laydate-icon" style="display: none;">
          <input type="text" name="end_time" id="end" class="laydate laydate-icon">
        </div>
        <p class="money"> <span class="all">¥400.00</span></p>
        <input type="submit" value="确定更改" class="save pay">
      </form>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <!-- 需要引入日期插件-->
  <script src="/assets/c/public/lib/laydate/laydate.js"></script>
  <script>
    var start = {
      elem: '#start',
      format: 'YYYY-MM-DD',
      min: laydate.now(), //设定最小日期为当前日期
      max: '2099-06-16', //最大日期
      istime: true,
      istoday: true,
      choose: function(datas){
         end.min = datas; //开始日选好后，重置结束日的最小日期
         end.start = datas //将结束日的初始值设定为开始日
      }
    };
    
    var end = {
      elem: '#end',
      format: 'YYYY-MM-DD',
      min: laydate.now(),
      max: '2099-06-16',
      istime: true,
      istoday: true,
      choose: function(datas){
        start.max = datas; //结束日选好后，重置开始日的最大日期
      }
    };
    
    laydate(start);
    laydate(end);
    
  </script>
</body>