  <link rel="stylesheet" href="/assets/c/css/person_adopt.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="main">
    <p class="title">我的牧业</p>
    <div class="nav"><a href="toduring">现养</a><a href="towait" class="active">待养</a><a href="tohistory">历史养殖</a></div>
    <div class="table now">
      <table>
        <thead>
          <tr class="head">
            <th>图片</th>
            <th>物种</th>
            <th>典牧署身份证</th>
            <th>养殖性质</th>
            <th>饲养时间</th>
            <th>预计出肉</th>
            <th>最新体重</th>
          </tr>
        </thead>
        <tbody id="list">
          
        </tbody>
      </table>
      <div class="pagelist">
        
      </div>
    </div>
    
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script>
    $(function(){
       // 饲料切换
      $('.nav a').click(function () {
        var index = $(this).index();
        $('.table').eq(index).fadeIn().siblings('.table').fadeOut();
        $(this).addClass('active').siblings('a').removeClass('active');
      });
      var page=1;
      var size=10;
      query(page,size,function(total){
        $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
            query(page,size);
        }});
      });

      function query(page,size,callback){
        $.ajax({
          type:'post',
          url:"wait?page="+page+"&size="+size,
          dataType:'json',
          beforeSend:function() {  
           $('#query_hint').css("display","block");        
          },
          complete:function(){
             $('#query_hint').css("display","none");
          },
          success:function(data){
            var content = '';
            $.each(data.data,function(index,item){
              content+="<tr><td><img src=http://"+item.img_url+"></td><td>"+item.species+"</td><td>"+item.name+"</td><td>"+item.type+"</td><td>"+item.feed_time+"天</td><td>"+item.pre_weight+"kg</td><td>"+item.now_weight+"kg<br><span>（"+item.update_time+"）</span></td></tr>";
            })
            $("#list").html(content);
            callback && callback(data.total);
          }
        })
      }

    })
  </script>
</body>