  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
  <link rel="stylesheet" href="/assets/c/css/pig_detail.css">
  <script src="/assets/c/ckplayer/ckplayer.js"></script>
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">我的牧业</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">现养</a>><a href="#">详情</a></div>
  <div class="main">
    <p class="title">我的牧业</p>
    <div class="pig-video">
      <!-- 此处会应用第三方的东西可兼容至ie8，兼容性问题暂不修复-->
      <!-- <video src="" poster="/assets/c/images/common/video.jpg" controls="controls"></video> -->
      <div id="videoPlay" style="width: 100%;height: 425px;"></div>
      <div class="pig-tab">
        <div class="nav"><a href="javascript:;" class="weight active">体重趋势图</a><a href="javascript:;" class="eat">进食量趋势图</a><a href="javascript:;" class="activity">活动量趋势图</a><a href="javascript:;" class="sleep">睡眠量趋势图</a><a href="javascript:;" class="fat">体脂率趋势图</a></div>
        <!-- 图表部分-->
        <div id="charts"></div>
      </div>
    </div>
    <div class="pig-info">
      <p style="display: none;" class="type"><?php echo $product['type']; ?></p>
      <p class="name"><?php echo $product['species'] ?></p>
      <p class="id">典牧署身份证: <?php echo $product['name'] ?></p>
      <div class="gap"></div>
      <p class="weight">体重量: <span><?php echo $product['now_weight'] ?>kg</span><span class="date">(<?php echo $product['update_time'] ?>)</span></p>
      <p class="eat">进食量: <span><?php echo $product['food_intake'] ?>kg</span><span class="date">(<?php echo $product['update_time'] ?>)</span></p>
      <p class="activity">活动量: <span><?php echo $product['activity'] ?>h</span><span class="date">(<?php echo $product['update_time'] ?>)</span></p>
      <p class="sleep">睡眠量: <span><?php echo $product['sleep'] ?>h</span><span class="date">(<?php echo $product['update_time'] ?>)</span></p>
      <p class="fat">体脂率: <span><?php echo $product['fat_ratio'] ?>%</span><span class="date">(<?php echo $product['update_time'] ?>)</span></p>
      <div class="gap"></div>
      <p class="eat-kind">喂养饲料: <span>精致牧草</span></p>
      <?php if ($product['type']==1): ?>
        <a href="<?php echo 'changeforage?id='.$product['id'] ?>" class="save edit-eat">更改饲料</a>
      <?php else: ?>
        <div class="gap"></div>
      <?php endif ?>
            
      <p class="time">养殖时间: 已养殖<span><?php echo $product['has_feed'] ?>天</span><span class="date">
          <br>
          <span class="from"><?php echo $product['start_time'] ?></span> 至 <span class="to"><?php echo $product['end_time'] ?></span></span></p>
          <?php if ($product['type']==1): ?>
            <a href="<?php echo 'changetime?id='.$product['id'] ?>" class="save edit_time">增加养殖时间</a>
          <?php else: ?>

          <?php endif ?>
      <div class="gap"></div>
      <p class="advice">养殖者建议
        <?php if ($product['advice']!=null): ?>
          <p><?php echo $product['advice'] ?></p>
        <?php else: ?>
          <p>暂无..</p>
        <?php endif ?>
      </p>
      <span style="display: none;" id="d_url"><?php echo $product['dorm']['url'] ?></span>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script>
        var flashvars;
        flashvars={
            f: '/assets/c/ckplayer/m3u8.swf',
            //a: 'http://open.ys7.com/openlive/f01018a141094b7fa138b9d0b856507b.hd.m3u8', //此处填写购买获取到的视频播放地址
            a: document.getElementById('d_url').innerHTML,
            c: 0,
            p: 1,
            s: 4,
            lv: 1
        };
        var params = {bgcolor: '#FFF', allowFullScreen: true, allowScriptAccess: 'always', wmode: 'transparent'};
        CKobject.embedSWF("/assets/c/ckplayer/ckplayer.swf", "videoPlay", "video", "100%", "100%", flashvars, params);
    </script>
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <!-- hightcharts 图表插件--><script src="/assets/c/public/lib/highcharts/highcharts.js"></script>
  <script src="/assets/c/public/lib/highcharts/exporting.js"></script>
  <!-- 页面所需js-->
  <script src="/assets/c/js/pig_detail.js"></script>
</body>