  <link rel="stylesheet" href="/assets/c/css/share_pig.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">我的牧业</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">现养</a>><a href="#">更改养殖时间</a></div>
  <div class="main">
    <div class="pig-package"><img src="/assets/c/images/common/pig.png" alt="">
      <p class="number">猪种编号<span>JL0122016022202</span></p>
      <p class="detail">支付详情<span class="time">养殖时间延长至<span>2017-07-22 </span></span></p>
      <p class="money">支付金额 <span>¥427.00	</span></p>
    </div>
    <div class="pay">
      <!-- <label>
        <input type="radio" name="payway" value="wx"><img src="/assets/c/images/common/pay-wx.jpg" alt="微信支付">
      </label>
      <label>
        <input type="radio" name="payway" value="alipay"><img src="/assets/c/images/common/pay-alipay.jpg" alt="支付宝">
      </label> -->
      <input type="button" value="确认支付" class="save confirm-pay">
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
</body>