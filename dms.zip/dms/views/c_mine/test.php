  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
  <div class="main">
    <div class="pig-video">
      <!-- 此处会应用第三方的东西可兼容至ie8，兼容性问题暂不修复-->
      <!-- <video src="" poster="/assets/c/images/common/video.jpg" controls="controls"></video> -->
      <video src="http://open.ys7.com/openlive/f01018a141094b7fa138b9d0b856507b.hd.m3u8"
           poster="http://i.ys7.com/static/images/64f874091341499eba92ca0e029dd433/0a003d50c31ac0b1e589937720eaa93a/1_web.jpeg"
           controls="controls" width="100%">
    </video>

    <div>ceshi</div>
    </div>

  </div>

</body>