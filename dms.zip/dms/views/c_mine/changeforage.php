  <link rel="stylesheet" href="/assets/c/css/edit_eat.css">
  <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">我的牧业</a>><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>">现养</a>><a href="#">更改饲料</a></div>
  <div class="main"><img src="<?php echo 'http://'.$data['product']['img_url'] ?>" alt="猪">
    <div class="pig-info">
      <p class="title"><?php echo $data['product']['species'] ?></p>
      <p class="id">身份证：<span><?php echo $data['product']['name'] ?></span></p>
      <p class="place">饲养地: <span><?php echo $data['product']['farm_place'] ?></span></p>
      <p class="weight">30天体重: <span><?php echo $data['product']['foundation_weight'] ?>kg</span></p>
      <p class="note">
        <?php echo $data['product']['advice'] ?>
      </p>
    </div>
    <div class="eat"> 
      <form action="<?php echo Yii::$app->request->hostInfo.'/c_mine/foragecheck' ?>" method="post">
      <p style="display: none;" class="now_price"><?php echo $data['product']['now_price'] ?></p>
      <input type="text" style="display: none;" name="product_id" value="<?php echo $data['product']['id'] ?>">
      <p class="all">现有饲料：<span><?php echo $data['product']['now_forage'] ?></span></p><span class="change">选择饲料</span>
      <select id="eat" name="new_forage">
        <?php foreach ($data['forage'] as $key => $value): ?>
          <option value="<?php echo $value['type_id'] ?>"><?php echo $value['name'] ?></option>
        <?php endforeach ?>
      </select><span class="strength"></span>
      <p class="money">¥0.00</p>
      <input type="submit" value="确定更改" class="save pay">
      </form>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <!-- js-->
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
</body>