  <link rel="stylesheet" href="/assets/b/css/pigs_add.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
    .newpigs-add .basic-mess .mess {
      width: 700px;
      float: left;
      overflow: hidden;
    }
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">所在位置：<a href="<?php echo Yii::$app->request->hostInfo.'/b_dorm/list' ?>">牧舍管理</a><a href="#">修改牧舍</a></div>
      <div class="tab-main pigs-repo">

        <div class="newpigs-add">
          <?php if (Yii::$app->session->getFlash('status')): ?>
            <script type="text/javascript">
              alert('修改成功');
            </script>
          <?php endif ?>
          <form action="<?php echo Yii::$app->request->hostInfo.'/b_dorm/update?id='.$dorm->id;?>" name="pigs-edit" method="post" enctype="multipart/form-data">
            
            <div class="basic-mess">               
              <div class="mess">
                <p class="number">牧舍编号
                  <!-- <span>JL012</span> -->
                  <input type="text" name="name" value="<?php echo $dorm->name ?>">
                </p>
                <p class="weight">直播地址
                  <input type="text" name="url" class="num" style="width: 610px;" value="<?php echo $dorm->url?>">
                </p>
              </div>
              
              <div class="clear"></div>
              <hr class="gap">
            </div>
            <input type="submit" value="确认提交" class="submit save">
            <div class="clear"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
<!--   <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/pigs_add1.js"></script>
  <script src="/assets/b/js/validator2.js"></script> -->
</body>