<!DOCTYPE html>
<html lang="en">
  <head> 
    <title>典牧署</title>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="screen-orientation" content="portrait">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="x5-orientation" content="portrait">
    <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
    <link rel="stylesheet" href="/assets/c/css/passport.css">
    <style type="text/css">
      span.login-error {
          visibility: visible;
          color: red;
          position: absolute;
          display: inline-block;
          visibility: hidden;
          width: 60%;
          height: 14px;
          top: 14px;
          margin-left: 8px;
          padding-left: 18px;
          background: url(/assets/c/images/common/status.png) no-repeat 0 -14px;
      }
    </style>
  </head>
  <body>
    <div class="header"><a href="#"><img src="/assets/c/images/passport/passport-logo.png" alt="典牧署"></a></div>
    <div class="main-bg">
      <div class="main"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
        <p class="intro">
          城市丛林太无趣，肉类吃得不放心？典牧署帮你养殖健康肉
        </p>
        <div class="login-modal">
          <p class="nav"><a id="reg" href="javascript:;">注册</a><a id="login" href="javascript:;" class="active">登录</a></p>
          <div class="reg">
            <form action="" method="post">
              <div class="phone-box">
                <input type="number" name="phone" placeholder="手机号" class="phone"><span class="tip"></span>
              </div>
              <!-- 短信验证码-->
              <div class="smscode-box">
                <input type="text" name="smscode" placeholder="短信验证码" class="smscode"><a href="javascript:;" class="sendcode">发送验证码</a><span class="tip"></span>
              </div>
              <div class="password-box">
                <input type="password" name="password" placeholder="设置密码" class="password"><span class="tip"></span>
              </div>
              <div class="password-box">
                <input type="password" name="re_pass" placeholder="确认密码" class="repass"><span class="tip"></span>
              </div>
              <!-- 图形验证码-->
              <!-- <div class="imgcode fix">
                <input type="text" name="imgcheck" placeholder="图形验证码" class="imgcheck"><img src="/assets/c/images/passport/imgcode.jpg" alt=""><span class="tip"></span>
              </div> -->
              <input type="button" value="注册典牧署" class="submit regsubmit">
              <p class="guide"> <span>点击「注册典牧署」按钮，即代表您同意 </span><a href="#">
                  《典牧署协议》
                  </a></p>
            </form>
          </div>
          <div class="login">
            <p class="error"><?php echo Yii::$app->session->getFlash('error') ?></p>
            <form action="<?php echo Yii::$app->request->hostInfo.'/c_login/login';?>" method="post">
              <div class="phone-box">
                <input type="number" name="username" placeholder="手机号" class="phone">
              </div>
              <div class="password-box">
                <input type="password" name="password" placeholder="密码" class="password">
                <?php if (isset($login_fail)): ?>
                  <span class="login-error" style="visibility: visible; left: 410px;"><?php echo $login_fail ?></span>
                <?php endif ?>
              </div>
              <input type="submit" value="立即登录" name="submit" class="submit">
              <label> 
                <input type="checkbox" class="remember"><span>记住我</span>
              </label>
              <label><a href="<?php echo Yii::$app->request->hostInfo.'/c_pass/index' ?>" class="forgetpass">忘记密码？</a></label>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
    <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
    <script src="/assets/c/js/edit-common.js"></script>
    <script src="http://cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
    <script src="/assets/c/js/passport.js"></script>
  </body>
</html>