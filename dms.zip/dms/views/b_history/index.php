  <link rel="stylesheet" href="/assets/b/css/history_trade.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="main">
    <p class="top-title">历史交易</p>
    <div class="tables">
      <table>
        <thead>
          <tr class="head">
            <th class="info">信息</th>
            <th>宰杀时间</th>
            <th>出肉量</th>
            <th>交易金额</th>
          </tr>
        </thead>
        <tbody id="list">
          <!-- <tr>
            <td>
              <div class="first"><img src="/assets/b/images/common/pig.png" alt="">
                <div class="pig-info">
                  <p class="tit">三元猪</p>
                  <p class="id">典牧署<span>JL0122016022202</span></p>
                  <p class="time">养殖时间<span>2016-07-22至2017-06-22</span></p>
                </div>
              </div>
            </td>
            <td>2017-06-22</td>
            <td> 
              <p class="weight">128.3kg</p>
            </td>
            <td> 
              <p class="money">¥4888.00</p>
            </td>
          </tr> -->
          
        </tbody>
      </table>
    </div>
    <div class="pagelist">

    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script type="text/javascript">
    $(function(){
      var total;

      query(1,10);


      $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
            query(page,size,total);
      }}); 

      function query(page,size){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size,
              dataType:"json",
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = '';
                $.each(data.data,function(index,item){
                  content+="<tr><td><div class='first'><img src=http://"+item.img_url+"><div class='pig-info'><p class='tit'>"+item.species+"</p><p class='id'>典牧署<span>"+item.name+"</span></p><p class='time'>养殖时间<span>"+item.start_time+"至"+item.end_time+"</span></p></div></div></td><td>"+item.kill_time+"</td><td> <p class='weight'>"+item.output+"kg</p></td><td> <p class='money'>¥"+item.all_price+"</p></td></tr>";
                })
                total = data.total;
                $("#list").html(content);
              }
          })
      }
    })
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
</body>