  <link rel="stylesheet" href="/assets/b/css/mess_center.css">
  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <div class="main">
    <p class="top-title">消息中心</p>
    <!-- <ul class="nav">
      <li class="active">全部消息</li>
      <li>典牧署消息</li>
      <li>物流消息</li>
    </ul> -->
    <div class="mess mess-all">
      <ul id="list">
        <!-- <li> 
          <p class="mess-group">物流消息: <span>你的猪肉有新动态</span></p><img src="/assets/b/images/common/pig.png" alt="">
          <p class="title">三元猪</p>
          <p class="id">典牧署身份证: <span>JL0122016022202</span></p>
          <p class="date">
            养殖时间: 
            <span class="from">2016-06-22</span> 至 <span class="to">2017-05-22</span>
          </p>
          <div class="clear"></div>
          <div class="more">
            <p class="time">2016-05-22 13:12:01</p><a href="#" class="detail">查看详情</a>
          </div>
        </li> -->
        
      </ul>
      <div class="pagelist"></div>
    </div>
  </div>
  <div id="footer"> 
    <div class="footer-main footer-bg">
      <div class="footer-content">
        <div class="footer-left"><a href="#" class="logo"><img src="/assets/c/images/common/logo-icon.png" alt="典牧署"></a>
          <p class="callus">0431-88885323</p>
          <p class="time">（周一至周日：9:00~18:00）</p>
        </div>
        <div class="footer-right">
          <ul class="aboutus">
            <li class="title">关于典牧署</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=1' ?>">平台简介</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=4' ?>">加入我们</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=5' ?>">联系我们</a></li>
          </ul>
          <ul class="users">
            <li class="title">用户服务</li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>">帮助中心</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=2' ?>">使用条款</a></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=3' ?>">隐私政策</a></li>
          </ul>
          <p class="wx"><img src="/assets/c/images/common/wx.png" alt=""><span>微信公众号</span></p>
        </div>
      </div>
    </div>
    <div class="copyright"><span>&copy;2017&nbsp;&nbsp;典牧署-长春市艾格瑞特信息科技有限责任公司</span></div>
  </div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    $(function(){

      query(1,10,function(total){
          $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
                query(page,size);
          }}); 
      });

      function query(page,size,callback){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size,
              dataType:"json",
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                if (data.total==0) {
                  alert('暂无消息提示!');
                }
                var content = '';
                $.each(data.data,function(index,item){
                  content+="<li> <p class='mess-group'><span>你的商品有新动态</span></p><img src=http://"+item.img_url+"><p class='title'>"+item.species+"</p><p class='id'>典牧署身份证: <span>"+item.name+"</span></p><p class='date'>"+item.content+"</p><div class='clear'></div><div class='more'><p class='time'>"+item.update_time+"</p></div></li>";
                })
                $("#list").html(content);
                callback && callback(data.total);
              },
              error:function(data){
                $('#query_hint').css("display","none");
                alert('请求失败');
              }
          })
      }
    })
    
  </script>
  <script src="/assets/c/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/common.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js"></script>
</body>