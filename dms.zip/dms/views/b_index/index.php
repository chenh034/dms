  <link rel="stylesheet" href="/assets/b/css/personal_date.css">
  <div class="main">
    <p class="top">个人资料</p>
    <div class="nav"><a href="javascript:;" class="active">养殖负责人</a><a href="javascript:;">养殖场</a><a href="javascript:;">账户设置</a></div>
    <div class="date both">
      <form action="<?php echo Yii::$app->request->hostInfo.'/b_index/contact' ?>" method="post">
        <label>
          <span class="left">姓名</span>
          <input type="text" placeholder="姓和名" name="name" class="text" value="<?php echo $data->name ?>">
          <span class="right">身份证号</span>
          <input type="text" name="id_number" class="id idcard" value="<?php echo $data->id_number ?>">
        </label>
        <label>
          <span>电话</span>
          <input type="tel" name="cellphone" class="tel phone" value="<?php echo $data->cellphone ?>">
          <span class="right">联系住址</span>
          <input type="text" name="account_place" class="address" value="<?php echo $data->account_place ?>">
        </label>
        <label>
          <span>邮箱</span>
          <input type="email" name="email" class="email" value="<?php echo $data->email ?>">
          <span class="right">备用电话</span>
          <input type="tel" name="bak_phone" class="tel-alts phone" value="<?php echo $data->bak_phone ?>">
        </label>
        <input type="submit" value="确认修改" class="confirm">
      </form>
    </div>
    <div class="date person-farm">
      <div class="address-add">
        <form action="<?php echo Yii::$app->request->hostInfo.'/b_index/farm' ?>" method="post">
          <!-- 后期需要引入脚本进行替换-->
          <div class="left">
            <label for="address">养殖场名
              <input type="text" name="farm_name" class="detail-address" value="<?php echo $data->farm_name ?>">
            </label>
            <div id="distpicker4">
              <label for="place">所在地区
                <select class="province" data-province="<?php echo $address['province'] ?>"></select>
                <select class="city" data-city="<?php echo $address['city'] ?>"></select>
                <select class="area" name="area_id" data-district="<?php echo $address['area'] ?>" ></select> 
              </label>
            </div>
            <label for="address">具体地址
              <input type="text" name="detail_place" class="detail-address" value="<?php echo $data->detail_place ?>">
            </label>
            <label for="home" class="homeamount">牧舍数量 
              <input type="number" name="dorm_num" class="amount num" value="<?php echo $data->dorm_num ?>">
              <span class="ge">个</span>
              <span class="baby">可养幼崽</span>
              <input type="text" name="product_num" class="amount num" value="<?php echo $data->product_num ?>">
              <span class="tou">头</span>
            </label>
          </div>
          <div class="right">
            <p class="title">设置饲料</p>
            <div class="set-food">
              <?php foreach ($forage as $key => $value): ?>
                <label>
                  <input type="checkbox" name="<?php echo $value['price'] ?>" value="<?php echo $value['forage_id'] ?>" class="food">
                  <span><?php echo $value['forage']['name'] ?></span>
                </label>
              <?php endforeach ?>
            </div>
          </div>
          <div class="clear"></div>
          <input value="确认修改" type="submit" class="submit save">
        </form>
      </div>
    </div>
    <div class="date edit-account">
      <p>养殖账户<span class="id"><?php echo $data->username ?></span></p>
      <p>账户密码<span class="key">·········</span><a href="#">更改密码请与平台管理员联系</a></p>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/distpicker.data.js"></script>
  <script src="/assets/c/js/distpicker.js"></script>
  <script src="/assets/c/js/main.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/js/validator.js"></script>
  <script>
    // 资料切换
    $('.nav a').click(function () {
        var index = $(this).index();
        $('.date').eq(index).show().siblings('.date').hide();
        $(this).addClass('active').siblings('a').removeClass('active');
    });
    
    $('.person-farm .food').change(function () {
        if ($(this).is(':checked')) {
            // $(this).parent().append(showSetPrice($(this).prop('name')));
            $(this).parent().append(showSetPrice($(this).val(),$(this).prop('name')));
        } else {
            if (!!$(this).siblings('.price')) {
                $(this).siblings('.price, .tip').remove();
            } else {
                return false;
            }
        }
    });
    
    function showSetPrice (name,price) {
        var fragment = document.createDocumentFragment();
        var oInput = document.createElement('input');
        oInput.className = 'price num';
        oInput.setAttribute('type','number');
        oInput.name = 'price['+name+']';
        oInput.value = price;
        
        fragment.appendChild(oInput);
    
        var oTip = document.createElement('span');
        oTip.className = 'tip';
        oTip.innerHTML = '元/kg';
        fragment.appendChild(oTip);
    
        return fragment;
    }
    
  </script>
</body>