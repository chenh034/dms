  <link rel="stylesheet" href="/assets/b/css/personal_date.css">
  <style type="text/css">
    .main .person-farm .address-add .right {
        width: 400px;
        float: none;
        margin: 5px auto;
        overflow: hidden;
    }
    .main .person-farm .address-add .right .set-food {
        width: 400px;
        float: none;
        display: inline-block;
    }
    .main .person-farm .address-add .right .set-food span{
        display: inline-block;
        width: 100px;
    }
    .main .person-farm .address-add .right .set-food label .price{
        margin-left: 10px;
    }
    .main .person-farm .address-add form .submit {
        float: right;
        margin-right: 200px;
    }
  </style>
  <div class="main">
    <p class="top">设置饲料价格</p>
    <!-- <div class="nav"><a href="javascript:;" class="active">养殖负责人</a><a href="javascript:;">养殖场</a><a href="javascript:;">账户设置</a></div> -->
    
    <div class="date person-farm" style="display: block;">
      <div class="address-add">
        <form action="<?php echo Yii::$app->request->hostInfo.'/b_index/forage' ?>" method="post">
          
          <div class="right">
            <!-- <p class="title">设置饲料</p> -->
            <div class="set-food">
              <?php foreach ($forage as $key => $value): ?>
                <label>
                  <!-- <input type="checkbox" name="<?php echo $value['price'] ?>" value="<?php echo $value['forage_id'] ?>" class="food"> -->
                  <span><?php echo $value['forage']['name'] ?></span>
                  <input class="price num" type="number" name="price[<?php echo $value['forage_id'] ?>]" style="border-color: rgb(238, 238, 238);" value="<?php echo $value['price'] ?>">
                  <i>&nbsp;&nbsp;&nbsp;元/kg</i>
                </label>
              <?php endforeach ?>
            </div>
          </div>
          <div class="clear"></div>
          <input value="确认修改" type="submit" class="submit save">
        </form>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script src="/assets/c/js/distpicker.data.js"></script>
  <script src="/assets/c/js/distpicker.js"></script>
  <script src="/assets/c/js/main.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/js/validator.js"></script>
  <script>
    
    $('.person-farm .food').change(function () {
        if ($(this).is(':checked')) {
            // $(this).parent().append(showSetPrice($(this).prop('name')));
            $(this).parent().append(showSetPrice($(this).val(),$(this).prop('name')));
        } else {
            if (!!$(this).siblings('.price')) {
                $(this).siblings('.price, .tip').remove();
            } else {
                return false;
            }
        }
    });
    
    function showSetPrice (name,price) {
        var fragment = document.createDocumentFragment();
        var oInput = document.createElement('input');
        oInput.className = 'price num';
        oInput.type = 'number';
        oInput.name = 'price['+name+']';
        oInput.value = price;
        
        fragment.appendChild(oInput);
    
        var oTip = document.createElement('span');
        oTip.className = 'tip';
        oTip.innerHTML = '元/kg';
        fragment.appendChild(oTip);
    
        return fragment;
    }
    
  </script>
</body>