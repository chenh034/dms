  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
  .query_hint{
      display: none;
      border:5px solid #939393;
      width:250px;
      height:50px;
      line-height:55px;
      padding:0 20px;
      position:fixed;
      left:50%;
      margin-left:-140px;
      top:50%;
      margin-top:-40px;
      font-size:15px;
      color:#333;
      font-weight:bold;
      text-align:center;
      background-color:#f9f9f9;
  }
  .query_hint img{position:relative;top:10px;left:-8px;}
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <form action="<?php echo Yii::$app->request->hostInfo.'/b_wait/batconfirm' ?>" method="post">
        <div class="position">
          所在位置：<a href="./pigs_toadopt.html">待饲养</a>
           
        </div>
        <div class="tab-main pigs-toadopt">
        <!-- <a href="javascript:;" class="pigs-adopt save">批量饲养</a> -->
        <input type="submit" class="pigs-adopt save" value="批量饲养">
          <div class="clear"></div>
          <table>
            <thead>
              <tr>
                <th class="checkbox allchecked"> 
                  <label for="allchecked">
                    <input type="checkbox" name="allchecked">
                    全选
                  </label>
                </th>
                <th class="img">图片</th>
                <th class="kind">物种</th>
                <th class="id">典牧署身份证</th>
                <th class="weight">养殖属性</th>
                <th class="price">总价</th>
                <th class="output">所属人数</th>
                <th class="operate">操作</th>
              </tr>
            </thead>
            <tbody id="list">
              
            </tbody>
          </table>
          <div class="pagelist"></div>
        </div>
              <div class="modal-mark"></div>
              <div class="modal-wrap">
                <div class="modal"><span class="close"></span>
                  <div class="modal-content">
                    <p class="content">是否确认饲养?</p>
                    <p class="desc">确认饲养后请在“养殖中”栏目中分配猪舍</p>
                    <hr><a href="javascript:;" class="save">确认饲养</a><a href="javascript:;" class="cancel">取消</a>
                  </div>
                </div>
              </div>
      </div>
    </form>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">     </script>
  <script src="/assets/b/js/index.js"></script>
  <script>
    $(function () {
      $('.modal .save').click(function () {
        console.log($(this).attr('title'));
        window.location.href = 'confirm?id='+$(this).attr('title');
      });

      query(1,10,function(total){
          $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
              query(page,size);
          }});
      });

      function query(page,size,callback){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size,
              dataType:'json',
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
            
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = '';
                $.each(data.data,function(index,item){
                  content+="<tr><td class='select'><input type='checkbox' name='select[]' value="+item.id+"></td><td class='img'>"
                  +"<img src=http://"+item.img_url+"></td><td class='kind'>"
                  +item.species.name
                  +"</td><td class='id'>"
                  +item.name
                  +"</td><td class='weight'>"
                  +item.type+"</td><td class='price'>¥"
                  +item.total_price+"</td><td class='output'>"
                  +item.belong
                  +"</td><td><a href='javascript:;' title="+item.id+" class='adopt'>饲养</a></td></tr>"
                })
                
                $("#list").html(content);
                callback && callback(data.total);
              },
              error:function(data){
                 alert('请求超时');
                 $('#query_hint').css("display","none");
              }
          })
      }
    
    });
    
  </script>
</body>