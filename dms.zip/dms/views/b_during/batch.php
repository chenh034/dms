  <link rel="stylesheet" href="/assets/b/css/many_update.css">
  <div class="main">
    <form action="<?php echo Yii::$app->request->hostInfo?>/b_during/batch" method="post" class="many-update">
    <div class="select"><span>按牧舍筛选</span>
      <select>
        <option value="1牧舍">1牧舍</option>
        <option value="2牧舍">2牧舍</option>
      </select><span>按物种选择</span>
      <select>
        <option value="三元猪">三元猪</option>
        <option value="黑山猪">黑山猪</option>
      </select>
      <div class="date" style="width: 250px;"><span class="time">更新时间</span>
        <input type="text" name="update_time" id="start" class="laydate-icon">
      </div>
    </div>
    
      <table>
        <tr class="head">
          <th class="a">序号</th>
          <th class="b">牧舍</th>
          <th class="b">物种</th>
          <th class="c">典牧署身份证</th>
          <th>体重量（kg）</th>
          <th>进食量（kg）</th>
          <th>活动量（h）</th>
          <th>睡眠时间（h）</th>
          <th>体脂率（%）</th>
        </tr>
        <?php foreach ($data as $key => $value): ?>
        <tr>
          <td><?php echo $key+1 ?></td>
          <td><?php echo $value['dorm'] ?></td>
          <td><?php echo $value['species']['name'] ?></td>
          <td><?php echo $value['name'] ?></td>
          <td> 
            <input type="text" name="info[<?php echo $key+1 ?>][id]" value="<?php echo $value['id'] ?>" style="display: none;">
            <input type="text" name="info[<?php echo $key+1 ?>][now_weight]" value="<?php echo $value['now_weight'] ?>" class="num">
          </td>
          <td>
            <input type="text" name="info[<?php echo $key+1 ?>][food_intake]" value="<?php echo $value['food_intake'] ?>" class="num">
          </td>
          <td>
            <input type="text" name="info[<?php echo $key+1 ?>][activity]" value="<?php echo $value['activity'] ?>" class="num">
          </td>
          <td>
            <input type="text" name="info[<?php echo $key+1 ?>][sleep]" value="<?php echo $value['sleep'] ?>" class="num">
          </td>
          <td>
            <input type="text" name="info[<?php echo $key+1 ?>][fat_ratio]" value="<?php echo $value['fat_ratio'] ?>" class="num">
          </td>
        </tr>
        <?php endforeach ?>
      </table>
      <input type="submit" value="确认提交" class="submit save">
      <div class="clear"></div>
    </form>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
  <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/validator.js"></script>
  <script>
    var start = {
    	elem: '#start',
    	format: 'YYYY/MM/DD',
    	max: laydate.now(), //设定最大日期为当前日期
    	min: '2016-06-16', //最小日期
    	istime: true,
    	istoday: true,
    	choose: function(datas){
    		console.log(datas);
    	}
    };
    laydate(start);
    
  </script>
</body>