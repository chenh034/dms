  <link rel="stylesheet" href="/assets/b/css/index.css">
  <link rel="stylesheet" href="/assets/b/css/pigs_adopting_output.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs_adopting.html">养殖中</a> 
        <a href="./pigs_adopting_output.html">出肉详情</a>
                     
      </div>
      <p><?php echo Yii::$app->session->getFlash('result') ?></p>
      <div class="tab-main pigs-adopting">
        <!-- 填写出肉信息-->
        <div class="output-detail">
          <form action="<?php echo Yii::$app->request->hostInfo.'/b_during/result?id='.$product['id'];?>" method="post">           
            <div class="curhotel">
              <div class="pig-hotel">
                <p class="title"><?php echo $product['species']['name'] ?></p>
                <p class="cur-hotel">牧舍： <span><?php echo $product['dorm'] ?></span></p>
                <p class="id">编号: <span><?php echo $product['name'] ?></span></p>
              </div>
            </div>
            <table class="output-write">
              <thead>
                <th class="kind">肉种</th>
                <th class="number">数量</th>
                <th class="unit">单位</th>
                <th class="weight">每单位重量(kg)</th>
                <th class="allweight">共计重量</th>
              </thead>
              <tbody>
                <tr>
                  <td class="kind">
                    <input type="text" name="kind[]">
                  </td>
                  <td class="number">
                    <input type="number" name="number[]">
                  </td>
                  <td class="unit">
                    <select name="unit[]">
                      <option value="盒">盒</option>
                      <option value="个">个</option>
                    </select>
                  </td>
                  <td class="weight">
                    <input type="text" name="weight[]">
                  </td>
                  <td class="allweight"></td>
                </tr>
                <tr>
                  <td class="kind">
                    <input type="text" name="kind[]">
                  </td>
                  <td class="number">
                    <input type="number" name="number[]">
                  </td>
                  <td class="unit">
                    <select name="unit[]">
                      <option value="盒">盒</option>
                      <option value="个">个</option>
                    </select>
                  </td>
                  <td class="weight">
                    <input type="text" name="weight[]">
                  </td>
                  <td class="allweight"></td>
                </tr>
                <tr>
                  <td class="kind">
                    <input type="text" name="kind[]">
                  </td>
                  <td class="number">
                    <input type="number" name="number[]">
                  </td>
                  <td class="unit">
                    <select name="unit[]">
                      <option value="盒">盒</option>
                      <option value="个">个</option>
                    </select>
                  </td>
                  <td class="weight">
                    <input type="text" name="weight[]">
                  </td>
                  <td class="allweight"></td>
                </tr>
                <tr>
                  <td class="kind">
                    <input type="text" name="kind[]">
                  </td>
                  <td class="number">
                    <input type="number" name="number[]">
                  </td>
                  <td class="unit">
                    <select name="unit[]">
                      <option value="盒">盒</option>
                      <option value="个">个</option>
                    </select>
                  </td>
                  <td class="weight">
                    <input type="text" name="weight[]">
                  </td>
                  <td class="allweight"></td>
                </tr>
              </tbody>
            </table>
            <div class="clear"></div><a href="javascript:;" class="add-newline">+ 添加新列</a>
            <div class="clear"></div>
            <p class="allmoney">
            共计：<span>0.00kg</span> <input id="output" type="text" name="output" value="0" style="display: none;">
            </p>
            <div class="clear"></div>
            <input type="submit" value="确认提交" class="submit save">
            <div class="clear"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/js/pigs_adopting_output.js"></script>
</body>