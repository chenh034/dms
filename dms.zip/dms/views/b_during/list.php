  <link rel="stylesheet" href="/assets/b/public/lib/pages/paging.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <style type="text/css">
  .query_hint{
      display: none;
      border:5px solid #939393;
      width:250px;
      height:50px;
      line-height:55px;
      padding:0 20px;
      position:fixed;
      left:50%;
      margin-left:-140px;
      top:50%;
      margin-top:-40px;
      font-size:15px;
      color:#333;
      font-weight:bold;
      text-align:center;
      background-color:#f9f9f9;
  }
  .query_hint img{position:relative;top:10px;left:-8px;}
  .main .right .tab-main table tbody td .message {
       display: inline; 
      -moz-box-sizing: border-box;
       box-sizing: border-box; 
       border: none; 
       color: #ea5300;
       border-radius: 0px; 
       line-height:0; 
       text-align: center; 
  }
  </style>
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="#">养殖中</a>
                     
      </div>
      <div class="tab-main pigs-adopting">
      <form action=<?php Yii::$app->request->hostInfo;?>/b_during/tobatch method="post">
        <div class="top"><a href="message?status=t" class="allTips">今日提醒</a><a href="message?status=h" class="hisTips">历史提醒</a><a href="<?php Yii::$app->request->hostInfo;?>/b_dorm/list" class="allTips" style="margin-left: 25px;">管理牧舍</a><input type="submit" class="updatemany save" value="批量更新信息"></div>
        <?php echo Yii::$app->session->getFlash('status'); ?>
        <table>
          <thead>
            <tr>
              <th class="checkbox allchecked"> 
                <label for="allchecked">
                  <input type="checkbox" name="allchecked">
                  全选
                </label>
              </th>
              <th class="hotel">牧舍 </th>
              <th class="kind">物种</th>
              <th class="id">典牧署身份证</th>
              <th class="update-date">最近更新 </th>
              <th class="tips">消息提醒</th>
              <th class="operate">操作</th>
            </tr>
          </thead>
          <tbody id="list">
            
          </tbody>
        </table>
        <div class="pagelist"></div>
      </div>
      </form>
            <div class="modal-mark"></div>
            <div class="modal-wrap">
              <div class="modal"><span class="close"></span>
                <div class="modal-content">
                  <p class="content">是否确认宰杀?</p>
                  <p class="desc">确认宰杀后将填写出肉信息</p>
                  <hr><a href="javascript:;" class="save">确认宰杀</a><a href="javascript:;" class="cancel">取消</a>
                </div>
              </div>
            </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <div id="query_hint" class="query_hint">
      正在查询，请稍等．．．
  </div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <script src="/assets/b/js/index.js"></script>
  <script src="/assets/b/public/lib/pages/query.js"></script>
  <script src="/assets/b/public/lib/pages/paging.js">   </script>
  <script>
    $(function () {
      $('.modal .save').click(function () {
        console.log($(this).attr('title'));
        window.location.href = 'toresult?id='+$(this).attr('title');
      });

      query(1,10,function(total){
        $('.pagelist').Paging({pagesize:10,count:total,toolbar: true,callback:function(page,size,count){
            query(page,size);
        }});
      });


      function query(page,size,callback){
          $.ajax({
              type:'post',
              url:"json?page="+page+"&size="+size,
              dataType:'json',
              beforeSend:function() {  
                 $('#query_hint').css("display","block");
            
              },
              complete:function(){
                 $('#query_hint').css("display","none");
              },
              success:function(data){
                var content = "";
                var message = '';

                $.each(data.data,function(index,item){
                  message = '';
                  if (item.message!=null) {
                    $.each(item.message,function(i,msg){
                      message+="<span><a class='message' href=../b_message/detail?id="+msg.id+">"+msg.content+"</a></span>";
                    })
                  }
                  content+="<tr><td class='select'><input type='checkbox' name='select[]' value="+item.id+"></td><td class='hotel'><a target='_blank' href=assigndorm?id="+item.id+" class='add-hotel'>"
                    +item.dorm
                    +"</a></td><td class='kind'>"
                    +item.species.name
                    +"</td><td class='id'>"
                    +item.name
                    +"</td><td class='update-date'>"
                    +item.update_time
                    +"</td><td class='tips'>"
                    +message
                    +"</td><td><a href=toupdate?id="+item.id+" class='update'>更新信息</a><a href='javascript:;' title="+item.id+" class='kill'>宰杀</a></td></tr>";
                })
                // setCookie('during_total',data.total);
                callback && callback(data.total);
                $("#list").html(content);
              },
              error:function(data){
                 alert('请求超时');  
                 $('#query_hint').css("display","none");
              }
          })
      }
    
    });
    
  </script>
</body>