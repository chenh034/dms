  <link rel="stylesheet" href="/assets/b/css/pigs_add.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">所在位置：<a href="#">牧舍管理</a><a href="#">分配牧舍</a></div>
      <div class="tab-main pigs-repo">

        <div class="newpigs-add">
          <?php echo Yii::$app->session->getFlash('status') ?>
          <form action="<?php echo Yii::$app->request->hostInfo.'/b_during/assigndorm?id='.$product_id;?>" name="pigs-edit" method="post" enctype="multipart/form-data">
            
            <div class="basic-mess">               
              <div class="mess">
                <p class="number">选择牧舍
                  <!-- <span>JL012</span> -->
                  <select name="dorm_id">
                    <?php foreach ($dorm as $key => $value): ?>
                      <option value="<?php echo $value['id'] ?>"><?php echo $value['name'] ?></option>
                    <?php endforeach ?>
                  </select>
                </p>
              </div>
              
              <div class="clear"></div>
              <hr class="gap">
            </div>
            <input type="submit" value="确认提交" class="submit save">
            <div class="clear"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
  <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/pigs_add1.js"></script>
  <script src="/assets/b/js/validator2.js"></script>
</body>