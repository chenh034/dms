  <link rel="stylesheet" href="/assets/b/css/today_remind.css">
  <div class="main"><span><?php echo Yii::$app->session->getFlash('date_message') ?>消息</span><a href="javascript:;">导出PDF</a>
    <div class="clear"></div>
    <table>
      <tr class="head">
        <th class="a">序号</th>
        <th class="b">牧舍</th>
        <th class="c">物种</th>
        <th class="d">典牧署身份证</th>
        <th>消息提醒明细</th>
      </tr>
      <?php foreach ($message as $key => $value): ?>
        <tr>
          <td><?php echo $key+1 ?></td>
          <td><?php echo $value['product']['dorm'] ?></td>
          <td><?php echo $value['species'] ?></td>
          <td><?php echo $value['product']['name'] ?></td>
          <td>
            <?php if ($value['forage']): ?>
              饲料改动（<?php echo $value['forage'] ?>）；
            <?php endif ?>
            <?php if ($value['feed_time']): ?>
              养殖时间改动（至 <?php echo $value['feed_time'] ?>）；
            <?php endif ?>
            <?php if ($value['kill_time']): ?>
              宰杀提醒（ <?php echo $value['kill_time'] ?> 宰杀）
            <?php endif ?>
          </td>
          <!-- <td>饲料改动（1号饲料）；养殖时间改动（至2017-07-22）；宰杀提醒（2017-07-22宰杀）</td> -->
        </tr>
      <?php endforeach ?>
  
    </table>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
</body>