  <link rel="stylesheet" href="/assets/b/css/pigs_adopting_update.css">
  <link rel="stylesheet" href="/assets/b/css/index.css">
  <div class="main">
    <div class="left">
      <ul class="tabs">
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>">库存幼崽</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_wait/list' ?>">待饲养</a></li>
        <li class="active"> <a href="<?php echo Yii::$app->request->hostInfo.'/b_during/list' ?>">养殖中</a></li>
        <li> <a href="<?php echo Yii::$app->request->hostInfo.'/b_killed/list' ?>">已宰杀</a></li>
      </ul>
    </div>
    <div class="right">
      <div class="position">
        所在位置：<a href="./pigs_adopting.html">养殖中</a> 
        <a href="./pigs_adopting_update.html">更新信息</a>
                     
      </div>
      <div class="tab-main pigs-adopting">
        <!-- 更新信息-->
        <?php echo Yii::$app->session->getFlash('status') ?>
        <div class="update-mess">
          <form action="<?php echo Yii::$app->request->hostInfo.'/b_during/update?id='.$product['id'];?>" method="post" name="update-mess">
            <div class="curhotel">
              <div class="pig-hotel">
                <p class="title">三元猪</p>
                <p class="cur-hotel">牧舍： <span><?php echo $product['dorm'];?></span></p>
                <p class="id">编号: <span><?php echo $product['name'];?></span></p>
              </div><a href="#" class="edit-hotel">更改牧舍</a>
            </div>
            <div class="more-mess">
              <div>更改时间
                <input type="text" name="update_time" id="date" class="laydate-icon" value="<?php echo date('Y/m/d',$product['update_time']) ?>">
              </div>
              <p>体重量
                <input type="text" name="now_weight" class="num" value="<?php echo $product['now_weight'] ?>"><span>kg</span>
              </p>
              <p>进食量
                <input type="text" name="food_intake" class="num" value="<?php echo $product['food_intake'] ?>"><span>kg</span>
              </p>
              <p>活动量
                <input type="text" name="activity" class="num" value="<?php echo $product['activity'] ?>"><span>h</span>
              </p>
              <p>睡眠量
                <input type="text" name="sleep" class="num" value="<?php echo $product['sleep'] ?>"><span>h</span>
              </p>
              <p>体脂率
                <input type="text" name="fat_ratio" class="num" value="<?php echo $product['fat_ratio'] ?>"><span>%</span>
              </p>
            </div>
            <div class="advice">
              <p>养殖建议</p>
              <textarea name="advice"> <?php echo $product['advice'] ?> </textarea>
            </div>
            <input type="submit" value="确认提交" class="submit save">
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer">&copy;2017  典牧署-长春市艾格瑞特信息科技有限责任公司</div>
  <script src="/assets/b/public/lib/jquery-1.9.1.min.js"></script>
  <script>
    // 头部下拉
    $('.login a').click(function (ev) {
      $('.login ul').toggle();
    });
    
  </script>
  <!-- 需要引入日期插件-->
  <script src="/assets/b/public/lib/laydate/laydate.js"></script>
  <script src="/assets/b/js/index.js"></script>
  <script src="/assets/b/js/validator.js"></script>
  <script>
    // 养殖中 -> 更改信息
    var editDate = {
      elem: '#date',
      format: 'YYYY/MM/DD',
      min: '2015-12-31', //设定最小日期为当前日期
      max: '2099-06-16', //最大日期
      istime: false,
      istoday: true,
      choose: function(datas){
        console.log(datas);
      }
    };
    
    laydate(editDate);
    
  </script>
</body>