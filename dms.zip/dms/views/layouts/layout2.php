<!DOCTYPE html><!--[if IE 8]><!--> <html class="ie8"> <!--<![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <title>典牧署</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="/assets/b/public/reset.css">
  <link rel="stylesheet" href="/assets/b/css/common.css">
  <link rel="stylesheet" href="/assets/b/css/mark.css">
</head>
<body>
  <div class="header-wrap">
    <div class="header-tbg"> 
      <div class="header-top">
        <p class="call">客服电话 ：0431-88885323<span>(周一到周日：9:00 - 18:00)</span></p>
        <ul class="nav">
          <li> <a target="_blank" href="<?php echo Yii::$app->request->hostInfo ?>" target="_blank">典牧署官网</a></li>
          <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question'; ?>" target="_blank">帮助中心</a></li>
          <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/infos?id=6'; ?>">养殖条约</a></li>
        </ul>
      </div>
    </div>
    <div class="header-bbg">
      <div class="header-bottom fix"><a href="<?php echo Yii::$app->request->hostInfo.'/b_product/list' ?>" class="logo"> <img src="/assets/b/images/common/logo.png" alt="典牧署"></a>
        <div class="login">
          <p>养殖户 : <a href="javascript:;"><?php echo Yii::$app->session['farm_user']['username'] ?><span class="down"></span></a></p>
          <ul>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/b_message/index'; ?>">消息中心</a><span>(<?php echo Yii::$app->session['farm_user']['message_count'] ?>)</span></li>
            <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/b_history/index'; ?>">历史交易</a></li>
            <li><a href="<?php echo Yii::$app->request->hostInfo.'/b_index/index'; ?>">个人资料</a></li>
            <li><a href="<?php echo Yii::$app->request->hostInfo.'/b_login/logout'; ?>">退出 </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

<?php echo $content ?>

