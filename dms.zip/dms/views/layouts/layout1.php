<!DOCTYPE html><!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<!--[if IE]>    <html class="ie8 woldie" lang="en"> <![endif]--> 
<head>
  <title>典牧署</title>
  <meta charset="utf-8">
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
  <link rel="stylesheet" href="/assets/c/public/fonts/reset.css">
  <link rel="stylesheet" href="/assets/c/public/fonts/iconfont.css">
  <link rel="stylesheet" href="/assets/c/css/common.css">
</head>
<body>
<div id="header-top">
    <div class="header-main"> 
      <ul class="header-info">
        <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring' ?>"><i class="iconfont icon-muchang"></i> 我的牧业</a></li>
        <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_result/index' ?>"><i class="iconfont icon-rou"></i> 养殖收获</a></li>
      </ul>
      <ul class="login">
        <?php if (isset(Yii::$app->session['font_user'])): ?>
          <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_message/index' ?>" class="mess"><i class="iconfont icon-youxiang"></i> 消息中心</a></li>
          <li class="person"><a id="person-center" href="javascript:;" class="person-center"><img style="width: 35px;height: 35px;border-radius: 18px;" src="<?php echo Yii::$app->request->cookies->get('head_url') ?>" alt="个人中心"></a>
            <ul class="person-data">
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_user/index'; ?>">个人资料</a></li>
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_user/index'; ?>">收货地址</a></li>
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_mine/toduring'; ?>">我的牧业</a></li>
              <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_result/index'; ?>">养殖收获</a></li>
              <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_login/logout'; ?>">退出 </a></li>
            </ul>
          </li>
        <?php else: ?>
          <li><a href="<?php echo Yii::$app->request->hostInfo.'/c_login/tologin'; ?>" class="mess"><i class="iconfont icon-shouji"></i> 登陆</a></li>
        <?php endif ?>
        
      </ul>
    </div>
  </div>
  <!-- 导航部分			-->
  <div id="header-menu" class="fix"><a href="<?php echo Yii::$app->request->hostInfo; ?>" class="logo"> <img src="/assets/c/images/common/logo.png" alt="典牧署"></a>
    <div class="search"><i class="iconfont icon-sousuo"></i>
      <form action="<?php echo Yii::$app->request->hostInfo.'/c_index/searchlist' ?>">
        <?php if (isset($_GET['keyword'])): ?>
          <input type="text" name="keyword" value="<?php echo $_GET['keyword'] ?>" placeholder="请输入相关商品信息......" class="search-input">
        <?php else: ?>
          <input type="text" name="keyword" placeholder="请输入相关商品信息......" class="search-input">
        <?php endif ?>
        <input type="submit" value="搜索" class="submit">
      </form>
    </div>
    <ul class="nav">
      <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/articlelist' ?>"><span class="title">畜牧手册</span><br><span class="detail">啥叫一头好猪</span></a></li>
      <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/commentlist' ?>"><span class="title">养殖者说</span><br><span class="detail">过来人的说法</span></a></li>
      <li><a target="_blank" href="<?php echo Yii::$app->request->hostInfo.'/c_index/question' ?>"><span class="title">帮助中心</span><br><span class="detail">解答你的疑问</span></a></li>
    </ul>
  </div>

<?php echo $content; ?>
