<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use crazyfd\qiniu\Qiniu;
use app\models\ProductComment;
use app\models\CommentPic;
use app\models\Product;
use app\models\Order;
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_commentController extends Controller
{
	public function actionIndex(){
		return $this->redirect(Yii::$app->request->hostInfo.'/c_result/index');
	}

	public function actionAdd(){
		// print_r($_FILES);die();
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['user_id'] = $user_id;

			if (isset($_FILES['file'])) {
				$file = $this->uploadPics();
			}
            
            $transaction = Yii::$app->db->beginTransaction();
			try{

			    $ProductComment = new ProductComment;
			    $add_status = $ProductComment->addComment($post);

			    $Product = Product::findOne($post['product_id']);
			    $Product->status = 7;
			    $Product->save();

			    $Order = Order::findOne($post['order_id']);
			    $Order->status = Order::COMMENT;
			    $Order->save();

			    if (isset($file)) {
			    	foreach ($file as $key => $value) {
			    		$file[$key]['comment_id'] = $add_status['data']['comment_id'];
			    	}
			    	$pic_status = Yii::$app->db->createCommand()
			             ->batchInsert(CommentPic::tableName(),['img_url','comment_id'],$file)
			             ->execute();
			        if (!$pic_status) {
			        	throw new \Exception('图片添加失败');
			        }
			    }

			    if($add_status['code'] == 1){
			    	throw new \Exception('评论添加失败！');
			    }
			    
			    $transaction->commit(); 
			}catch (\Exception $e){
			    $transaction->rollBack();
			    $err = [
			        'code' => $e->getCode(),
			        'msg'  => $e->getMessage(),
			        'file'    => $e->getFile(),
			        'line'   => $e->getLine()
			    ];
				print_r(['code'=>1,'data'=>$err['msg']]);
				return;
			}
			return $this->render('tip');

		}
	}

	private function uploadPics(){
		$file = [];
		$qiniu = new Qiniu(ProductComment::AK, ProductComment::SK, ProductComment::DOMAIN, ProductComment::BUCKET);
		foreach ($_FILES['file']['tmp_name'] as $key => $value) {
			if ($_FILES['file']['error'][$key] > 0) {
				return false;
			}
			$k = uniqid();
            $qiniu->uploadFile($value, $k);
            $file[$key]['img_url'] = $qiniu->getLink($k);
		}

        return $file;
	}
}