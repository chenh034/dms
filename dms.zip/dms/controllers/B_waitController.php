<?php

namespace app\controllers;

use Yii;
use app\models\Product;
use yii\web\Controller;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_waitController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}
	
	public function actionIndex(){

	}

	public function actionConfirm($id){
		$id = (int)$id;
		$Product = Product::findOne($id);
		if (!is_null($Product)) {
			$Product->start_time = date('Y-m-d',time());
			$Product->end_time = date('Y-m-d',time()+$Product->feed_time*24*3600);
			$Product->status = 3;
			if ($Product->save()) {
				return $this->renderPartial('tip');
			}else{
				return $this->renderPartial('tip2');
			}
		}

	}

	public function actionBatconfirm(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			foreach ($post['select'] as $key => $value) {
				$Product = Product::findOne($value);
				if (!is_null($Product)) {
					$Product->start_time = date('Y-m-d',time());
					$Product->end_time = date('Y-m-d',time()+$Product->feed_time*24*3600);
					$Product->status = 3;
					$Product->save();
				}
			}
			return $this->renderPartial('tip');
		}
	}

	public function actionList(){
		$this->layout = 'layout2';
		return $this->render("list");
	}


	public function actionJson($page,$size){
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		$size = (int)$size;
		$page = (int)$page;
		$offset = $size*($page-1);
        
        $total = Product::find()->where(['is_ok'=>1,'status'=>2])->count();
		$data = Product::find()
		        ->select(['id','species_id','type','name','foundation_price','all_price','feed_price','start_time','end_time','img_url'])
		        ->with(['species'=>function($query){
	                	$query->select('id,name');
	                },'setmeal'=>function($query){
	                	$query->where(['buy'=>1]);
	                }]
                )
		        ->orderBy('id desc')
		        ->offset($offset)
		        ->limit($size)
		        ->where(['farm_id'=>$farm_id,'is_ok'=>1,'status'=>2])
		        ->asArray()
		        ->all();

		foreach ($data as $key => $value) {
			if ($value['type']==1) {
				// $days = (strtotime($value['end_time'])-strtotime($value['start_time']))/(3600*24);
				// $data[$key]['total_price'] = $value['foundation_price']+$days*$value['feed_price'];
				$data[$key]['total_price'] = $value['all_price'];
			}else if ($value['type']==2) {
				$total_price = 0;
				foreach ($value['setmeal'] as $k => $v) {
					$total_price += (int)$v['price'];
				}
				$data[$key]['total_price'] = $total_price;
			}

			if ($value['type']==1) {
				$data[$key]['type'] = '认养';
				$data[$key]['belong'] = 1;
			}else if ($value['type']==2) {
				$data[$key]['type'] = '共筹';
				$data[$key]['belong'] = sizeof($data[$key]['setmeal']);
			}
		}
        
        $Info['total'] = $total;
        $Info['data'] = $data;
        
		print_r(json_encode($Info));

	}
}