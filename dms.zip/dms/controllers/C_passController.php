<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FontUser;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_passController extends Controller
{
	public function actionIndex(){
		return $this->renderPartial('index');
	}

	public function actionCheck($phone){
        $phone = trim($phone);
        $FontUser = FontUser::find()->where(['username'=>$phone])->one();
        if (is_null($FontUser)) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1]));
        }
	}

	public function actionCheckcode(){
		if (Yii::$app->request->isPost) {
			$cache = Yii::$app->cache;
			$post = Yii::$app->request->post();
			if ($post['code']==$cache->get($post['phone'])){
				print_r(json_encode(['code'=>0]));
			}else{
				print_r(json_encode(['code'=>1]));
			}
		}
	}

	public function actionTochange(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$cache = Yii::$app->cache;
			if ($cache->get($post['phone'])==$post['code']) {
				return $this->renderPartial('change',['phone'=>$post['phone']]);
			}else{
				return $this->renderPartial('index',['check_fail'=>1]);
			}
		}
	}

	public function actionChange(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$username = $post['phone'];
			$password = md5($post['password']);
			$FontUser = FontUser::find()->where(['username'=>$username])->one();
			$FontUser->password = $password;
			if ($FontUser->save()) {
				return $this->renderPartial('tip');
			}
		}
	}

	public function actionSendmessage(){
		if (Yii::$app->request->isPost) {
			$cache = Yii::$app->cache;
			$post = Yii::$app->request->post();
			$code = trim($post['code']);
			$phone = trim($post['phone']);

			$cache->set($phone,$code,180);
			$url = FontUser::$url.FontUser::$sid.'/Messages/templateSMS?sig='.strtoupper(md5(FontUser::$sid.FontUser::$token.date('YmdHis')));
			$data = ['templateSMS'=>
			            [
			             'appId'=>FontUser::$appId,
	                     'param'=>$code,
	                     'templateId'=>FontUser::$templateId2,
	                     'to'=>$phone
	                    ]
			        ];
			$header1 = 'Authorization:'.base64_encode(FontUser::$sid.':'.date('YmdHis'));
			$header = array('Content-type:application/json;charset=utf-8',$header1,'Accept:application/json');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_URL, $url);
			if(strtolower(substr($url,0,5)) == 'https'){
				//$location = 'D:/Program Files/wamp/wamp/www/example/call_center/';	//证书绝对地址
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);	//信任任何证书;
				//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);	//只信任颁发的证书;
				//curl_setopt($ch, CURLOPT_CAINFO, $location.'call_center.cer');	//颁发的受信任的证书
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);	//检查证书中是否设置域名,0不验证;
			}
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			$output = curl_exec($ch);
			$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($status != 200){
				$output = (object)array(
					'code' => $status,
					'errno' => curl_errno($ch),
					'error' => curl_error($ch)
				);
				$output = json_encode($output);
			}else{
				$output = array(
                     'code'=>0
				);
				$output = json_encode($output);
			}
			curl_close($ch);
			print_r($output);
		}
	}

}