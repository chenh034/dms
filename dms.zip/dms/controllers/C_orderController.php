<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Order;
use app\models\OrderRaised;
use app\models\OrderAdopt;
use app\models\Product;
use app\models\ForageOffer;
use app\models\ReceiptAddress;
use app\models\Province;
use app\models\City;
use app\models\Setmeal;
use app\models\Pay;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_orderController extends Controller
{
	public function behaviors(){
         return [
            'font' => [
                'class' => 'app\component\FontFilter'//调用过滤器
            ]
        ];
    }
    
	public function actionAdd(){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
		$tr = Yii::$app->db->beginTransaction();
		try{
			if (Yii::$app->request->isPost) {
				$post = Yii::$app->request->post();
				$Order = new Order;
				$Order->scenario = 'add';
	            
	            $Order->user_id = $user_id;
	            $Order->product_id = $post['product_id'];
	            $Order->product_type = $post['product_type'];
	            $Order->status = Order::CREATEORDER;
	            $Order->createtime = time();
	            if (!$Order->save()) {
	            	throw new \Exception("订单创建失败");
	            }
	            $order_id = $Order->id;

	            if ($post['product_type'] == 1) {
	            	$this->adopt($post,$order_id);
	            }else if($post['product_type'] == 2){
                    $this->raised($post,$order_id);
	            }
	            $tr->commit();
	            // print_r(['code'=>0]);
	            return $this->redirect(['check','order_id'=>$order_id,'type'=>$post['product_type']]);
			}else{
				throw new \Exception("请求方式错误");
			}

		}catch(\Exception $e) {
			$tr->rollback();
			$err = [
		        'code' => $e->getCode(),
		        'msg'  => $e->getMessage(),
		        'file'    => $e->getFile(),
		        'line'   => $e->getLine()
		    ];
            print_r(['code'=>1,"data"=>$err]);
		}
	}

	public function actionCheck($order_id,$type){
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
		$Order = Order::find()->where(['id'=>$order_id])->one();
		$status = $Order->status;
		$product_id = $Order->product_id;
		if ($status != Order::CREATEORDER && $status != Order::CHECKORDER) {
			# code...
		}
		$data = [];
		$address = ReceiptAddress::find()->with('area')->where(['user_id'=>$user_id])->asArray()->all();
		foreach ($address as $key => $value) {
			$City = City::find()->where(['cityID'=>$value['area']['fatherID']])->one();
			$Province = Province::find()->where(['provinceID'=>$City->fatherID])->one();
			$address[$key]['city'] = $City->city;
			$address[$key]['province'] = $Province->province;
		}
		$Product = Product::find()
		          ->select(['id','farm_id','species_id','forage_id','name','foundation_weight','foundation_price','img_url','start_time','end_time','feed_time','feed_price','output'])
                  ->with(['species'=>function($query){
                  	$query->select('id,name');
                  },'farm'=>function($query){
  		        	$query->select('id,account_place');
  		          },'forage'])
                  ->where(['id'=>$Order->product_id])
                  ->asArray()
                  ->one();

        
        $data['address'] = $address;
        $data['product'] = $Product;

		if ($type==1) {
			$Detail = OrderAdopt::find()->with('forage')->where(['order_id'=>$order_id])->asArray()->one();

			$Product['species'] = $Product['species']['name'];
			$Product['forage'] = $Product['forage']['name'];
	        $Product['farm_place'] = $Product['farm']['account_place'];
	  //       $Product['feed_time'] = (strtotime($Detail['end_time'])-strtotime($Detail['start_time']))/(3600*24);
			// $Product['start_time'] = $Detail['start_time'];
			// $Product['end_time'] = $Detail['end_time'];
			// $Product['forage'] = $Detail['forage']['name'];
			$data['product'] = $Product;

			// $forage_price = ForageOffer::find()->where(['forage_id'=>$Detail['forage']['id'],'farm_id'=>$Product['farm_id']])->one()->price;

			$all_price = $Product['feed_price']*$Detail['time_add']+$Product['foundation_price'];

		}else if ($type==2) {
			$all_price = 0;
			$setmeals = OrderRaised::find()->where(['order_id'=>$order_id])->asArray()->all();
			foreach ($setmeals as $key => $value) {
				$model = Setmeal::find()->where(['id'=>$value['setmeal_id']])->one();
                $data['setmeal'][] = $model;
                $all_price = $all_price+$model->price;
			}
		}

		$data['all_price'] = $all_price;
		$data['order_id'] = $order_id;
        
        $Order = Order::find()->where(['id'=>$order_id])->one();
        $Order->amount = $all_price;
        $Order->save();
        $this->layout = 'layout1';
        if ($type==1) {
        	return $this->render('check1',['data'=>$data]);
        }else if ($type==2) {
        	return $this->render('check2',['data'=>$data]);
        }
		
	}

	public function actionConfirm($order_id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Order = Order::find()->where(['id'=>$order_id])->one();
			$Order->scenario = "update";
	        $post['status'] = Order::CHECKORDER;

	        if ($Order->load($post,'') && $Order->save()) {
	        	return $this->redirect(['pay','order_id'=>$Order->id]);
	        }else{
	        	return ['code'=>1,'data'=>$Order->getErrors()];
	        }
		}
		
	}

	public function actionPay($order_id){
		return Pay::alipay($order_id);
		// $result =  Pay::alipay1($order_id);
		// if ($result) {
  //          return $this->redirect(Yii::$app->request->hostInfo.'/pay/ok');
  //       }else {
  //          return $this->redirect(Yii::$app->request->hostInfo.'/pay/fail');
  //       }
	}

	private function adopt($post,$order_id){
		$OrderDetail = new OrderAdopt;
		$OrderDetail->order_id = $order_id;
		$OrderDetail->time_add = $post['feed_time'];
		if (!$OrderDetail->save()) {
			throw new \Exception(json_encode($OrderDetail->getErrors()));
		}
	}

	private function raised($post,$order_id){
		foreach ($post['setmeals'] as $key => $value) {
			$OrderDetail = new OrderRaised;
			$data['order_id'] = $order_id;
			$data['setmeal_id'] = $value;
			$data['price'] = Setmeal::findOne($value)->price;
			$data['createtime'] = time();
			$status = $OrderDetail->add($data);
			if ($status['code']!=0) {
				throw new \Exception(json_encode($status['data']));
			}
		}
	}
}