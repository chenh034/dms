<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Product;
use app\models\Setmeal;
use app\models\Species;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_raiseController extends Controller
{
	public function actionList(){
  		$species = Species::find()->where(['is_use'=>1])->asArray()->all();
      // $model = new Species;
      // $tree = $model->getTree($species);
      foreach ($species as $key => $value) {
      	if ($value['parent_id']==0) {
      		unset($species[$key]);
      	}
      }
      $this->layout = 'layout1';
      return $this->render('list',['species'=>$species]);
	}

	public function actionJson($page=1,$size=12,$species=0,$time='desc',$rate='desc'){
  		// Yii::$app->response->format = Response::FORMAT_JSON;
  		$page = (int)$page;
  		$size = (int)$size;
  		$offset = $size*($page-1);
  		$species = (int)$species;
  		if ($species==0) {
  			$where = ['type'=>2,'status'=>1,'is_ok'=>1];
  		}else {
        $where = ['type'=>2,'status'=>1,'is_ok'=>1,'species_id'=>$species];
  		}

  		$data['total'] = Product::find()->where($where)->count();
  		$Product = Product::find()->select(['id','farm_id','species_id','foundation_weight','img_url','rate'])
    			                      ->with(['species'=>function($query){
    			                      	$query->select('id,name');
    			                      },'farm'=>function($query){
    			      		        	    $query->select('id,account_place,pca');
    			      		            }])
    			                      ->limit($size)
    			                      ->offset($offset)
    			                      ->where($where)
    			                      ->orderBy('rate '.$rate.', id '.$time)
    			                      ->asArray()
    			                      ->all();

  	    foreach ($Product as $key => $value) {
            $setmeal_total = Setmeal::find()->where(['product_id'=>$value['id']])->count();
            $Product[$key]['species'] = $value['species']['name'];
            $Product[$key]['farm_place'] = $value['farm']['pca'];
            $Product[$key]['rate'] = sprintf("%.2f", $value['rate']/$setmeal_total);
            unset($Product[$key]['farm']);
        }

        $data['data'] = $Product;

        print_r(json_encode($data));
	}

	public function actionDetail($id){
    		Yii::$app->session['returnUrl'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        if (isset(Yii::$app->session['font_user'])) {
            $user_id = Yii::$app->session['font_user']['user_id'];
        }else{
            return $this->redirect(Yii::$app->request->hostInfo.'/c_login/tologin');
        }
    		$id = (int)$id;
    		$Product = Product::find()
    		          ->select(['id','farm_id','species_id','forage_id','name','foundation_weight','pre_weight','img_url','advice','introduce','setmeal_info','feed_time','start_time','end_time','output','status'])
                  ->with(['species'=>function($query){
                  	$query->select('id,name');
                  },'farm'=>function($query){
  		        	  $query->select('id,account_place');
  		            },'forage'=>function($query){
  		          	$query->select('id,name');
  		            }])
                  ->where(['id'=>$id])
                  ->orderBy('id desc')
                  ->asArray()
                  ->one();

        if ($Product['status']!=1) {
          die('商品已被购买');
        }

    		$Product['species'] = $Product['species']['name'];
    		$Product['forage'] = $Product['forage']['name'];
        $Product['farm_place'] = $Product['farm']['account_place'];
        // $Product['feed_time'] = (strtotime($Product['end_time'])-strtotime($Product['start_time']))/(3600*24);
        unset($Product['start_time']);
        unset($Product['end_time']);
        unset($Product['farm']);

        $Setmeal = Setmeal::find()->select(['id','name','price','buy'])->where(['product_id'=>$id])->asArray()->all();

        $data['product'] = $Product;
        $data['setmeal'] = $Setmeal;

        $this->layout = 'layout1';
        return $this->render('detail',['data'=>$data]);

	}

	public function actionTest(){
		print_r($_POST);
	}
}

