<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\Species;
use app\models\Setmeal;
use app\models\FarmResult;
use app\models\Forage;
use app\models\ForageType;
use app\models\ForageOffer;
use yii\web\Response;
use crazyfd\qiniu\Qiniu;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_productController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}
	
	public function actionToadd(){
		$farm_id = Yii::$app->session['farm_user']['user_id'];
        $species = Species::find()->where(['is_use'=>1])->asArray()->all();
        $model = new Species;
        $tree = $model->getTree($species);
        $speciesTree = $model->setPrefix($tree);

        $forage = ForageOffer::find()->with(['forage'=>function($query){
        	$query->select(['id','name']);
        }])->where(['farm_id'=>$farm_id])->asArray()->all();
        
        $this->layout = 'layout2';
        return $this->render("add",['species'=>$speciesTree,'forage'=>$forage]);
	}


	public function actionAdd(){
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		// $farm_id = 1;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['farm_id'] = $farm_id;
			if ($post['type'] == 'adopt') {
				$post['type'] =1;
				unset($post['food']);
				unset($post['setmeal']);


				$transaction = Yii::$app->db->beginTransaction();
				try{
					$add_status = $this->adopt($post);
					if ($add_status['code']==1) {
						$err_msg = $this->getoneMessage($add_status['data']);
						throw new \Exception($err_msg[0]);
					}
					$Result = new FarmResult;
					$pro_rs = $Result->addResult($farm_id,$add_status['data']['product_id']);
					if ($pro_rs['code']==1) {
						throw new \Exception('farm_result添加失败');
					}
					// foreach ($forages as $key => $value) {
					// 	$model = new Forage;
     //                    $model->type_id = $value;
     //                    $model->product_id = $add_status['data']['product_id'];
     //                    $model->farm_id = $farm_id;
     //                    if (!$model->save()) {
     //                    	throw new \Exception('可选饲料添加失败');
     //                    }
					// }
					$transaction->commit();
					Yii::$app->session->setFlash('status','添加成功');
					return $this->redirect(['toadd']);
				}catch(\Exception $e){
					$transaction->rollBack();
					$err = [
				        'code' => $e->getCode(),
				        'msg'  => $e->getMessage(),
				        'file'    => $e->getFile(),
				        'line'   => $e->getLine()
				    ];
					Yii::$app->session->setFlash('status',$err['msg']);
					return $this->redirect(['toadd']);
				}
				
			}else if ($post['type'] == 'raise') {
				$post['type'] = 2;
				unset($post['food']);
				$this->raised($post);
				Yii::$app->session->setFlash('status','添加成功');
				return $this->redirect(['toadd']);
			}
	
		}
	}

	public function adopt($post){
		$Product = new Product;
		if (isset($_FILES['file'])) {
			$img_url = $this->uploadPic();
			$post['img_url'] = $img_url;
		}
		$add_status = $Product->addProduct($post);
		
		return $add_status;

	}

	public function raised($post){
		$Product = new Product;
		$Setmeal = new Setmeal;
		if (isset($_FILES['file'])) {
			$img_url = $this->uploadPic();
			$post['img_url'] = $img_url;
		}
		$setmeals = $post['setmeal'];
		unset($post['setmeal']);

		$transaction = Yii::$app->db->beginTransaction();
		try{
        
		    $add_status = $Product->addProduct($post);
 
		    if($add_status['code'] == 1){
		    	$err_msg = $this->getoneMessage($add_status['data']);
				throw new \Exception($err_msg[0]);
		    }

			$farm_id = $post['farm_id'];
			$product_id = $add_status['data']['product_id'];

			$Result = new FarmResult;
			$pro_rs = $Result->addResult($farm_id,$product_id);
			if ($pro_rs['code']==1) {
				$err_msg = $this->getoneMessage($add_status['data']);
				throw new \Exception($err_msg[0]);
			}

            foreach ($setmeals as $key => $value) {
            	$data = $value;
            	$data['index'] = $key;
				$Setmeal = new Setmeal;
				$setmeal_status = $Setmeal->addSetmeal($data,$farm_id,$product_id);
				if ($setmeal_status['code']==1) {
					throw new \Exception('套餐添加失败');
				}
			}
		    
		    $transaction->commit(); 
		}catch (\Exception $e){
		    $transaction->rollBack();
			$err = [
		        'code' => $e->getCode(),
		        'msg'  => $e->getMessage(),
		        'file'    => $e->getFile(),
		        'line'   => $e->getLine()
		    ];
			Yii::$app->session->setFlash('status',$err['msg']);
			return $this->redirect(['toadd']);
		}
		return $add_status;
	}

	public function actionToedit($id){
		$id = (int)$id;
		
		$farm_id = Yii::$app->session['farm_user']['user_id'];
        $species = Species::find()->asArray()->all();
        $model = new Species;
        $tree = $model->getTree($species);
        $speciesTree = $model->setPrefix($tree);

        $forage = ForageType::find()->asArray()->all();

        // $forage = ForageOffer::find()->with(['forage'=>function($query){
        // 	$query->select(['id','name']);
        // }])->where(['farm_id'=>$farm_id])->asArray()->all();

        // $forages = Forage::find()->where(['product_id'=>$id])->asArray()->all();

        // foreach ($forage as $key => $value) {
        // 	$forage[$key]['checked'] = 0;
        // 	foreach ($forages as $k => $v) {
        // 		if ($value['forage_id']==$v['type_id']) {
        // 			$forage[$key]['checked'] = 1;
        // 		}
        // 	}
        // }

        $Product = Product::find()->where(['id'=>$id])->asArray()->one();
        if ($Product['is_ok']!=0) {
			die('审核后无法修改信息');
		}
        
        $this->layout = 'layout2';
        if ($Product['type']==1) {
        	return $this->render("edit1",['species'=>$speciesTree,'forage'=>$forage,'product'=>$Product]);
        }else if ($Product['type']==2) {
        	$setmeals = Setmeal::find()->where(['product_id'=>$Product['id']])->asArray()->all();
        	foreach ($setmeals as $key => $value) {
        		// $setmeals[$key]['num'] = $this->toString($key+1);
        		$setmeals[$key]['num'] = $value['index'];
        	}
        	return $this->render("edit2",['species'=>$speciesTree,'forage'=>$forage,'product'=>$Product,'setmeals'=>$setmeals]);
        }
	}

	public function actionEdit($id){
		$id = (int)$id;
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		$Product = Product::findOne($id);
        if (Yii::$app->request->isPost) {
        	$post = Yii::$app->request->post();
            $post['img_url'] = $Product->img_url;
        	if (isset($_FILES['file']) && $_FILES['file']['error']==0) {
				$img_url = $this->uploadPic();
				$post['img_url'] = $img_url;
				if ($Product->img_url) {
					$this->delPic($Product->img_url);
				}
			}
			if ($post['type']=='adopt') {
				$post['type'] = 1;
				// $forages = $post['food'];
				// unset($post['food']);
				$transaction = Yii::$app->db->beginTransaction();
				try{
					$edit_status = $Product->editProduct($post);
					if ($edit_status['code']==1) {
						$err_msg = $this->getoneMessage($edit_status['data']);
						throw new \Exception($err_msg[0]);
					}
					// Forage::deleteAll(['product_id'=>$Product->id]);
					// foreach ($forages as $key => $value) {
					// 	$model = new Forage;
     //                    $model->type_id = $value;
     //                    $model->product_id = $Product->id;
     //                    $model->farm_id = $farm_id;
     //                    if (!$model->save()) {
     //                    	throw new \Exception('修改饲料失败');
     //                    }
					// }
					$transaction->commit();
					Yii::$app->session->setFlash('status','修改成功');
					return $this->redirect(['toedit','id'=>$id]);
				}catch(\Exception $e){
					$transaction->rollBack();
					$err = [
				        'code' => $e->getCode(),
				        'msg'  => $e->getMessage(),
				        'file'    => $e->getFile(),
				        'line'   => $e->getLine()
				    ];
					Yii::$app->session->setFlash('status',$err['msg']);
					return $this->redirect(['toedit','id'=>$id]);
				}
			}else if ($post['type']=='raised') {
				$post['type']=2;
				$setmeals = $post['setmeal'];
				unset($post['setmeal']);

				$transaction = Yii::$app->db->beginTransaction();
				try{

				    $edit_status = $Product->editProduct($post);
				    if($edit_status['code'] == 1){
				    	$err_msg = $this->getoneMessage($edit_status['data']);
						throw new \Exception($err_msg[0]);
				    }
				    $product_id = $edit_status['data']['product_id'];

                    Setmeal::deleteAll(['product_id'=>$Product->id]);
		            foreach ($setmeals as $key => $value) {
		            	$data = $value;
		            	$data['index'] = $key;
						$Setmeal = new Setmeal;
						$setmeal_status = $Setmeal->addSetmeal($data,$farm_id,$product_id);
						if ($setmeal_status['code']==1) {
							print_r($setmeal_status);die();
							throw new \Exception('套餐添加失败');
						}
					}
				    
				    $transaction->commit(); 
				    Yii::$app->session->setFlash('status','修改成功');
					return $this->redirect(['toedit','id'=>$id]);
				}catch (\Exception $e){
				    $transaction->rollBack();
					$err = [
				        'code' => $e->getCode(),
				        'msg'  => $e->getMessage(),
				        'file'    => $e->getFile(),
				        'line'   => $e->getLine()
				    ];
					Yii::$app->session->setFlash('status','修改失败：'.$err['msg']);
					return $this->redirect(['toedit','id'=>$id]);
				}
			}
        }
	}

	public function actionDel($id){
		$id = (int)$id;
		$Product = Product::findOne($id);
		if (!is_null($Product)) {
			$this->delPic($Product->img_url);
			if ($Product->delete()) {
				return $this->renderPartial('tip');
			}else{
				return $this->renderPartial('tip');
			}
		}

	}

	public function actionBatchdel(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			foreach ($post['select'] as $key => $value) {
				$Product = Product::findOne($key);
				if (!is_null($Product)) {
					$this->delPic($Product->img_url);
					$Product->delete();
				}
			}
			return $this->renderPartial('tip');
		}
	}

	public function actionList(){
		$this->layout = 'layout2';
		return $this->render('list');
	}

	public function actionList1(){
		$this->layout = 'layout2';
		return $this->render('list1');
	}

	public function actionList2(){
		$this->layout = 'layout2';
		return $this->render('list2');
	}

	public function actionJson($page,$size,$is_ok){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		$size = (int)$size;
        $offset = $size*($page-1);
        $is_ok = (int)$is_ok;
        
        $data['total'] = Product::find()->where(['is_ok'=>$is_ok,'status'=>1])->count();
        $data['data'] = Product::find()->select(['id','name','species_id','foundation_weight','pre_weight','foundation_price','img_url','is_ok'])
                ->with(['species'=>function($query){
                	$query->select('id,name');
                }])
                ->where(['farm_id'=>$farm_id,'is_ok'=>$is_ok,'status'=>1])
                ->limit($size)
                ->offset($offset)
                ->orderBy('id desc')
                ->asArray()
                ->all();

        return $data;
	}

	private function uploadPic(){
		if ($_FILES['file']['error'] > 0) {
			return false;
		}
		$qiniu = new Qiniu(Product::AK, Product::SK, Product::DOMAIN, Product::BUCKET);
		$key = uniqid();
        $qiniu->uploadFile($_FILES['file']['tmp_name'], $key);
        $img_url = $qiniu->getLink($key);

        return $img_url;
	}

	private function delPic($link){
		$qiniu = new Qiniu(Product::AK, Product::SK, Product::DOMAIN, Product::BUCKET);
        $qiniu->delete(basename($link));
	}

	public function getoneMessage($data){
		static $arr = [];
        foreach ($data as $key => $value) {
        	if (is_array($value)) {
        		$this->getoneMessage($value);
        	}else{
        		$arr[] = $value;
        	}
        }
        return $arr;
	}
    
    public function toString($key){
    	switch ($key) {
    		case '1':
    			return '一';
    			break;
    		case '2':
    			return '二';
    			break;
    		case '3':
    			return '三';
    			break;
    		case '4':
    			return '四';
    			break;
    		case '5':
    			return '五';
    			break;
    		case '6':
    			return '六';
    			break;
    		case '7':
    			return '七';
    			break;
    		case '8':
    			return '八';
    			break;
    		case '9':
    			return '九';
    			break;
    		case '10':
    			return '十';
    			break;
    		
    		default:
    			# code...
    			break;
    	}
    }

}