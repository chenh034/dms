<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FarmUser;
use app\models\FarmUpdate;
use app\models\Area;
use app\models\City;
use app\models\Province;
use app\models\ForageOffer;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_indexController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}

	public function actionIndex(){
		$user_id = Yii::$app->session['farm_user']['user_id'];
		// $user_id = 1;

		$FarmUser = FarmUser::findOne($user_id);

		$area = Area::find()->where(['areaID'=>$FarmUser->area_id])->one();
		$city = City::find()->where(['cityID'=>$area->fatherID])->one();
		$province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
		$address['area'] = $area->area;
		$address['city'] = $city->city;
		$address['province'] = $province->province;
        
        $forage = ForageOffer::find()->with('forage')->where(['farm_id'=>$user_id])->asArray()->all();
		$this->layout = 'layout2';
		return $this->render('index',['data'=>$FarmUser,'address'=>$address,'forage'=>$forage]);
	}

	public function actionContact(){
		$user_id = Yii::$app->session['farm_user']['user_id'];
		// $user_id = 1;
		$FarmUser = FarmUser::findOne($user_id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$FarmUser->bak_phone = $post['bak_phone'];
			$FarmUser->account_place = $post['account_place'];
			$FarmUser->save();
            $Update = [];
            foreach ($post as $key => $value) {
            	if ($value!=$FarmUser->$key) {
            		$Update[$key] = $value; 
            	}
            }
         
            
            if (!empty($Update)) {
            	$FarmUpdate = FarmUpdate::find()->where(['farm_id'=>$user_id,'status'=>0])->one();
	        	if (is_null($FarmUpdate)) {
	        		$FarmUpdate = new FarmUpdate;
	        	}
	        	$Update['farm_id'] = $user_id;
	        	$FarmUpdate->load($Update,'');
	        	if ($FarmUpdate->save()) {
	        		return $this->renderPartial('tip');
	        	}else{
	        		return $this->renderPartial('tip1');
	        	}
            }else{
            	return $this->renderPartial('tip');
            }

		}
	}

	public function actionFarm(){
		$user_id = Yii::$app->session['farm_user']['user_id'];
		// $user_id = 1;
		$FarmUser = FarmUser::findOne($user_id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$FarmUser->dorm_num = $post['dorm_num'];
			$FarmUser->product_num = $post['product_num'];
			$FarmUser->detail_place = $post['detail_place'];
			$FarmUser->save();

			if (isset($post['price'])) {
				foreach ($post['price'] as $key => $value) {
					$ForageOffer = ForageOffer::find()->where(['forage_id'=>$key])->one();
					$ForageOffer->price = $value;
					$ForageOffer->save();
				}
			}

            $Update = [];
            if ($post['area_id']!=$FarmUser->area_id) {
            	$Update['area_id'] = $post['area_id'];
            	// $Update['detail_place'] = $post['detail_place'];
            }
            if ($post['farm_name']!=$FarmUser->farm_name) {
            	$Update['farm_name'] = $post['farm_name'];
            }
         
            
            if (!empty($Update)) {
            	$FarmUpdate = FarmUpdate::find()->where(['farm_id'=>$user_id,'status'=>0])->one();
	        	if (is_null($FarmUpdate)) {
	        		$FarmUpdate = new FarmUpdate;
	        	}
	        	$Update['farm_id'] = $user_id;
	        	$FarmUpdate->load($Update,'');
	        	if ($FarmUpdate->save()) {
	        		return $this->renderPartial('tip');
	        	}else{
	        		return $this->renderPartial('tip1');
	        	}
            }else{
            	return $this->renderPartial('tip');
            }

		}
	}

	public function actionAccount(){
		// $user_id = Yii::$app->session['farm_user'];
		

	}

	public function actionForage(){
		$user_id = Yii::$app->session['farm_user']['user_id'];
		// $user_id = 1;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			foreach ($post['price'] as $key => $value) {
				$ForageOffer = ForageOffer::find()->where(['forage_id'=>$key])->one();
				if (!is_null($ForageOffer)) {
					$ForageOffer->price = $value;
					$ForageOffer->save();
				}
			}
			return $this->redirect('forage');
		}else{
			$forage = ForageOffer::find()->with('forage')->where(['farm_id'=>$user_id])->asArray()->all();
			$this->layout = 'layout2';
			return $this->render('forage',['forage'=>$forage]);
		}
	}
}