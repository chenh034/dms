<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Species;
use app\models\HandBook;
use app\models\ForageType;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class DetailController extends Controller
{
	
	public function actionSpecies($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$Species = Species::findOne($id);

		return $Species->attributes;
	}


	public function actionArticle($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$HandBook = HandBook::findOne($id);

		return $HandBook->content;
	}

	public function actionForage($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$ForageType = ForageType::findOne($id);
        $data['ingredient'] = $ForageType->ingredient;
        $data['introduce'] = $ForageType->introduce;
        $data['img_url'] = $ForageType->img_url;
		return $data;
	}
}