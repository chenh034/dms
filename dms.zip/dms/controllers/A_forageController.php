<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FarmUser;
use app\models\Forage;
use app\models\ForageType;
use app\models\Species;
use yii\web\Response;
use app\component\Upload;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_forageController extends Controller
{
	public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
	
	public function actionAdd(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();

			$check = ForageType::find()->where(['name'=>trim($post['name'])])->one();
            if (!is_null($check)) {
            	$add_status = ['code'=>3];
            	return $add_status;
            }
            
            $Upload = new Upload;
			$img_url = $Upload->uploadPic();
			$post['img_url'] = $img_url;

			$ForageType = new ForageType;
			$add_status = $ForageType->addForage($post);

			if ($add_status['code']==0) {
        		return ['code'=>0];
        	}else{
        		return ['code'=>1,'data'=>$add_status['data']];
        	}
		}
	}

	public function actionEdit($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$ForageType = ForageType::findOne($id);

		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();

			$post['img_url'] = $ForageType->img_url;
        	if (isset($_FILES['file']) && $_FILES['file']['error']==0) {
				$Upload = new Upload;
				$img_url = $Upload->uploadPic();
				$post['img_url'] = $img_url;
				if ($ForageType->img_url) {
					$Upload->delPic($ForageType->img_url);
				}
			}

			$edit_status = $ForageType->editForage($post);

			if ($edit_status['code']==0) {
        		return ['code'=>0];
        	}else{
        		return ['code'=>1,'data'=>$edit_status['data']];
        	}
        	
		}
		return $ForageType->attributes;
	}

	public function actionDel($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$ForageType = ForageType::findOne($id);
		if (!is_null($ForageType)) {
			// $Upload = new Upload;
			// $Upload->delPic($ForageType->img_url);
			$ForageType->is_use = 0;
			if ($ForageType->save()) {
				return ['code'=>0];
			}else{
				return ['code'=>1,'data'=>$ForageType->getErrors()];
			}
		}else{
			return ['code'=>0];
		}
	}

	public function actionBatchdel(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$tr = Yii::$app->db->beginTransaction();
			try{
			    foreach ($post['ids'] as $key => $value) {
					$ForageType = ForageType::findOne($value);
	                $ForageType->is_use = 0;
	                if (!$ForageType->save()) {
	                	throw new Exception("删除失败");	
	                }
				}
				$tr->commit();
			}catch (\Exception $e){
			    $tr->rollBack();
				$err = [
			        'code' => $e->getCode(),
			        'msg'  => $e->getMessage(),
			        'file'    => $e->getFile(),
			        'line'   => $e->getLine()
			    ];
				return ['code'=>1,'data'=>$err['msg']];
			}
			return ['code'=>0];
		}
	}

	public function actionJson($page=1,$size=10){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
        $offset = $size*($page-1);
        $data['total'] = ForageType::find()->where(['is_use'=>1])->count();
        $data['data'] = ForageType::find()->select(['id','name','object','ingredient','img_url','introduce'])
                ->limit($size)
                ->offset($offset)
                ->where(['is_use'=>1])
                ->orderBy('id desc')->asArray()->all();
        return $data;
	}

	public function actionAll($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		if ($id) {
			$data = ForageType::find()->select(['id','name','object','ingredient','img_url','introduce'])
	                ->where(['is_use'=>1])
	                ->orderBy('id desc')->asArray()->all();
	        $ForageOffer = FarmUser::findOne($id)->forage_offer;
	        $ForageOffer = explode(',', $ForageOffer);
	        foreach ($data as $key => $value) {
	        	$data[$key]['check'] = 0;
	        	foreach ($ForageOffer as $k => $v) {
	        		if ($value['id']==$v) {
	        			$data[$key]['check'] = 1;
	        		}
	        	}
	        }
		}else{
			$data = ForageType::find()->select(['id','name','object','ingredient','img_url','introduce'])
	                ->where(['is_use'=>1])
	                ->orderBy('id desc')->asArray()->all();
		}
		return $data;
        
	}


}