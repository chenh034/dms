<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Order;
use app\models\Product;
use app\models\ProductParam;
use app\models\Forage;
use app\models\ForageType;
use app\models\ForageOffer;
use app\models\Pay;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_mineController extends Controller
{
    public function behaviors(){
         return [
            'font' => [
                'class' => 'app\component\FontFilter'//调用过滤器
            ]
        ];
    }
    
    public function actionTest(){
        return $this->renderPartial('test');
    }
    public function actionNickname($id){
        Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $Order = Order::find()->where(['product_id'=>$id,'user_id'=>Yii::$app->session['font_user']['user_id']])->one();
            $Order->nickname = $post['nickname'];
            if ($Order->save()) {
                return ['code'=>0];
            }else{
                return ['code'=>1,'data'=>$Order->getErrors()];
            }
        }
    }

    public function actionTowait(){
        $user_id = Yii::$app->session['font_user']['user_id'];
        $this->layout = 'layout1';
        return $this->render('wait');

    }
	
	public function actionWait($page=1,$size=10){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
        
        $orders = Order::find()->select(['id','product_id'])->where(['user_id'=>$user_id,'status'=>Order::PAYSUCCESS])->asArray()->all();
        $ids = [];
        foreach ($orders as $key => $value) {
        	$ids[] = $value['product_id'];
        }
        $ids = array_flip($ids);
        $ids = array_flip($ids);

        $total = Product::find()->where(['in','id',$ids])->andWhere('status=2')->count();
        $Product = Product::find()
                    ->select(['id','img_url','species_id','name','type','feed_time','start_time','end_time','pre_weight','now_weight','update_time'])
                    ->with('species')
                    ->limit($size)
                    ->offset($offset)
                    ->where(['in','id',$ids])
                    ->andWhere('status=2 or status=1')
                    ->asArray()
                    ->all();
        foreach ($Product as $key => $value) {
        	if ($value['type']==1) {
        		$Product[$key]['type'] = '认养';
        	}else if ($value['type']==2) {
        	    $Product[$key]['type'] = '共筹';
        	}
        	$Product[$key]['species'] = $value['species']['name'];
            $Product[$key]['update_time'] = date('Y-m-d',$value['update_time']);
        }
        
        $data['total'] = $total;
        $data['data'] = $Product;
        print_r(json_encode($data));

	}
    

    public function actionToduring(){
        $user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('during');
    }
	public function actionDuring($page=1,$size=10){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
        
        $orders = Order::find()->select(['id','product_id'])->where(['user_id'=>$user_id])
           ->andWhere(['in','status',[Order::PAYSUCCESS,Order::SENDED]])->asArray()->all();
        $ids = [];
        foreach ($orders as $key => $value) {
        	$ids[] = $value['product_id'];
        }
        $ids = array_flip($ids);
        $ids = array_flip($ids);

        $total = Product::find()->where(['in','id',$ids])->andWhere('status=3')->count();
        $Product = Product::find()->select(['id','img_url','species_id','name','type','start_time','end_time','pre_weight','now_weight','update_time'])->with('species')->limit($size)->offset($offset)->where(['in','id',$ids])->andWhere('status=3')->asArray()->all();
        foreach ($Product as $key => $value) {
        	if ($value['type']==1) {
        		$Product[$key]['type'] = '认养';
        	}else if ($value['type']==2) {
        	    $Product[$key]['type'] = '共筹';
        	}
        	$Product[$key]['species'] = $value['species']['name'];
            $Product[$key]['update_time'] = date('Y-m-d',$value['update_time']);
            $Product[$key]['nickname'] = Order::find()->where(['product_id'=>$value['id'],'user_id'=>$user_id])->one()->nickname;
        }
        
        $data['total'] = $total;
        $data['data'] = $Product;
        print_r(json_encode($data));
	}


    public function actionTohistory(){
        $user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('history');
    }

	public function actionHistory($page=1,$size=10){
        // Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$user_id = Yii::$app->session['font_user']['user_id'];
		// $user_id = 1;
        
        $orders = Order::find()->select(['id','product_id'])->where(['user_id'=>$user_id,'status'=>Order::RECEIVED])->asArray()->all();
        $ids = [];
        foreach ($orders as $key => $value) {
        	$ids[] = $value['product_id'];
        }
        $ids = array_flip($ids);
        $ids = array_flip($ids);

        $total = Product::find()->where(['in','id',$ids])->andWhere('status=4')->count();
        $Product = Product::find()->select(['id','img_url','species_id','name','type','start_time','end_time','pre_weight','output'])->with('species')->limit($size)->offset($offset)->where(['in','id',$ids])->andWhere('status=4')->asArray()->all();
        foreach ($Product as $key => $value) {
        	if ($value['type']==1) {
        		$Product[$key]['type'] = '认养';
        	}else if ($value['type']==2) {
        	    $Product[$key]['type'] = '共筹';
        	}
        	$Product[$key]['species'] = $value['species']['name'];
        }
        
        $data['total'] = $total;
        $data['data'] = $Product;
        print_r(json_encode($data));
	}

    public function actionDetail($id){
        $id = (int)$id;
        $Product = Product::find()
                   ->select(['id','species_id','name','type','now_weight','advice','dorm','start_time','end_time','update_time'])
                   ->with(['species','param'=>function($query){

                   },'dorm'])
                   ->where(['id'=>$id])
                   ->asArray()->one();
        $end = end($Product['param']);
        $update_time = $end['update_time'];
        $Product['food_intake'] = $end['food_intake'];
        $Product['activity'] = $end['activity'];
        $Product['sleep'] = $end['sleep'];
        $Product['now_weight'] = $end['now_weight'];
        $Product['fat_ratio'] = $end['fat_ratio'];
        $Product['species'] = $Product['species']['name'];
        $Product['has_feed'] = (strtotime(date('Y-m-d',time()))-strtotime($Product['start_time']))/(3600*24);
        $Product['update_time'] = date('Y-m-d',$update_time);

        $this->layout = 'layout1';
        return $this->render('detail',['product'=>$Product]);
    }

    public function actionGetparam($id){
        Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;

        $ProductParam = ProductParam::find()->where(['product_id'=>$id])->asArray()->all();
        $end = end($ProductParam);
        $update_time = $end['update_time'];

        $paramSize = count($ProductParam);
        $food_intake = $activity = $sleep = $now_weight = $fat_ratio = [];
        $x = [];
        if ($paramSize>5) {
            $start = $ProductParam[0];
            $end = end($ProductParam);
            unset($ProductParam[0]);
            $ProductParam = array_pop($ProductParam);

            $rand_keys = array_rand($ProductParam,3);
            $x[] = date('Y-m-d',$start['update_time']);
            $food_intake[] = $start['food_intake'];
            $activity[] = $start['activity'];
            $sleep[] = $start['sleep'];
            $now_weight[] = $start['now_weight'];
            $fat_ratio[] = $start['fat_ratio'];
            foreach ($rand_keys as $key => $value) {
                $x[] = date('Y-m-d',$ProductParam[$value]['update_time']);
                $food_intake[] = $ProductParam[$value]['food_intake'];
                $activity[] = $ProductParam[$value]['activity'];
                $sleep[] = $ProductParam[$value]['sleep'];
                $now_weight[] = $ProductParam[$value]['now_weight'];
                $fat_ratio[] = $ProductParam[$value]['fat_ratio'];
            }
            $x[] = date('Y-m-d',$end['update_time']);
            $food_intake[] = $end['food_intake'];
            $activity[] = $end['activity'];
            $sleep[] = $end['sleep'];
            $now_weight[] = $end['now_weight'];
            $fat_ratio[] = $end['fat_ratio'];
        }else{
            foreach ($ProductParam as $key => $value) {
                $x[] = date('Y-m-d',$value['update_time']);
                $food_intake[] = $value['food_intake'];
                $activity[] = $value['activity'];
                $sleep[] = $value['sleep'];
                $now_weight[] = $value['now_weight'];
                $fat_ratio[] = $value['fat_ratio'];
            }
        }
    
        $data['x'] = $x;
        $data['food_intake'] = $food_intake;
        $data['activity'] = $activity;
        $data['sleep'] = $sleep;
        $data['now_weight'] = $food_intake;
        $data['fat_ratio'] = $food_intake;

        return $data;
    }

    public function actionChangeforage($id){
        // Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;
        $Product = Product::find()
                  ->select(['id','farm_id','species_id','forage_id','name','foundation_weight','pre_weight','feed_price','img_url','advice','output'])
                  ->with(['species'=>function($query){
                    $query->select('id,name');
                  },'farm'=>function($query){
                    $query->select('id,account_place');
                  }])
                  ->where(['id'=>$id])
                  ->orderBy('id desc')
                  ->asArray()
                  ->one();
        $Product['species'] = $Product['species']['name'];
        $Product['farm_place'] = $Product['farm']['account_place'];
        $Product['now_forage'] = ForageType::findOne($Product['forage_id'])->name;
        $Product['now_price'] =  ForageOffer::find()->where(['farm_id'=>$Product['farm_id'],'forage_id'=>$Product['forage_id']])->one()->price;
        unset($Product['farm']);

        $Forage = Forage::find()
                 ->select(['id','type_id'])
                 ->with(['forage'=>function($query){
                    $query->select(['id','name']);
                 }])
                 ->where(['product_id'=>$id])
                 ->asArray()
                 ->all();
        foreach ($Forage as $key => $value) {
            $Forage[$key]['name'] = $value['forage']['name'];
            $Forage[$key]['price'] = ForageOffer::find()->where(['forage_id'=>$value['type_id'],'farm_id'=>$Product['farm_id']])->one()->price;
            unset($Forage[$key]['forage']);
        }

        $data['product'] = $Product;
        $data['forage'] = $Forage;
        $this->layout = 'layout1';
        return $this->render('changeforage',['data'=>$data]);
    }

    public function actionForagecheck(){
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $Product = Product::findOne($post['product_id']);


            $new_forage = ForageType::findOne($post['new_forage'])->name;
            $new_forage_id = ForageType::findOne($post['new_forage'])->id;
            $feed_time = (strtotime($Product->end_time)-strtotime($Product->start_time))/(3600*24);
            $new_price = ForageOffer::find()->where(['farm_id'=>$Product->farm_id,'forage_id'=>$post['new_forage']])->one()->price;
            $old_price = ForageOffer::find()->where(['farm_id'=>$Product->farm_id,'forage_id'=>$Product->forage_id])->one()->price;
            $pay_price = ($new_price-$old_price)*$feed_time;

            $this->layout = 'layout1';
            return $this->render('foragecheck',['price'=>$pay_price,'new_forage'=>$new_forage,'new_forage_id'=>$new_forage_id,'product'=>$Product]);

        }
    }

    public function actionForageconfirm(){
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $Product = Product::findOne($post['product_id']);
            
            $new_forage = ForageType::findOne($post['new_forage'])->name;
            $new_forage_id = ForageType::findOne($post['new_forage'])->id;
            $feed_time = (strtotime($Product->end_time)-strtotime($Product->start_time))/(3600*24);
            $new_price = ForageOffer::find()->where(['farm_id'=>$Product->farm_id,'forage_id'=>$post['new_forage']])->one()->price;
            $old_price = ForageOffer::find()->where(['farm_id'=>$Product->farm_id,'forage_id'=>$Product->forage_id])->one()->price;
            $pay_price = ($new_price-$old_price)*$feed_time;

            // return Pay::alipay_f($Product->id,$new_forage_id,$new_forage,$pay_price);
            $result = Pay::alipay2($Product->id,$new_forage_id,$new_forage,$pay_price);
            if ($result) {
               return $this->redirect(Yii::$app->request->hostInfo.'/pay/ok');
            }else {
               return $this->redirect(Yii::$app->request->hostInfo.'/pay/fail');
            }

        }
    }


    public function actionChangetime($id){
        $id = (int)$id;
        $Product = Product::find()
                  ->select(['id','farm_id','species_id','forage_id','name','foundation_weight','pre_weight','feed_price','img_url','advice','output','start_time','end_time'])
                  ->with(['species'=>function($query){
                    $query->select('id,name');
                  },'farm'=>function($query){
                    $query->select('id,account_place');
                  }])
                  ->where(['id'=>$id])
                  ->orderBy('id desc')
                  ->asArray()
                  ->one();
        $Product['species'] = $Product['species']['name'];
        $Product['farm_place'] = $Product['farm']['account_place'];
        $Product['now_forage'] = ForageType::findOne($Product['forage_id'])->name;
        $Product['now_price'] =  ForageOffer::find()->where(['farm_id'=>$Product['farm_id'],'forage_id'=>$Product['forage_id']])->one()->price;

        unset($Product['farm']);

        $data['product'] = $Product;
        $this->layout = 'layout1';
        return $this->render('changetime',['data'=>$data]);
    }

    public function actionTimecheck(){
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $Product = Product::findOne($post['product_id']);

            $add_time = (strtotime($post['end_time'])-strtotime($Product->end_time))/(3600*24);

            $forage_price = ForageOffer::find()->where(['farm_id'=>$Product->farm_id,'forage_id'=>$Product->forage_id])->one()->price;
            $pay_price = ($forage_price+$Product->feed_price)*$add_time;

            $this->layout = 'layout1';
            return $this->render('timecheck',['price'=>$pay_price,'new_date'=>$post['end_time'],'product'=>$Product]);

        }
    }


}