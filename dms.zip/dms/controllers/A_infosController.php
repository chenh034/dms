<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\component\Upload;
use app\models\Infos;
use app\models\IndexImg;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_infosController extends Controller
{
	
	public function actionIndex(){
		$data = Infos::find()->select(['id','name'])->asArray()->all();
		print_r(json_encode($data));
	}

	public function actionUpdate($id){
		$id = (int)$id;
		$Infos = Infos::findOne($id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Infos->content = $post['content'];
			$Infos->update_time = date('Y-m-d H:i:s',time());
			if ($Infos->save()) {
				print_r(json_encode(['code'=>0]));
			}else{
				print_r(json_encode(['code'=>1,'data'=>$Infos->getErrors()]));
			}
		}else{
			print_r(json_encode($Infos->attributes));
		}
		
	}

	public function actionAddbanner(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
            
            $Upload = new Upload;
			$img_url = $Upload->uploadPic();
			$post['img_url'] = $img_url;

			$IndexImg = new IndexImg;
			$add_status = $IndexImg->add($post);

			print_r(json_encode($add_status));
		}
	}

	public function actionEditbanner($id){
		$id = (int)$id;
		$IndexImg = IndexImg::findOne($id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['img_url'] = $IndexImg->img_url;
			if (isset($_FILES['file']) && $_FILES['file']['error']==0) {
				$Upload = new Upload;
				$img_url = $Upload->uploadPic();
				$post['img_url'] = $img_url;
				if ($IndexImg->img_url) {
					$Upload->delPic($IndexImg->img_url);
				}
			}
			$edit_status = $IndexImg->edit($post);
			print_r(json_encode($edit_status));
			return;
		}

		print_r(json_encode($IndexImg->attributes));
	}

	public function actionDel($id){
		$id = (int)$id;
		$IndexImg = IndexImg::findOne($id);
		$Upload = new Upload;
		if ($IndexImg->delete()) {
			$Upload->delPic($IndexImg->img_url);
			print_r(json_encode(['code'=>0]));
		}else{
			print_r(json_encode(['code'=>1]));
		}
	}

	public function actionShow($id,$status){
		$id = (int)$id;
		$status = (int)$status;
		$IndexImg = IndexImg::findOne($id);
		$IndexImg->is_show = $status;
		if ($IndexImg->save()) {
			print_r(json_encode(['code'=>0]));
		}else{
			print_r(json_encode(['code'=>1,'data'=>$IndexImg->getErrors()]));
		}
	}

	public function actionJson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);

		$data['total'] = IndexImg::find()->count();
		$data['data'] = IndexImg::find()->limit($size)->offset($offset)->orderBy('id desc')->asArray()->all();

		print_r(json_encode($data));
	}
}