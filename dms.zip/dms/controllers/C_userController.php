<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Admin;
use app\models\FontUser;
use app\models\ReceiptAddress;
use app\models\Province;
use app\models\City;
use app\component\Upload;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_userController extends Controller
{
	
	public function actionIndex(){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		Yii::$app->session['returnUrl'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		if (isset(Yii::$app->session['font_user'])) {
			$user_id = Yii::$app->session['font_user']['user_id'];
		}else{
			return $this->redirect(Yii::$app->request->hostInfo.'/c_login/tologin');
		}
		
		$data = FontUser::find()->select(['username','nickname','head_url'])->where(['id'=>$user_id])->one();
		$address = ReceiptAddress::find()->with('area')->asArray()->where(['user_id'=>$user_id])->all();
		foreach ($address as $key => $value) {
			$City = City::find()->where(['cityID'=>$value['area']['fatherID']])->one();
			$Province = Province::find()->where(['provinceID'=>$City->fatherID])->one();
			$address[$key]['city'] = $City->city;
			$address[$key]['province'] = $Province->province;
		}

		if (!is_null($data)) {
			$data = $data->attributes;
            $data['address'] = $address;
			$this->layout = 'layout1';
			return $this->render('index',['data'=>$data]);
		}else{
			return [];
		}

	}


	public function actionUser(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$user_id = Yii::$app->session['font_user']['user_id'];

		if (Yii::$app->request->isPost) {
			$FontUser = FontUser::findOne($user_id);
			$post = Yii::$app->request->post();
			if (isset($_FILES['file']) && $_FILES['file']['error']==0) {
				$Upload = new Upload;
				if ($FontUser->head_url) {
					$Upload->delPic($FontUser->head_url);
				}
				$head_url = $Upload->uploadPic();
				$FontUser->head_url = 'http://'.$head_url;

			}
			$FontUser->nickname = $post['nickname'];
			$FontUser->scenario = "edit";
			if ($FontUser->save()) {
				$cookies = Yii::$app->response->cookies;
				$cookies->add(new \yii\web\Cookie([
					   'name'=>'head_url',
	                   'value'=>$FontUser->head_url
					]));
				Yii::$app->session->setFlash('status','修改成功');
				return $this->redirect('index');
			}else{
				Yii::$app->session->setFlash('status','修改失败');
				return $this->redirect('index');
			}
		}
	}

	public function actionAddress(){
		$user_id = Yii::$app->session['font_user']['user_id'];
		if (Yii::$app->request->isPost) {
			$ReceiptAddress = new ReceiptAddress;

			$post = Yii::$app->request->post();
			$post['user_id'] = $user_id;
			$add_status = $ReceiptAddress->addAddress($post);
			if ($add_status['code']==0) {
				$this->layout = 'layout1';
				return $this->redirect('index');
			}
		}
	}

	public function actionAddresslist(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		// $user_id = Yii::$app->session['font']['user_id'];
		$user_id = 1;
		$data = ReceiptAddress::find()->asArray()->where(['user_id'=>$user_id,'is_use'=>1])->all();

		return $data;
	}

	public function actionToedit($id){
		$id = (int)$id;
		$address = ReceiptAddress::find()->with('area')->where(['id'=>$id])->asArray()->one();

		$City = City::find()->where(['cityID'=>$address['area']['fatherID']])->one();
		$Province = Province::find()->where(['provinceID'=>$City->fatherID])->one();
		$address['city'] = $City->city;
		$address['province'] = $Province->province;
		$this->layout = 'layout1';
		return $this->render('edit',['address'=>$address]);
	}

	public function actionEdit($id){
		$id = (int)$id;
		$ReceiptAddress = ReceiptAddress::findOne($id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();

			$edit_status = $ReceiptAddress->editAddress($post);
			if ($edit_status['code']==0) {
				// $this->layout = 'layout1';
				return $this->redirect(['tip']);
			}
		}
	}

	public function actionDel($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;
       
        $ReceiptAddress = ReceiptAddress::findOne($id);

        if (!is_null($ReceiptAddress)) {
        	if ($ReceiptAddress->is_default==1) {
	        	$new_default = ReceiptAddress::find()->where(['is_use'=>1,'is_default'=>0])->one();
	        	$new_default->is_default = 1;
	        	$new_default->save();
	        }
	        $ReceiptAddress->is_use = 0;
        	if ($ReceiptAddress->save()) {
	        	return ['code'=>0];
	        }else{
	        	return ['code'=>1];
	        }
        }
	}

	public function actionDefault($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;

		$status = ReceiptAddress::findOne($id)->changeDefault();
        
        if ($status['code']==0) {
        	return ['code'=>0];
        }else{
        	return ['code'=>1];
        }
	}

	public function actionTip(){
		return $this->renderPartial('tip');
	}
}