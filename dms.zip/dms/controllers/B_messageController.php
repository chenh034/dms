<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\FarmMessage;
use app\models\ForageType;
use app\models\Species;

/**
* 
*/
class B_messageController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}

	public function actionIndex(){
		$this->layout = 'layout2';
		return $this->render('index');
	}

	public function actionDetail($id){
		$id = (int)$id;
		$message = FarmMessage::find()->with('product')->where(['mid'=>$id])->asArray()->one();
		$Product = Product::find()
		          ->select(['id','farm_id','species_id','forage_id','name','foundation_weight','foundation_price','img_url','start_time','end_time','output','start_time','end_time'])
                  ->with(['species'=>function($query){
                  	$query->select('id,name');
                  }])
                  ->where(['id'=>$message['product_id']])
                  ->asArray()
                  ->one();

        $Product['species'] = $Product['species']['name'];
        $Product['forage'] = ForageType::findOne($Product['forage_id'])->name;
        $Product['mid'] = $id;

        if ($message['forage']!=null) {
			$Product['message'] = '饲料更改为：'.$message['forage'];
		}
		if ($message['feed_time']!=null) {
			$Product['message'] = '养殖时间更改为：'.$message['feed_time'];
		}
		if ($message['kill_time']!=null) {
			$Product['message'] = '宰杀时间为：'.$message['kill_time'];
		}
		if ($message['feed']!=null) {
			$Product['message'] = '养殖时间：'.$message['product']['start_time'].'至'.$message['product']['end_time'];
		}

		$this->layout = 'layout2';
		return $this->render('detail',['product'=>$Product]);
	}

	public function actionConfirm($id){
		$id = (int)$id;
		$message = FarmMessage::findOne($id);

		if ($message->feed!=null) {
			$Product = Product::findOne($message->product_id);
			if (!is_null($Product)) {
				$Product->status = 3;
				if ($Product->save()) {
					$message->confirm = 1;
					$message->save();
					return $this->redirect('index');
				}else{
					return $this->redirect('index');
				}
			}
		}
		$message->confirm = 1;
		$message->save();
		// Yii::$app->session['farm_user']['message_count'] = Yii::$app->session['farm_user']['message_count']-1;
		return $this->redirect('index');
	}
	
	public function actionJson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
        
        $user_id = Yii::$app->session['farm_user']['user_id'];
		$message = FarmMessage::find()
		           ->with(['product'=>function($query){
		           	  $query->select(['id','start_time','end_time','species_id','name','img_url']);
		           }])
		           ->where(['farm_id'=>$user_id,'confirm'=>0])
		           ->asArray()
		           ->orderBy('mid desc')
		           ->all();
		$data['total'] = FarmMessage::find()->where(['farm_id'=>$user_id])->count();

		foreach ($message as $key => $value) {
			if ($value['forage']!=null) {
				$temp['id'] = $value['mid'];
				$temp['farm_id'] = $value['farm_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'forage';
				$temp['content'] = '饲料更改为：'.$value['forage'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['feed_time']!=null) {
				$temp['id'] = $value['mid'];
				$temp['farm_id'] = $value['farm_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'feed_time';
				$temp['content'] = '养殖时间更改为：'.$value['feed_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['kill_time']!=null) {
				$temp['id'] = $value['mid'];
				$temp['farm_id'] = $value['farm_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'kill_time';
				$temp['content'] = '宰杀时间为：'.$value['kill_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['feed']!=null) {
				$temp['id'] = $value['mid'];
				$temp['farm_id'] = $value['farm_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'feed';
				$temp['content'] = '养殖时间：'.$value['product']['start_time'].'至'.$value['product']['end_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['check']!=null) {
				$temp['id'] = $value['mid'];
				$temp['type'] = 'check';
				$temp['content'] = '您的账户信息修改申请审核未通过';
				$temp['update_time'] = $value['update_time'];
				$data['data'][] = $temp;
			}
		}

		print_r(json_encode($data));
	}
}