<?php 

namespace app\controllers;

use Yii;
use yii\web\Response;
use yii\db\Query;
use yii\web\Controller;
use app\models\Product;
use app\models\FontUser;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_historyController extends Controller
{
	public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
	
	public function actionJson($page=1,$size=10,$time=null){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);

		if ($time) {
			$andWhere = "kill_time='$time'";
		}else{
			$andWhere = '';
		}
		$data['total'] = Product::find()->where('status=6 or status=7')->andWhere($andWhere)->count();

		$data['data'] = Product::find()
		                ->select(['id','farm_id','species_id','name','start_time','end_time','kill_time','output','all_price'])
		                ->with(['species','farm'=>function($query){
		                	$query->select(['id','username']);
		                }])
		                ->limit($size)
		                ->offset($offset)
		                ->where('status=6 or status=7')
		                ->andWhere($andWhere)
		                ->orderBy('id desc')
		                ->asArray()
		                ->all();
        foreach ($data['data'] as $key => $value) {
        	$data['data'][$key]['species'] = $value['species']['name'];
        	$data['data'][$key]['farm'] = $value['farm']['username'];
        }
        return $data;
	}

	public function actionDuringjson($page=1,$size=10,$time=null){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
        
        if (isset($_GET['keyword'])&&$_GET['keyword']!='') {
        	$keyword = $_GET['keyword'];
        	$search1 = (new Query)
	                   ->select('t_order.product_id')
	                   ->from('t_order')
	                   ->leftJoin('t_font_user','t_font_user.id=t_order.user_id')
	                   ->where('t_order.status=202 and t_font_user.username LIKE :keyword',[':keyword'=>'%'.$keyword.'%']);
	        $search2 = (new Query)
	                   ->select('t_product.id')
	                   ->from('t_product')
	                   ->leftJoin('t_farm_user','t_farm_user.id=t_product.farm_id')
	                   ->where('t_product.status=3 and t_farm_user.username LIKE :keyword',[':keyword'=>'%'.$keyword.'%']);
	        $search3 = (new Query)
	                   ->select('t_product.id as product_id')
	                   ->from('t_product')
	                   ->where('t_product.status=3 and t_product.name LIKE :keyword',[':keyword'=>'%'.$keyword.'%'])
	                   // ->limit($size)
	                   // ->offset($offset)
	                   ->union($search1)
	                   ->union($search2)
	                   ->all();
	        if ($search3) {
	        	foreach ($search3 as $key => $value) {
	        		$product_id[] = $value['product_id'];
	        	}
	        }else{
	        	$product_id = [];
	        }
	        
	        $data['total'] = Product::find()
			                ->where(['status'=>3])
			                ->andWhere(['in','id',$product_id])
			                ->count();
	        $data['data'] = Product::find()
			                ->select(['t_product.id','t_product.farm_id','species_id','t_product.name','dorm','start_time','end_time','output','all_price','t_product.status'])
			                ->joinWith(['species','dorm','farm'=>function($query){
			                	$query->select(['t_farm_user.id','username','cellphone']);
			                },'user'=>function($query){
			                	$query->select(['t_order.id','user_id','product_id']);
			                	$query->where('t_order.status=202');
			                }])
			                ->limit($size)
			                ->offset($offset)
			                ->where('t_product.status=3')
			                ->andWhere(['in','t_product.id',$product_id])
			                ->orderBy('t_product.id desc')
			                ->asArray()
			                ->all();
	    }else{
            if ($time) {
				$andWhere = "start_time='$time'";
			}else{
				$andWhere = '';
			}
			$data['total'] = Product::find()->where('status=3')->andWhere($andWhere)->count();

			$data['data'] = Product::find()
			                ->select(['t_product.id','t_product.farm_id','species_id','t_product.name','dorm','start_time','end_time','output','all_price','t_product.status'])
			                ->joinWith(['species','dorm','farm'=>function($query){
			                	$query->select(['t_farm_user.id','username','cellphone']);
			                },'user'=>function($query){
			                	$query->select(['t_order.id','user_id','product_id']);
			                	$query->where('t_order.status=202');
			                }])
			                ->limit($size)
			                ->offset($offset)
			                ->where('t_product.status=3')
			                ->andWhere($andWhere)
			                ->orderBy('t_product.id desc')
			                ->asArray()
			                ->all();
	    }

        foreach ($data['data'] as $key => $value) {
        	$data['data'][$key]['species'] = $value['species']['name'];
        	$data['data'][$key]['dorm'] = $value['dorm']['name'];
        	$data['data'][$key]['dorm_id'] = $value['dorm']['id'];
        	foreach ($value['user'] as $k => $v) {
        		$data['data'][$key]['user'][$k]['username'] = FontUser::find()->where(['id'=>$v['user_id']])->one()->username;
        	}
        }
        return $data;
        // print_r($data);
	}
}