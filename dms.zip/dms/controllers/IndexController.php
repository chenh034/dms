<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use dzer\express\Express;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class IndexController extends Controller
{
	
	public function actionIndex(){
		echo 'hello';
	}

	public function actionTest(){
		$rs = Express::search('424637395896');
		print_r($rs);
	}
}