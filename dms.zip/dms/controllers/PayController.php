<?php

namespace app\controllers;

use yii\web\Controller;
use app\models\Pay;
use Yii;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

class PayController extends Controller
{
    public $enableCsrfValidation = false;
    public function actionNotify()
    {
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            if (Pay::notify($post)) {
                echo "success";
                exit;
            }
            echo "fail";
            exit;
        }
    }


    public function actionReturn()
    {   
        $status = Yii::$app->request->get('trade_status');
        if ($status == 'TRADE_SUCCESS') {
            // return $this->renderPartial('ok');
            return $this->redirect(Yii::$app->request->hostInfo.'/pay/ok');
        } else {
            // return $this->renderPartial('fail');
            return $this->redirect(Yii::$app->request->hostInfo.'/pay/fail');
        }
        // return $this->render("status", ['status' => $s]);
        echo $s;
    }

    public function actionOk(){
        return $this->renderPartial('ok');
    }

    public function actionFail(){
        return $this->renderPartial('fail');
    }

}





