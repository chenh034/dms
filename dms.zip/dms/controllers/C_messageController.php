<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FontMessage;
use app\models\Species;

/**
* 
*/
class C_messageController extends Controller
{
	
	public function actionIndex(){
		$this->layout = 'layout1';
		return $this->render('index');
	}

	public function actionJson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = ($page-1)*$size;

		$user_id = Yii::$app->session['font_user']['user_id'];
		$message = FontMessage::find()
		           ->with(['product'=>function($query){
		           	  $query->select(['id','start_time','end_time','species_id','name','img_url']);
		           }])
		           ->where(['font_id'=>$user_id])
		           ->asArray()
		           ->orderBy('id desc')
		           ->all();
		$data['total'] = FontMessage::find()->where(['font_id'=>$user_id])->count();
		$data['data'] = [];

		foreach ($message as $key => $value) {
			if ($value['forage']!=null) {
				$temp['id'] = $value['id'];
				$temp['font_id'] = $value['font_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'forage';
				$temp['content'] = '饲料更改为：'.$value['forage'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['feed_time']!=null) {
				$temp['id'] = $value['id'];
				$temp['font_id'] = $value['font_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'feed_time';
				$temp['content'] = '养殖时间更改为：'.$value['feed_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['kill']!=null) {
				$temp['id'] = $value['id'];
				$temp['font_id'] = $value['font_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'kill_time';
				$temp['content'] = '已宰杀,宰杀时间为：'.$value['kill_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
			if ($value['feed']!=null) {
				$temp['id'] = $value['id'];
				$temp['font_id'] = $value['font_id'];
				$temp['product_id'] = $value['product_id'];
				$temp['type'] = 'feed';
				$temp['content'] = '已开始养殖：'.$value['product']['start_time'].'至'.$value['product']['end_time'];
				$temp['update_time'] = $value['update_time'];
				$temp['species'] = Species::findOne($value['product']['species_id'])->name;
				$temp['img_url'] = $value['product']['img_url'];
				$temp['name'] = $value['product']['name'];
				$data['data'][] = $temp;
			}
		}

		print_r(json_encode($data));
	}
}