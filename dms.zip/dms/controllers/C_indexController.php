<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\FarmUser;
use app\models\ProductComment;
use app\models\Species;
use app\models\HandBook;
use app\models\QuestionType;
use app\models\Question;
use app\models\Infos;
use app\models\IndexImg;
use app\models\Setmeal;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_indexController extends Controller
{
	
  	public function actionIndex(){
      		// $Product = Product::find()->select(['id','farm_id','species_id','foundation_weight','img_url','rate','start_time'])
        //               ->with(['species'=>function($query){
        //               	$query->select('id,name');
        //               },'farm'=>function($query){
      		//         	$query->select('id,account_place');
      		//         }])
        //               ->limit(4)
        //               ->where(['type'=>2,'status'=>1])
        //               ->orderBy('rate desc')
        //               ->asArray()
        //               ->all();

          $IndexImg = IndexImg::find()->where(['is_show'=>1])->orderBy('id desc')->asArray()->all();
              
          $Comment = ProductComment::find()
                     ->select(['id','user_id','content','product_id','createtime','main_level','fresh_level','log_level'])
                     ->with(['product'=>function($query){
                        $query->select(['id','farm_id','species_id','output','start_time','end_time']);
                     },'user'=>function($query){
                        $query->select(['id','username','nickname']);
                     },'pics'])
                     ->limit(3)
                     ->orderBy('id desc')
                     ->where(['is_index_show'=>1])
                     ->asArray()
                     ->all();

          // foreach ($Product as $key => $value) {
          //     $Product[$key]['species'] = $value['species']['name'];
          //     $Product[$key]['farm_place'] = $value['farm']['account_place'];
          //     unset($Product[$key]['farm']);
          // }

          foreach ($Comment as $key => $value) {
              $Comment[$key]['output'] = $value['product']['output'];
              $Comment[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;
              $Comment[$key]['feed_time'] = (strtotime($value['product']['end_time'])-strtotime($value['product']['start_time']))/(3600*24);
              $Comment[$key]['nickname'] = $value['user']['nickname'];
              $Comment[$key]['farm'] = FarmUser::find()->where(['id'=>$value['product']['farm_id']])->asArray()->one();
              if ($value['pics']==null) {
                $Comment[$key]['pic'] = null;
              }
              foreach ($value['pics'] as $k => $v) {
                  $Comment[$key]['pic'][] = $v['img_url'];
              }
              unset($Comment[$key]['pics']);
              unset($Comment[$key]['user']);
              unset($Comment[$key]['product']);
          }
        
          // $data['product'] = $Product;
          $data['IndexImg'] = $IndexImg;
          $data['Comment'] = $Comment;
          $data['farm_num'] = FarmUser::find()->count();
          $data['product_num'] = Product::find()->count();
          
          Yii::$app->session['returnUrl'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
          $this->layout = 'layout1';
          return $this->render("index", ['data' => $data]);
    }

    public function actionArticlelist(){
        $list = HandBook::find()->select(['id','title'])->where(['mark'=>1])->limit(8)->asArray()->all();
        $this->layout = 'layout1';
        return $this->renderPartial('articlelist',['toplist'=>$list]);
    }


    public function actionArticlejson($page=1,$size=10){
        $page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);

        $data['total'] = HandBook::find()->count();
        $data['data'] = HandBook::find()
                        ->limit($size)
                        ->offset($offset)
                        ->orderBy('id desc')
                        ->asArray()
                        ->all();
        foreach ($data['data'] as $key => $value) {
            $data['data'][$key]['update_time'] = date('Y-m-d',$value['update_time']);
            $data['data'][$key]['content'] = mb_substr(strip_tags(trim($value['content'])), 0,60,'utf-8');
        }

        print_r(json_encode($data));


    }

    public function actionArticle($id){
        $id = (int)$id;

        $list = HandBook::find()->select(['id','title'])->limit(8)->asArray()->all();

        $data = HandBook::findOne($id);

        return $this->renderPartial('article',['data'=>$data,'toplist'=>$list]);
    }


    public function actionQuestion(){
        $type = QuestionType::find()->asArray()->all();
        
        foreach ($type as $key => $value) {
          $data[] = ['type'=>$value['name'],
                     'content'=>Question::find()
                          ->select(['id','title','answer'])
                          ->where(['type_id'=>$value['id']])
                          ->orderBy('id desc')
                          ->asArray()
                          ->all()];
        }

        $this->layout = 'layout1';
        return $this->renderPartial('question',['data'=>$data]);
    }


    public function actionCommentlist(){
        $product_num = Product::find()->count();
        $this->layout = 'layout1';
        return $this->renderPartial('commentlist',['product_num'=>$product_num]);
    }

    public function actionCommentjson($page=1,$size=8){
        $page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);

        $Comment = ProductComment::find()
                     ->select(['id','user_id','content','product_id','createtime','main_level','fresh_level','log_level'])
                     ->with(['product'=>function($query){
                        $query->select(['id','farm_id','species_id','output','start_time','end_time']);
                     },'user'=>function($query){
                        $query->select(['id','username','nickname']);
                     },'pics'])
                     ->limit($size)
                     ->offset($offset)
                     ->orderBy('id desc')
                     ->where(['is_index_show'=>1])
                     ->asArray()
                     ->all();

        foreach ($Comment as $key => $value) {
                      $Comment[$key]['createtime'] = date('Y年m月d日',$value['createtime']);
                      $Comment[$key]['output'] = $value['product']['output'];
                      $Comment[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;
                      $Comment[$key]['farm'] = FarmUser::find()->where(['id'=>$value['product']['farm_id']])->asArray()->one();
                      $Comment[$key]['feed_time'] = (strtotime($value['product']['end_time'])-strtotime($value['product']['start_time']))/(3600*24);
                      $Comment[$key]['nickname'] = $value['user']['nickname'];
                      if ($value['pics']==null) {
                        $Comment[$key]['pic'] = null;
                      }
                      foreach ($value['pics'] as $k => $v) {
                          $Comment[$key]['pic'][] = $v['img_url'];
                      }
                      unset($Comment[$key]['pics']);
                      unset($Comment[$key]['user']);
                      unset($Comment[$key]['product']);
                  }
        $data['total'] = ProductComment::find()->where(['is_index_show'=>1])->count();
        $data['data'] = $Comment;
        print_r(json_encode($data));
    }

    public function actionInfos($id){
        $id = (int)$id;
        $Infos = Infos::find()->where(['id'=>$id])->asArray()->one();
        $this->layout = 'layout1';
        return $this->render('infos',['infos'=>$Infos]);
    }

    public function actionSearchlist(){
        if (Yii::$app->request->isPost) {
          $post = Yii::$app->requset->post();
          return $this->redirect(['searchlist','keyword'=>$post['keyword']]);
        }
        $this->layout = 'layout1';
        return $this->render('searchlist');
    }

    public function actionSearchjson($page=1,$size=12,$keyword=''){
      $page = (int)$page;
      $size = (int)$size;
      $offset = $size*($page-1);
          
      $data['total'] = Product::find()
                       ->joinWith(['species'=>function($query){
                                  $query->select('t_species.id,t_species.name');
                                },'farm'=>function($query){
                                  $query->select('t_farm_user.id,t_farm_user.account_place');
                              },'forage'=>function($query){
                                  $query->select('t_forage_type.id,t_forage_type.name');
                              }])
                       ->where('status=1 AND is_ok=1 and (t_species.name LIKE :keyword OR t_forage_type.name LIKE :keyword OR t_farm_user.pca LIKE :keyword)',[':keyword'=>'%'.$keyword.'%'])
                       ->count();

      $Product = Product::find()
                ->select(['t_product.id','farm_id','type','species_id','forage_id','birthday','foundation_weight','foundation_price','t_product.img_url','rate','start_time','end_time'])
                ->joinWith(['species'=>function($query){
                    $query->select('t_species.id,t_species.name');
                  },'farm'=>function($query){
                    $query->select('t_farm_user.id,t_farm_user.account_place,pca,farm_name');
                },'forage'=>function($query){
                    $query->select('t_forage_type.id,t_forage_type.name');
                }])
                ->limit($size)
                ->offset($offset)
                ->where('status=1 AND is_ok=1 and (t_species.name LIKE :keyword OR t_forage_type.name LIKE :keyword OR t_farm_user.pca LIKE :keyword OR t_farm_user.farm_name LIKE :keyword)',[':keyword'=>'%'.$keyword.'%'])
                ->orderBy('id desc')
                ->asArray()
                ->all();
      foreach ($Product as $key => $value) {
          if ($value['type']==1) {
            $Product[$key]['product_type'] = '认养';
            $Product[$key]['species'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>',$value['species']['name']);
            $Product[$key]['farm_place'] =str_replace($keyword, '<font color=red>'.$keyword.'</font>',$value['farm']['pca']);
            $Product[$key]['farm_name'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>', $value['farm']['farm_name']);
            unset($Product[$key]['farm']);
            unset($Product[$key]['forage']);
          }else if ($value['type']==2) {
            $setmeal_total = Setmeal::find()->where(['product_id'=>$value['id']])->count();
            $Product[$key]['product_type'] = '共筹';
            $Product[$key]['species'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>', $value['species']['name']);
            $Product[$key]['farm_place'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>', $value['farm']['pca']);
            $Product[$key]['farm_name'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>', $value['farm']['farm_name']);
            $Product[$key]['forage'] = str_replace($keyword, '<font color=red>'.$keyword.'</font>', $value['forage']['name']);
            $Product[$key]['rate'] = sprintf("%.2f", $value['rate']/$setmeal_total);
            unset($Product[$key]['farm']);
          }
      }

      $data['data'] = $Product;

      print_r(json_encode($data));
    }

    public function actionTest(){
        echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    }
}