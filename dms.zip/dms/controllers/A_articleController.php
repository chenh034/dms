<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\HandBook;
use crazyfd\qiniu\Qiniu;
use yii\web\Response;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_articleController extends Controller
{   
	public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
	
	public function actionAdd(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['update_time'] = time();

			if (isset($_FILES['cover'])) {
				$post['img_url'] = $this->uploadPic();
			}

			$HandBook = new HandBook;
			$add_status = $HandBook->addArticle($post);

			print_r(json_encode($add_status));

		}
	}

	public function actionEdit($id){
		$id = (int)$id;
		$HandBook = HandBook::findOne($id);

		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['update_time'] = time();
			$post['img_url'] = $HandBook->img_url;

			if (isset($_FILES['cover']) && $_FILES['cover']['error']==0) {
				$this->delPic($HandBook->img_url);
				$post['img_url'] = $this->uploadPic();
			}

			$edit_status = $HandBook->editArticle($post);

			print_r(json_encode($edit_status));
			return;

		}
		if (!is_null($HandBook)) {
			print_r(json_encode($HandBook->attributes));
		}else{
			print_r(json_encode([]));
		}
		
	}

	public function actionDel($id){
		$id = (int)$id;
		$HandBook = HandBook::findOne($id);
		if (!is_null($HandBook)) {
			$this->delPic($HandBook->img_url);
			if ($HandBook->delete()) {
				print_r(json_encode(['code'=>0]));
			}else{
				print_r(json_encode(['code'=>1]));
			}
		}else{
			print_r(json_encode(['code'=>0]));
		}
	}

	public function actionBatchdel(){
        Yii::$app->response->format = Response::FORMAT_JSON;
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $tr = Yii::$app->db->beginTransaction();
            try{
                foreach ($post['ids'] as $key => $value) {
                    $HandBook = HandBook::findOne($value);
                    if (!$HandBook->delete()) {
                        throw new Exception("删除失败");    
                    }
                }
                $tr->commit();
            }catch (\Exception $e){
                $tr->rollBack();
                $err = [
                    'code' => $e->getCode(),
                    'msg'  => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'   => $e->getLine()
                ];
                return ['code'=>1,'data'=>$err['msg']];
            }
            return ['code'=>0];
        }
    }

	public function actionJson($page=1,$size=10,$start_time=null,$end_time=null){
		$page = (int)$page;
		$size = (int)$size;
        $offset = $size*($page-1);

        if ($start_time!=null) {
            $start_time = strtotime($start_time);
        }else{
        	$start_time = 0;
        }

        if ($end_time!=null) {
        	$end_time = strtotime($end_time)+3600*24;
        }else{
        	$end_time = time();
        }

        $data['total'] = HandBook::find()->where("update_time between $start_time and $end_time")->count();
        $data['data'] = HandBook::find()
                        ->select(['id','title','img_url','update_time','is_top','mark','important'])
                        ->limit($size)
                        ->offset($offset)
                        ->where("update_time between $start_time and $end_time")
                        ->orderBy('id desc')
                        ->asArray()
                        ->all();
        print_r(json_encode($data));
	}

	public function actionTop($id,$status){
        $id = (int)$id;
        $status = (int)$status;

        $HandBook = HandBook::findOne($id);
        $HandBook->is_top = $status;
        if ($HandBook->save()) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1]));
        }
	}

	public function actionMark($id,$status){
        $id = (int)$id;
        $status = (int)$status;

        $HandBook = HandBook::findOne($id);
        $HandBook->mark = $status;
        if ($HandBook->save()) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1]));
        }
	}

	public function actionImportant($id,$important){
        $id = (int)$id;
        $important = (int)$important;

        $HandBook = HandBook::findOne($id);
        $HandBook->important = $important;
        if ($HandBook->save()) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1,'data'=>$HandBook->getErrors()]));
        }
	}


	private function uploadPic(){
		if ($_FILES['cover']['error'] > 0) {
			return false;
		}
		$qiniu = new Qiniu(HandBook::AK, HandBook::SK, HandBook::DOMAIN, HandBook::BUCKET);
		$key = uniqid();
        $qiniu->uploadFile($_FILES['cover']['tmp_name'], $key);
        $img_url = $qiniu->getLink($key);

        return $img_url;
	}

	private function delPic($link){
		$qiniu = new Qiniu(HandBook::AK, HandBook::SK, HandBook::DOMAIN, HandBook::BUCKET);
        $qiniu->delete(basename($link));
	}

}