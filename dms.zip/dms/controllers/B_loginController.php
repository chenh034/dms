<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FarmUser;
use app\models\FarmMessage;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_loginController extends Controller
{
	public function actionTologin(){
		return $this->renderPartial('login');
	}
	
	public function actionLogin(){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		if (!Yii::$app->request->isPost) {
			return $this->redirect(['b_login/tologin']);
		}

		$post = Yii::$app->request->post();
		
		$FarmUser = new FarmUser;
		$login_status = $FarmUser->login($post);

		if ($login_status['code']==0) {
			$user_id = FarmUser::find()->where(['username'=>$login_status['data']['username']])->one()->id;
			Yii::$app->session['farm_user'] = ['user_id'=>$user_id,
			                                   'username'=>$login_status['data']['username'],
			                                   'is_login'=>1,
			                                   'message_count'=>FarmMessage::find()->where(['farm_id'=>$user_id])->count()];
			// $login_status['data']['user_id'] = $user_id;
			return $this->redirect(['b_product/list']);
		}else{
			// var_dump($login_status);die();
            $errs = $this->getoneMessage($login_status['data']);
            $err_one = $errs[0];
            Yii::$app->session->setFlash("error",$err_one);
            return $this->redirect(['b_login/tologin']);
		}
		
	}

	public function actionLogout(){
		if (isset(Yii::$app->session['farm_user'])) {
			Yii::$app->session->remove('farm_user');
			return $this->redirect(['b_login/tologin']);
		}else{
			return $this->redirect(['b_login/tologin']);
		}
	}

	public function getoneMessage($data){
		static $arr = [];
        foreach ($data as $key => $value) {
        	if (is_array($value)) {
        		$this->getoneMessage($value);
        	}else{
        		$arr[] = $value;
        	}
        }
        return $arr;
	}
}