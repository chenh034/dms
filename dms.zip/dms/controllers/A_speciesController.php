<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Species;
use yii\web\Response;
use crazyfd\qiniu\Qiniu;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_speciesController extends Controller
{

    public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
	

	public function actionToAdd(){
        $SpeciesType = Species::find()->select(['id','name'])->where(['parent_id'=>0])->asArray()->all();
        // print_r($SpeciesType);
	}

	public function actionParent(){
		Yii::$app->response->format = Response::FORMAT_JSON;

		$SpeciesType = Species::find()->select(['id','name'])->where(['parent_id'=>0,'is_use'=>1])->asArray()->all();
		$data = ['data'=>$SpeciesType];
		return $data;
	}


	public function actionAdd(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
            
            $check = Species::find()->where(['name'=>trim($post['name']),'is_use'=>1])->one();
            if (!is_null($check)) {
            	$add_status = ['code'=>3];
            	return $add_status;
            }
            if ($post['parent_id']!=0) {
            	$img_url = $this->uploadPic();
            }else{
            	$post['special'] = '<---->';
            	$post['introduce'] = '#';
            	$img_url = '#';
            }
			
			$post['img_url'] = $img_url;


			$Species = new Species;
			$add_status = $Species->addSpecies($post);

			return $add_status;
		}
	}


	public function actionEdit($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
        $Species = Species::findOne($id);
        if (Yii::$app->request->isPost) {
        	$post = Yii::$app->request->post();
        	$post['img_url'] = $Species->img_url;
        	if (isset($_FILES['cover']) && $_FILES['cover']['error']==0) {
				$img_url = $this->uploadPic();
				$post['img_url'] = $img_url;
				if ($Species->img_url) {
					$this->delPic($Species->img_url);
				}
			}

        	$edit_status = $Species->editSpecies($post);
        	if ($edit_status['code']==0) {
        		$status = ['code'=>0];
        	}else{
        		$status = ['code'=>1];
        	}
        	return $status;
        }
        return $Species->attributes;

	}

	public function actionDel($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
		$Species = Species::findOne($id);
		// print_r($Species);die();
		if (!is_null($Species)) {
			// $delPic = $this->delPic($Species->img_url);
            $Species->is_use = 0;
			if ($Species->save()) {
				$status = ['code'=>0];
			}else{
				$status = ['code'=>1];
			}
		}else{
			$status = ['code'=>0];
		}
		return $status;
	}

    public function actionBatchdel(){
        Yii::$app->response->format = Response::FORMAT_JSON;
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $tr = Yii::$app->db->beginTransaction();
            try{
                foreach ($post['ids'] as $key => $value) {
                    $Species = Species::findOne($value);
                    $Species->is_use = 0;
                    if (!$Species->save()) {
                        throw new Exception("删除失败");    
                    }
                }
                $tr->commit();
            }catch (\Exception $e){
                $tr->rollBack();
                $err = [
                    'code' => $e->getCode(),
                    'msg'  => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'   => $e->getLine()
                ];
                return ['code'=>1,'data'=>$err['msg']];
            }
            return ['code'=>0];
        }
    }

	public function actionJson($page=1,$size,$parent_id=null){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
        $offset = $size*($page-1);
        
        if ($parent_id==null) {
        	$data = Species::find()->select(['id','name','special','parent_id','introduce','img_url'])
                ->with(['parent'=>function($query){
                	$query->select('id,name');
                }])
                ->offset($offset)
                ->limit($size)
                ->orderBy('id desc')
                ->where(['is_use'=>1])
                ->asArray()
                ->all();
            $total = Species::find()->where(['is_use'=>1])->count();
        }else{
        	$data = Species::find()->select(['id','name','special','parent_id','introduce','img_url'])
                ->with(['parent'=>function($query){
                	$query->select('id,name');
                }])
                ->offset($offset)
                ->limit($size)
                ->orderBy('id desc')
                ->where(['parent_id'=>$parent_id,'is_use'=>1])
                ->asArray()
                ->all();
            $total = Species::find()->where(['parent_id'=>$parent_id,'is_use'=>1])->count();
        }
        

        foreach ($data as $key => $value) {
        	if (!is_null($value['parent'])) {
        		$data[$key]['parent_name'] = $value['parent']['name'];
        	}else{
        		$data[$key]['parent_name'] = '无';
        	}
        	unset($data[$key]['parent']);
        }

        $data = ['total'=>$total,'data'=>$data];
        return $data;
	}


	private function uploadPic(){
		if ($_FILES['cover']['error'] > 0) {
			return false;
		}
		$qiniu = new Qiniu(Species::AK, Species::SK, Species::DOMAIN, Species::BUCKET);
		$key = uniqid();
        $qiniu->uploadFile($_FILES['cover']['tmp_name'], $key);
        $img_url = $qiniu->getLink($key);

        return $img_url;
	}

	private function delPic($link){
		$qiniu = new Qiniu(Species::AK, Species::SK, Species::DOMAIN, Species::BUCKET);

        $status = $qiniu->delete(basename($link));
        return $status;
	}

}
