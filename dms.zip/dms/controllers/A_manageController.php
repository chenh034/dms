<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FarmUser;
use app\models\Forage;
use app\models\ForageOffer;
use app\models\Area;
use app\models\City;
use app\models\Province;
use yii\web\Response;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_manageController extends Controller
{
	
    public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }

    public function actionCheck(){
        Yii::$app->response->format = Response::FORMAT_JSON;
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $status = FarmUser::find()->where(['username'=>trim($post['username'])])->one();
            if (is_null($status)) {
                return ['code'=>0];
            }else{
                return ['code'=>1];
            }
        }
    }
    
	public function actionAdd(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$FarmUser = new FarmUser;

			$post['forage_offer'] = implode(',', $post['forage_offer']);

            $area = Area::find()->where(['areaID'=>$post['area_id']])->one();
            $city = City::find()->where(['cityID'=>$area->fatherID])->one();
            $province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
            $address['area'] = $area->area;
            $address['city'] = $city->city;
            $address['province'] = $province->province;
            $post['pca'] = $address['province'].$address['city'].$address['area'];
            
            $add_status = $FarmUser->addUser($post,'add');
			
			return $add_status;

		}
		return ['code'=>1,'data'=>['status'=>'请求方式错误']];
	}

    public function actionEdit($id){
    	Yii::$app->response->format = Response::FORMAT_JSON;
    	$id = (int)$id;
    	$FarmUser = FarmUser::findOne($id);
    	if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
            if ($post['password']=='') {
                unset($post['password']);
            }else{
                $post['password'] = md5($post['password']);
            }

			$post['forage_offer'] = implode(',', $post['forage_offer']);

            $area = Area::find()->where(['areaID'=>$post['area_id']])->one();
            $city = City::find()->where(['cityID'=>$area->fatherID])->one();
            $province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
            $address['area'] = $area->area;
            $address['city'] = $city->city;
            $address['province'] = $province->province;
            $post['pca'] = $address['province'].$address['city'].$address['area'];
            
            $edit_status = $FarmUser->editUser($post,'add');

            $this->editForage(explode(',', $post['forage_offer']),$id);
			
			return $edit_status;

		}
		$FarmUser->forage_offer = explode(',', $FarmUser->forage_offer);

        $area = Area::find()->where(['areaID'=>$FarmUser->area_id])->one();
        $city = City::find()->where(['cityID'=>$area->fatherID])->one();
        $province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
        $address['area'] = $area->area;
        $address['city'] = $city->city;
        $address['province'] = $province->province;

        $data['data'] = $FarmUser->attributes;
        $data['address'] = $address;

		return $data;

    }

    public function actionDel($id){
    	Yii::$app->response->format = Response::FORMAT_JSON;
    	$id = (int)$id;
    	$FarmUser = FarmUser::findOne($id);
    	if (!is_null($FarmUser)) {
    		if ($FarmUser->delete()) {
    			return ['code'=>0];
    		}else{
    			return ['code'=>1];
    		}
    	}else{
    		return ['code'=>0];
    	}
    }

    public function actionJson($page=1,$size=5){
    	Yii::$app->response->format = Response::FORMAT_JSON;
    	$page = (int)$page;
    	$size = (int)$size;
    	$offset = $size*($page-1);

        $data['total'] = FarmUser::find()->count();
    	$data['data'] = FarmUser::find()
    	        ->select(['id','username','detail_place','name','cellphone'])
    	        ->limit($size)
    	        ->offset($offset)
                ->orderBy('id desc')
    	        ->asArray()
    	        ->all();

    	return $data;
    }

    public function editForage($data,$farm_id){
        $forage = [];
        foreach ($data as $key => $value) {
            $ForageOffer = ForageOffer::find()->where(['forage_id'=>$value,'farm_id'=>$farm_id])->one();
            $forage[$key]['farm_id'] = $farm_id;
            $forage[$key]['forage_id'] = $value;
            if (!is_null($ForageOffer)) {
                $forage[$key]['price'] = $ForageOffer->price;
            }else{
                $forage[$key]['price'] = 0;
            }
        }
        ForageOffer::deleteAll(['farm_id'=>$farm_id]);
        $status = Yii::$app->db->createCommand()
                  ->batchInsert(ForageOffer::tableName(),['farm_id','forage_id','price'],$forage)
                  ->execute();
        return $status;
    }

}