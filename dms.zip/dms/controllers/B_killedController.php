<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\Order;
use app\models\OrderRaised;
use app\models\Province;
use app\models\City;
use app\models\Area;
use app\component\Express;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_killedController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}
	
	public function actionList(){
		$this->layout = 'layout2';
		return $this->render('list');
	}
	
	public function actionJson($page=1,$size=10,$status=null){
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		$size = (int)$size;
		$page = (int)$page;
		$offset = $size*($page-1);
		$status = (int)$status;

		if ($status) {
			$data['total'] = Product::find()->where(['is_ok'=>1,'status'=>$status])->count();
			$data['data'] = Product::find()
		        ->select(['id','species_id','name','type','end_time','output','status'])
		        ->with(['species'=>function($query){
		        	$query->select('id,name');
		        },'result'=>function($query){
		        	$query->select('product_id,total_weight');
		        }])
		        ->offset($offset)
		        ->limit($size)
		        ->orderBy('id desc')
		        ->where(['farm_id'=>$farm_id,'is_ok'=>1,'status'=>$status])
		        ->asArray()
		        ->all();
		}else{
			$data['total'] = Product::find()->where('status in (4,5,6)')->andWhere('is_ok=1')->count();
			$data['data'] = Product::find()
		        ->select(['id','species_id','name','type','end_time','output','status'])
		        ->with(['species'=>function($query){
		        	$query->select('id,name');
		        },'result'=>function($query){
		        	$query->select('product_id,total_weight');
		        }])
		        ->offset($offset)
		        ->limit($size)
		        ->orderBy('id desc')
		        ->where('status in (4,5,6)')
		        ->andWhere(['farm_id'=>$farm_id,'is_ok'=>1])
		        ->asArray()
		        ->all();
		}
		foreach ($data['data'] as $key => $value) {
			if ($value['type']==1) {
				$data['data'][$key]['type'] = '认养';
			}else{
				$data['data'][$key]['type'] = '共筹';
			}

			if ($value['status']==4) {
				$data['data'][$key]['status'] = '待发货';
				$data['data'][$key]['op'] = '分配发货';
				$data['data'][$key]['href'] = 'assignlog?id='.$value['id'];
			}else if ($value['status']==5) {
				$data['data'][$key]['status'] = '待收货';
				$data['data'][$key]['op'] = '查看物流';
				$data['data'][$key]['href'] = 'checklog?id='.$value['id'];
			}else if ($value['status']==6) {
				$data['data'][$key]['status'] = '交易完成';
				$data['data'][$key]['op'] = '查看评价';
				$data['data'][$key]['href'] = '#';
			}
		}


		print_r(json_encode($data));
	}

	public function actionDetail($id){
        $id = (int)$id;

        $data = Product::find()
                ->select(['id','farm_id','species_id','name','start_time','end_time','img_url','output'])
                ->with(['species'=>function($query){
		        	$query->select('id,name');
		        },'result'=>function($query){
		        	$query->select('product_id,total_weight,content');
		        },'farm'=>function($query){
		        	$query->select('id,account_place');
		        }])
		        ->where(['id'=>$id])
		        ->asArray()
		        ->one();
		$object = json_decode($data['result']['content']);
		$content = [];
		foreach ($object as $key => $value) {
			foreach ($value as $k => $v) {
				$content[$k][$key] = $v;
				$content[$k]['all'] = $object->number[$k]*$object->weight[$k];
			}
		}
		$data['result']['content'] = $content;

		$this->layout = 'layout2';
		return $this->render('output_detail',['product'=>$data]);
	}

	public function actionAssignlog($id){
		$id = (int)$id;
		$Product = Product::find()
		                   ->select(['id','species_id','name','start_time','end_time','img_url'])
		                   ->with('species')
		                   ->where(['id'=>$id])
		                   ->asArray()
		                   ->one();
		$Order = Order::find()
		                ->select(['id','product_id','product_type','address_id','express_num','express'])
		                ->with('address')
		                ->where(['product_id'=>$id,'status'=>Order::PAYSUCCESS])
		                ->orWhere(['status'=>Order::SENDED])
		                ->asArray()
		                ->all();

		foreach ($Order as $key => $value) {
			if ($value['product_type']==1) {
				$Order[$key]['type'] = '认养';
				$Order[$key]['content'] = [];
			}else if ($value['product_type']==2) {
				$Order[$key]['type'] = '共筹';
				$detail = OrderRaised::find()
				          ->with(['setmeal'=>function($query){
				          	$query->select(['id','index']);
				          }])
				          ->where(['order_id'=>$value['id']])
				          ->asArray()
				          ->all();
				foreach ($detail as $k => $v) {
					$Order[$key]['content'][] = '套餐'.$v['setmeal']['index'];
				}
				
			}
			$area = Area::find()->where(['areaID'=>$value['address']['area_id']])->one();
			$city = City::find()->where(['cityID'=>$area->fatherID])->one();
			$province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
			$address['area'] = $area->area;
			$address['city'] = $city->city;
			$address['province'] = $province->province;
			$Order[$key]['address']['address'] = $address;
		}

		$this->layout = 'layout2';
		return $this->render('assignlog',['product'=>$Product,'order'=>$Order,'express'=>Order::$express]);
	}

	public function actionLog(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			foreach ($post as $key => $value) {
				$Order = Order::findOne($key);
				$Order->status = Order::SENDED;
				$Order->express = $value['express'];
				$Order->express_num = $value['express_num'];
				if ($Order->save()) {
					$status = 1;
				}else{
					$status = 0;
				}
			}
			$Product = Product::findOne($Order->product_id);
			$Product->status = 5;
			$Product->save();
            if ($status==1) {
            	Yii::$app->session->setFlash('log_status','提交成功');
            	return $this->redirect(['assignlog','id'=>$Order->product_id]);
            }else{
            	Yii::$app->session->setFlash('log_status','提交失败');
            	return $this->redirect(['assignlog','id'=>$Order->product_id]);
            }
		}
	}

	public function actionChecklog($id){
		$id = (int)$id;
		$Order = Order::find()
		                ->select(['id','express_num','express'])
		                ->where(['product_id'=>$id,'status'=>Order::SENDED])
		                ->asArray()
		                ->all();
		foreach ($Order as $key => $value) {
			$Express = Express::search($value['express_num']);
			$Order[$key]['express'] = json_decode($Express);
		}
		// print_r($Order);die();
        
        $this->layout = 'layout2';
		return $this->render('checklog',['order'=>$Order]);
	}
}