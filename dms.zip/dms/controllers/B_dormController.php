<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Dorm;


/**
* 
*/
class B_dormController extends Controller
{   
	public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }

    public function actionList(){
        // 
        $this->layout = 'layout2';
        return $this->render('list');
    }

    public function actionJson($page=1,$size=10){
        $page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);

        $user_id = Yii::$app->session['farm_user']['user_id'];
        
        $data['total'] = Dorm::find()->where(['farm_id'=>$user_id])->count();

        $data['data'] = Dorm::find()
                        ->limit($size)
                        ->offset($offset)
                        ->orderBy('id desc')
                        ->where(['farm_id'=>$user_id])
                        ->asArray()
                        ->all();
        print_r(json_encode($data));

    }

    public function actionAdd(){
        $this->layout = 'layout2';
        $user_id = Yii::$app->session['farm_user']['user_id'];
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $Dorm = new Dorm;
            $Dorm->farm_id = $user_id;
            $Dorm->name = $post['name'];
            $Dorm->url = $post['url'];
            // $Dorm->deviceSerial = $post['deviceSerial'];
            // $Dorm->validateCode = $post['validateCode'];
            if ($Dorm->save()) {
                // Yii::$app->session->setFlash('status','添加成功');
                return $this->redirect('list');
            }else{
                // Yii::$app->session->setFlash('status','添加失败');
                return $this->redirect('list');
            }
        }
        return $this->render('add');
    }

    public function actionUpdate($id){
        $id = (int)$id;
        $Dorm = Dorm::findOne($id);
        if (!is_null($Dorm)) {
            if (Yii::$app->request->isPost) {
                $post = Yii::$app->request->post();
                $Dorm->name = $post['name'];
                $Dorm->url = $post['url'];
                // $Dorm->deviceSerial = $post['deviceSerial'];
                // $Dorm->validateCode = $post['validateCode'];
                if ($Dorm->save()) {
                    Yii::$app->session->setFlash('status','修改成功');
                    return $this->redirect(['toupdate','id'=>$id]);
                }else{
                    Yii::$app->session->setFlash('status','修改失败');
                    return $this->redirect(['toupdate','id'=>$id]);
                }
            }
            
        }
    }


    public function actionToupdate($id){
        $id = (int)$id;
        $Dorm = Dorm::findOne($id);
        if (!is_null($Dorm)) {
            $this->layout = 'layout2';
            return $this->render('update',['dorm'=>$Dorm]);
        }
    }

    public function actionDel($id){
        
    }


	
	

}