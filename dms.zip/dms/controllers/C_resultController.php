<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\Order;
use app\models\Setmeal;
use app\models\Species;
use app\models\City;
use app\models\Area;
use app\models\Province;
use app\models\ForageType;
use app\models\FarmResult;
use app\component\Express;

/**
* 
*/
class C_resultController extends Controller
{
    public function behaviors(){
         return [
            'font' => [
                'class' => 'app\component\FontFilter'//调用过滤器
            ]
        ];
    }
	
	public function actionIndex(){
		$user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('index');
	}

	public function actionJson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$user_id = Yii::$app->session['font_user']['user_id'];
        
        $data['total'] = Order::find()
                 ->joinWith(['product'=>function($query){
                 	$query->where('t_product.status>2');
                 }])
                 ->where(['user_id'=>$user_id])
                 ->andWhere('t_order.status>'.Order::PAYFAILED)
                 ->count();
        $orders = Order::find()
                 ->select(['t_order.id','product_id','amount','product_type','t_order.status'])
                 ->joinWith(['product'=>function($query){
                 	$query->select(['t_product.id','img_url','species_id','t_product.status']);
                 	$query->where('t_product.status>2');
                 }])
                 ->with(['detail'=>function($query){
                 	$query->select(['id','order_id','setmeal_id']);
                 }])
                 ->limit($size)
                 ->offset($offset)
                 ->where(['user_id'=>$user_id])
                 ->andWhere('t_order.status>'.Order::PAYFAILED)
                 ->orderBy('t_order.id desc')
                 ->asArray()
                 ->all();
        // print_r($orders);die();
        foreach ($orders as $key => $value) {
        	if ($value['product_type']==1) {
        		$orders[$key]['product_type'] = '认养';
        		$orders[$key]['info'] = '整猪';
        	}else if ($value['product_type']==2) {
        		$orders[$key]['product_type'] = '共筹';
        		foreach ($value['detail'] as $k => $v) {
        			$orders[$key]['info'][] = Setmeal::find()->where(['id'=>$v['setmeal_id']])->one()->index;
        		}
        	}
        	$orders[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;

        }


        $data['data'] = $orders;
        print_r(json_encode($data));

	}
    
    public function actionWait(){
    	$user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('wait');
    }

	public function actionWaitjson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$user_id = Yii::$app->session['font_user']['user_id'];
        
        $data['total'] = Order::find()
                 ->joinWith(['product'=>function($query){
                 	$query->where('t_product.status>2');
                 }])
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::PAYSUCCESS])
                 ->count();
        $orders = Order::find()
                 ->select(['t_order.id','product_id','amount','product_type','t_order.status'])
                 ->joinWith(['product'=>function($query){
                 	$query->select(['t_product.id','img_url','species_id','t_product.status']);
                 	$query->where('t_product.status>2');
                 }])
                 ->with(['detail'=>function($query){
                 	$query->select(['id','order_id','setmeal_id']);
                 }])
                 ->limit($size)
                 ->offset($offset)
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::PAYSUCCESS])
                 ->orderBy('t_order.id desc')
                 ->asArray()
                 ->all();

        foreach ($orders as $key => $value) {
        	if ($value['product_type']==1) {
        		$orders[$key]['product_type'] = '认养';
        		$orders[$key]['info'] = '整猪';
        	}else if ($value['product_type']==2) {
        		$orders[$key]['product_type'] = '共筹';
        		foreach ($value['detail'] as $k => $v) {
        			$orders[$key]['info'][] = Setmeal::find()->where(['id'=>$v['setmeal_id']])->one()->index;
        		}
        	}
        	$orders[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;

        }

        $data['data'] = $orders;
        print_r(json_encode($data));
	}

	public function actionSend(){
		$user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('send');
	}

	public function actionSendjson($page=1,$size=10){
		$page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);
        $user_id = Yii::$app->session['font_user']['user_id'];
        
        $data['total'] = Order::find()
                 ->joinWith(['product'=>function($query){
                    $query->where('t_product.status>2');
                 }])
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::SENDED])
                 ->count();
        $orders = Order::find()
                 ->select(['t_order.id','product_id','amount','product_type','t_order.status'])
                 ->joinWith(['product'=>function($query){
                    $query->select(['t_product.id','img_url','species_id','t_product.status']);
                    $query->where('t_product.status>2');
                 }])
                 ->with(['detail'=>function($query){
                    $query->select(['id','order_id','setmeal_id']);
                 }])
                 ->limit($size)
                 ->offset($offset)
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::SENDED])
                 ->orderBy('t_order.id desc')
                 ->asArray()
                 ->all();

        foreach ($orders as $key => $value) {
            if ($value['product_type']==1) {
                $orders[$key]['product_type'] = '认养';
                $orders[$key]['info'] = '整猪';
            }else if ($value['product_type']==2) {
                $orders[$key]['product_type'] = '共筹';
                foreach ($value['detail'] as $k => $v) {
                    $orders[$key]['info'][] = Setmeal::find()->where(['id'=>$v['setmeal_id']])->one()->index;
                }
            }
            $orders[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;

        }

        $data['data'] = $orders;
        print_r(json_encode($data));
	}

	public function actionRec(){
		$user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('rec');
	}

	public function actionRecjson($page=1,$size=10){
		$page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);
        $user_id = Yii::$app->session['font_user']['user_id'];
        
        $data['total'] = Order::find()
                 ->joinWith(['product'=>function($query){
                    $query->where('t_product.status>2');
                 }])
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::RECEIVED])
                 ->count();
        $orders = Order::find()
                 ->select(['t_order.id','product_id','amount','product_type','t_order.status'])
                 ->joinWith(['product'=>function($query){
                    $query->select(['t_product.id','img_url','species_id','t_product.status']);
                    $query->where('t_product.status>2');
                 }])
                 ->with(['detail'=>function($query){
                    $query->select(['id','order_id','setmeal_id']);
                 }])
                 ->limit($size)
                 ->offset($offset)
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::RECEIVED])
                 ->orderBy('t_order.id desc')
                 ->asArray()
                 ->all();

        foreach ($orders as $key => $value) {
            if ($value['product_type']==1) {
                $orders[$key]['product_type'] = '认养';
                $orders[$key]['info'] = '整猪';
            }else if ($value['product_type']==2) {
                $orders[$key]['product_type'] = '共筹';
                foreach ($value['detail'] as $k => $v) {
                    $orders[$key]['info'][] = Setmeal::find()->where(['id'=>$v['setmeal_id']])->one()->index;
                }
            }
            $orders[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;

        }

        $data['data'] = $orders;
        print_r(json_encode($data));
	}

    public function actionSuccess(){
        $user_id = Yii::$app->session['font_user']['user_id'];

        $this->layout = 'layout1';
        return $this->render('success');
    }

    public function actionSuccessjson($page=1,$size=10){
        $page = (int)$page;
        $size = (int)$size;
        $offset = $size*($page-1);
        $user_id = Yii::$app->session['font_user']['user_id'];
        
        $data['total'] = Order::find()
                 ->joinWith(['product'=>function($query){
                    $query->where('t_product.status>2');
                 }])
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::COMMENT])
                 ->count();
        $orders = Order::find()
                 ->select(['t_order.id','product_id','amount','product_type','t_order.status'])
                 ->joinWith(['product'=>function($query){
                    $query->select(['t_product.id','img_url','species_id','t_product.status']);
                    $query->where('t_product.status>2');
                 }])
                 ->with(['detail'=>function($query){
                    $query->select(['id','order_id','setmeal_id']);
                 }])
                 ->limit($size)
                 ->offset($offset)
                 ->where(['user_id'=>$user_id,'t_order.status'=>Order::COMMENT])
                 ->orderBy('t_order.id desc')
                 ->asArray()
                 ->all();

        foreach ($orders as $key => $value) {
            if ($value['product_type']==1) {
                $orders[$key]['product_type'] = '认养';
                $orders[$key]['info'] = '整猪';
            }else if ($value['product_type']==2) {
                $orders[$key]['product_type'] = '共筹';
                foreach ($value['detail'] as $k => $v) {
                    $orders[$key]['info'][] = Setmeal::find()->where(['id'=>$v['setmeal_id']])->one()->index;
                }
            }
            $orders[$key]['species'] = Species::find()->where(['id'=>$value['product']['species_id']])->one()->name;

        }

        $data['data'] = $orders;
        print_r(json_encode($data));
    }

    public function actionDetail($order_id){
        // 
        $order_id = (int)$order_id;
        $order = Order::find()
                ->select(['id','product_type','amount','product_id','address_id'])
                ->with(['product'=>function($query){
                    $query->select(['id','species_id','img_url','name','start_time','end_time','forage_id']);
                },'address'=>function($query){

                },'detail'=>function($query){

                }])
                ->where(['id'=>$order_id])
                ->asArray()
                ->one();
        $Area = Area::find()->where(['areaID'=>$order['address']['area_id']])->one();
        $City = City::find()->where(['cityID'=>$Area->fatherID])->one();
        $Province = Province::find()->where(['provinceID'=>$City->fatherID])->one();
        $order['address']['area'] = $Area->area;
        $order['address']['city'] = $City->city;
        $order['address']['province'] = $Province->province;
        $order['product']['species'] = Species::findOne($order['product']['species_id'])->name;

        if ($order['product_type']==1) {
            $order['type'] = '认养';
            $order['result'] = '整猪';
            $order['info'] = ForageType::findOne($order['product']['forage_id'])->name;
        }else if ($order['product_type']==2) {
            $order['type'] = '共筹';
            $order['result'] = '';
            $order['info'] = '';
            foreach ($order['detail'] as $key => $value) {
                $Setmeal = Setmeal::findOne($value['setmeal_id']);
                $order['result'].='套餐'.$Setmeal->index.';';
                $order['info'].=$Setmeal->name;
            }
        }

        $output = FarmResult::find()->where(['product_id'=>$order['product']['id']])->asArray()->one();
        $object = json_decode($output['content']);
        $content = [];
        if ($object) {
            foreach ($object as $key => $value) {
                foreach ($value as $k => $v) {
                    $content[$k][$key] = $v;
                    $content[$k]['all'] = $object->number[$k]*$object->weight[$k];
                }
            }
        }
        
        $content_size = count($content);
        $chunk_1 = ceil($content_size/2);
        $chunk_2 = floor($content_size/2);
        
        $content_1 = array_slice($content, 0,$chunk_1);
        $content_2 = array_slice($content, $chunk_1,$chunk_2);

        $this->layout = 'layout1';
        return $this->render('detail',['order'=>$order,'output1'=>$content_1,'output2'=>$content_2]);
    }

    public function actionLog($order_id){
        $order_id = (int)$order_id;
        $order = Order::find()
                ->select(['id','product_type','amount','product_id','address_id','express_num'])
                ->with(['detail'=>function($query){

                },'product'=>function($query){
                    $query->select(['forage_id']);
                }])
                ->where(['id'=>$order_id])
                ->asArray()
                ->one();

        if ($order['product_type']==1) {
            $order['type'] = '认养';
            $order['result'] = '整猪';
            $order['info'] = ForageType::findOne($order['product']['forage_id'])->name;
        }else if ($order['product_type']==2) {
            $order['type'] = '共筹';
            $order['result'] = '';
            $order['info'] = '';
            foreach ($order['detail'] as $key => $value) {
                $Setmeal = Setmeal::findOne($value['setmeal_id']);
                $order['result'].='套餐'.$Setmeal->index.';';
                $order['info'].=$Setmeal->name;
            }
        }
        $express = Express::search($order['express_num']);
        $express = json_decode($express);
        // print_r($express);die();
        $this->layout = 'layout1';
        return $this->render('log',['order'=>$order,'express'=>$express]);
    }


    public function actionTocomment($order_id){
        $order_id = (int)$order_id;
        $order = Order::find()
                ->select(['id','product_type','amount','product_id','address_id','express_num'])
                ->with(['detail'=>function($query){

                },'product'=>function($query){
                    $query->select(['forage_id']);
                }])
                ->where(['id'=>$order_id])
                ->asArray()
                ->one();

        if ($order['product_type']==1) {
            $order['type'] = '认养';
            $order['result'] = '整猪';
            $order['info'] = ForageType::findOne($order['product']['forage_id'])->name;
        }else if ($order['product_type']==2) {
            $order['type'] = '共筹';
            $order['result'] = '';
            $order['info'] = '';
            foreach ($order['detail'] as $key => $value) {
                $Setmeal = Setmeal::findOne($value['setmeal_id']);
                $order['result'].='套餐'.$Setmeal->index.';';
                $order['info'].=$Setmeal->name;
            }
        }

        $this->layout = 'layout1';
        return $this->render('comment',['order'=>$order]);
    }

    public function actionConfirm($order_id){
        $order_id = (int)$order_id;
        $Order = Order::findOne($order_id);
        $Order->status = Order::RECEIVED;
        $Product = Product::findOne($Order->product_id);
        $Product->status = 6;
        $Order->save();
        $Product->save();
        return $this->redirect(['send']);
    }

}