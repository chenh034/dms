<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\ProductComment;
use app\models\FarmUpdate;
use app\models\FarmUser;
use app\models\ForageType;
use app\models\Forage;
use app\models\Area;
use app\models\City;
use app\models\Province;
use app\models\FarmMessage;
use yii\web\Response;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_checkController extends Controller
{

  public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
	
	public function actionProductjson($page=1,$size=10,$is_ok=0){
       Yii::$app->response->format = Response::FORMAT_JSON;
	     $is_ok = (int)$is_ok;
       $page = (int)$page;
       $size = (int)$size;
       $offset = $size*($page-1);
       
       $data['total'] = Product::find()->where(['is_ok'=>$is_ok])->count();
       $data['data'] = Product::find()->select(['id','farm_id','name','type','species_id','foundation_weight','pre_weight','foundation_price','img_url'])
                ->with(['species'=>function($query){
                  $query->select('id,name');
                },'farm'=>function($query){
                  $query->select(['id','username']);
                }])
                ->where(['is_ok'=>$is_ok])
                ->limit($size)
                ->offset($offset)
                ->orderBy('id desc')
                ->asArray()
                ->all();

        return $data;
	}


	public function actionProductdetail($id){
        Yii::$app->response->format = Response::FORMAT_JSON;
    		$id = (int)$id;
    		$data = Product::find()
                ->with(['species'=>function($query){
                  $query->select('id,name');
                },'farm'=>function($query){
                  $query->select(['id','username']);
                },'setmeal'])
                ->where(['id'=>$id])
                ->asArray()
                ->one();
        if ($data['type']==1) {
          // $forage_offer = Forage::find()->where(['product_id'=>$data['id']])->asArray()->all();
          // foreach ($forage_offer as $key => $value) {
          //   $forage[$key] = ForageType::find()->where(['id'=>$value['type_id']])->one()->name;
          // }
          $forage[] = ForageType::find()->where(['id'=>$data['forage_id']])->one()->name;
        }else if ($data['type']==2) {
          $forage[] = ForageType::find()->where(['id'=>$data['forage_id']])->one()->name;
        }

        $data['forage'] = $forage;
    		return $data;
	}
	public function actionCheckproduct($id,$is_ok){
        Yii::$app->response->format = Response::FORMAT_JSON;
    		$id = (int)$id;
    		$is_ok = (int)$is_ok;
        if (Yii::$app->request->isPost) {
          $post = Yii::$app->request->post();
          $reason = $post['reason'];
          $Product = Product::findOne($id);
          $Product->is_ok = $is_ok;
          $Product->fail_reason = $reason;
          if ($Product->save()) {
            return ['code'=>0];
          }else{
            return ['code'=>1,'data'=>$Product->getErrors()];
          }
        }else{
            $Product = Product::findOne($id);
            $Product->is_ok = $is_ok;
            if ($Product->save()) {
              return ['code'=>0];
            }else{
              return ['code'=>1,'data'=>$Product->getErrors()];
            }
        }
	}


	public function actionCommentjson($page=1,$size=10,$is_index_show=0){
       Yii::$app->response->format = Response::FORMAT_JSON;
  	   $is_index_show = (int)$is_index_show;
       $page = (int)$page;
       $size = (int)$size;
       $offset = $size*($page-1);
       
       $data['total'] = ProductComment::find()->where(['is_index_show'=>$is_index_show])->count();
       $data['data'] = ProductComment::find()
               ->select(['id','user_id','content','createtime'])
               ->with(['pics','user'=>function($query){
                 $query->select(['id','username']);
               }])
               ->limit($size)
               ->offset($offset)
               ->orderBy('id desc')
               ->where(['is_index_show'=>$is_index_show])
               ->asArray()
               ->all();

        return $data;
	}

	public function actionCommentDetail($id){
  		Yii::$app->response->format = Response::FORMAT_JSON;
      $id = (int)$id;
  		$data = ProductComment::find()->one();

  		return $data->attributes;
	}
	public function actionCheckcomment($id,$is_index_show){
    		Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;
    		$is_index_show = (int)$is_index_show;

        $ProductComment = ProductComment::findOne($id);
        $ProductComment->is_index_show = $is_index_show;
        if ($ProductComment->save()) {
        	return ['code'=>0];
        }else{
        	return ['code'=>1,'data'=>$ProductComment->getErrors()];
        }
	}
  
  public function actionUserjson($page=1,$size=10){
      Yii::$app->response->format = Response::FORMAT_JSON;
      $page = (int)$page;
      $size = (int)$size;
      $offset = $size*($page-1);
      
      $data['total'] = FarmUpdate::find()->where(['status'=>0])->count();
      $data['data'] = FarmUpdate::find()
                    ->with(['farm'=>function($query){
                       $query->select(['id','username']);
                    }])
                    ->limit($size)
                    ->offset($offset)
                    ->where(['status'=>0])->asArray()->all();
      foreach ($data['data'] as $key => $value) {
          $data['data'][$key]['address'] = null;
          if (!is_null($value['area_id'])) {
            $area = Area::find()->where(['areaID'=>$value['area_id']])->one();
            $city = City::find()->where(['cityID'=>$area->fatherID])->one();
            $province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
            $data['data'][$key]['address'] = $province->province.$city->city.$area->area;
          }
          $data['data'][$key]['username'] = $value['farm']['username'];
      }
      
      
      return $data;
  }

  public function actionCheckuser($id,$status){
      Yii::$app->response->format = Response::FORMAT_JSON;
      $id = (int)$id;
      $status = (int)$status;

      $FarmUpdate = FarmUpdate::find()->where(['id'=>$id])->one();
      $FarmUpdateArray = FarmUpdate::find()->where(['id'=>$id])->asArray()->one();
      $FarmUpdate->status = $status;
      $FarmUpdate->save();
      if ($status==1) {
        $FarmUser = FarmUser::findOne($FarmUpdate->farm_id);
        foreach ($FarmUpdateArray as $key => $value) {
          if ($value!=null && $key!='farm_id' && $key!='status' && $key!='id') {
             $FarmUser->$key = $value;
          }
          if ($key=='area_id'&&$value!=null) {
            $area = Area::find()->where(['areaID'=>$value])->one();
            $city = City::find()->where(['cityID'=>$area->fatherID])->one();
            $province = Province::find()->where(['provinceID'=>$city->fatherID])->one();
            $address['area'] = $area->area;
            $address['city'] = $city->city;
            $address['province'] = $province->province;
            $FarmUser->pca = $address['province'].$address['city'].$address['area'];
          }
        }
        if ($FarmUser->save()) {
          return ['code'=>0];
        }else{
          return ['code'=>1,'data'=>$FarmUser->getErrors()];
        }
      }else{
        $post = Yii::$app->request->post();
        $FarmMessage = new FarmMessage;
        $FarmMessage->check = $post['reason'];
        if ($FarmMessage->save()) {
          return ['code'=>0];
        }
      }
  }


}