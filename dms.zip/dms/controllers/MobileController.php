<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\FontUser;
use app\models\Order;
use app\models\Product;
use app\models\ProductParam;
use app\models\Forage;
use app\models\ForageType;
use app\models\ForageOffer;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class MobileController extends Controller
{
	
	public function actionDuring($user_id){
		Yii::$app->response->format = Response::FORMAT_JSON;
        if (!$user_id) {
            return ['code'=>1];
        }
        $user_id = FontUser::encrypt($user_id,'D','a');        
        $orders = Order::find()->select(['id','product_id'])->where(['user_id'=>$user_id])
           ->andWhere(['in','status',[Order::PAYSUCCESS,Order::SENDED]])->asArray()->all();
        $ids = [];
        foreach ($orders as $key => $value) {
            $ids[] = $value['product_id'];
        }
        $ids = array_flip($ids);
        $ids = array_flip($ids);

        $Product = Product::find()
                    ->select(['id','img_url','species_id','name','type','start_time','end_time','pre_weight','now_weight','update_time'])
                    ->with('species')
                    ->where(['in','id',$ids])
                    ->andWhere('status=3')
                    ->orderBy('id desc')
                    ->asArray()
                    ->all();
        foreach ($Product as $key => $value) {
            if ($value['type']==1) {
                $Product[$key]['type'] = '认养';
            }else if ($value['type']==2) {
                $Product[$key]['type'] = '共筹';
            }
            $Product[$key]['species'] = $value['species']['name'];
            $Product[$key]['update_time'] = date('Y-m-d',$value['update_time']);
            $Product[$key]['nickname'] = Order::find()->where(['product_id'=>$value['id'],'user_id'=>$user_id])->one()->nickname;
        }
        
        $data = ['code'=>0,'data'=>$Product];
        return $data;
	}

	public function actionDetail($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = (int)$id;
        $Product = Product::find()
                   ->select(['id','species_id','name','type','now_weight','dorm','advice','start_time','end_time','update_time'])
                   ->with(['species','param'=>function($query){

                   },'dorm'])
                   ->where(['id'=>$id])
                   ->asArray()->one();
        $end = end($Product['param']);
        $update_time = $end['update_time'];
        $Product['food_intake'] = $end['food_intake'];
        $Product['activity'] = $end['activity'];
        $Product['sleep'] = $end['sleep'];
        $Product['now_weight'] = $end['now_weight'];
        $Product['fat_ratio'] = $end['fat_ratio'];
        $Product['species'] = $Product['species']['name'];
        $Product['has_feed'] = (strtotime(date('Y-m-d',time()))-strtotime($Product['start_time']))/(3600*24);
        $Product['update_time'] = date('Y-m-d',$update_time);

        return $Product;
	}

	public function actionGetparam($id){
		Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;

        $ProductParam = ProductParam::find()->where(['product_id'=>$id])->asArray()->all();
        $end = end($ProductParam);
        $update_time = $end['update_time'];

        $paramSize = count($ProductParam);
        $food_intake = $activity = $sleep = $now_weight = $fat_ratio = [];
        $x = [];
        if ($paramSize>5) {
            $start = $ProductParam[0];
            $end = end($ProductParam);
            unset($ProductParam[0]);
            $ProductParam = array_pop($ProductParam);

            $rand_keys = array_rand($ProductParam,3);
            $x[] = date('Y-m-d',$start['update_time']);
            $food_intake[] = $start['food_intake'];
            $activity[] = $start['activity'];
            $sleep[] = $start['sleep'];
            $now_weight[] = $start['now_weight'];
            $fat_ratio[] = $start['fat_ratio'];
            foreach ($rand_keys as $key => $value) {
                $x[] = date('Y-m-d',$ProductParam[$value]['update_time']);
                $food_intake[] = $ProductParam[$value]['food_intake'];
                $activity[] = $ProductParam[$value]['activity'];
                $sleep[] = $ProductParam[$value]['sleep'];
                $now_weight[] = $ProductParam[$value]['now_weight'];
                $fat_ratio[] = $ProductParam[$value]['fat_ratio'];
            }
            $x[] = date('Y-m-d',$end['update_time']);
            $food_intake[] = $end['food_intake'];
            $activity[] = $end['activity'];
            $sleep[] = $end['sleep'];
            $now_weight[] = $end['now_weight'];
            $fat_ratio[] = $end['fat_ratio'];
        }else{
            foreach ($ProductParam as $key => $value) {
                $x[] = date('Y-m-d',$value['update_time']);
                $food_intake[] = $value['food_intake'];
                $activity[] = $value['activity'];
                $sleep[] = $value['sleep'];
                $now_weight[] = $value['now_weight'];
                $fat_ratio[] = $value['fat_ratio'];
            }
        }
    
        $data['x'] = $x;
        $data['food_intake'] = $food_intake;
        $data['activity'] = $activity;
        $data['sleep'] = $sleep;
        $data['now_weight'] = $food_intake;
        $data['fat_ratio'] = $food_intake;

        return $data;
	}
}