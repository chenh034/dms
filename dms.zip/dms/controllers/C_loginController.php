<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\FontUser;
use yii\web\Response;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
*
*/
class C_loginController extends Controller
{
	public function actionTologin(){
		return $this->renderPartial('login');
	}
	public function actionLogin(){

		$post = Yii::$app->request->post();

		$FontUser = new FontUser;
		$login_status = $FontUser->login($post);


		if ($login_status['code']==0) {
			$user_id = $login_status['data']['user_id'];
			Yii::$app->session['font_user'] = ['user_id'=>$user_id,'head_url'=>$login_status['data']['head_url'],'is_login'=>1];
			$cookies = Yii::$app->response->cookies;
			$cookies->add(new \yii\web\Cookie([
				   'name'=>'head_url',
                   'value'=>$login_status['data']['head_url']
				]));
			if (isset(Yii::$app->session['returnUrl'])) {
				$returnUrl = Yii::$app->session['returnUrl'];
			}else{
				$returnUrl = Yii::$app->request->hostInfo.'/c_index/index';
			}
	        return $this->redirect($returnUrl);
		}else{
            $errs = $this->getoneMessage($login_status['data']);
            $err_one = $errs[0];
            // Yii::$app->session->setFlash("error",$err_one.',请重新登陆');
            return $this->renderPartial('login',['login_fail'=>$err_one.',请重新登陆']);
		}

	}

	public function actionWlogin(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$post = Yii::$app->request->post();

		$FontUser = new FontUser;
		$login_status = $FontUser->login($post);

        if ($login_status['code']==0) {
        	$login_status['data']['user_id'] = FontUser::encrypt($login_status['data']['user_id'],'E','a');
        }
		return $login_status;
	}

	public function actionLogout(){
		if (isset(Yii::$app->session['font_user'])) {
			Yii::$app->session->remove('font_user');
			return $this->redirect(['c_index/index']);
		}else{
			return $this->redirect(['c_index/index']);
		}
	}

	public function actionReg(){
		if (Yii::$app->request->isPost) {
			if (Yii::$app->request->isPost) {
				$post = Yii::$app->request->post();
				$cache = Yii::$app->cache;
				if ($post['code']==$cache->get($post['phone'])) {
					$FontUser = new FontUser;
					$FontUser->username = $post['phone'];
					$FontUser->password = md5($post['password']);
					if ($FontUser->save()) {
						if (isset(Yii::$app->session['font_user'])) {
							Yii::$app->session->remove('font_user');
						}
						Yii::$app->session['font_user'] = ['user_id'=>$FontUser->id,'head_url'=>Yii::$app->request->hostInfo.'/assets/c/images/common/person.png','is_login'=>1];
						$cookies = Yii::$app->response->cookies;
						$cookies->add(new \yii\web\Cookie([
							   'name'=>'head_url',
			                   'value'=>Yii::$app->request->hostInfo.'/assets/c/images/common/person.png'
							]));
						print_r(json_encode(['code'=>0]));
					}else{
						print_r(json_encode(['code'=>2]));
					}
				}else{
					print_r(json_encode(['code'=>1]));
				}
			}
		}
	}

	public function actionCheck($phone){
        $phone = trim($phone);
        $FontUser = FontUser::find()->where(['username'=>$phone])->one();
        if (is_null($FontUser)) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1]));
        }
	}

	public function actionSuccess(){
		return $this->renderPartial('success');
	}

	public function actionSendmessage(){
		if (Yii::$app->request->isPost) {
			$cache = Yii::$app->cache;
			$post = Yii::$app->request->post();
			$code = trim($post['code']);
			$phone = trim($post['phone']);

			$cache->set($phone,$code,180);
			$url = FontUser::$url.FontUser::$sid.'/Messages/templateSMS?sig='.strtoupper(md5(FontUser::$sid.FontUser::$token.date('YmdHis')));
			$data = ['templateSMS'=>
			            [
			             'appId'=>FontUser::$appId,
	                     'param'=>$code,
	                     'templateId'=>FontUser::$templateId1,
	                     'to'=>$phone
	                    ]
			        ];
			$header1 = 'Authorization:'.base64_encode(FontUser::$sid.':'.date('YmdHis'));
			$header = array('Content-type:application/json;charset=utf-8',$header1,'Accept:application/json');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_URL, $url);
			if(strtolower(substr($url,0,5)) == 'https'){
				//$location = 'D:/Program Files/wamp/wamp/www/example/call_center/';	//证书绝对地址
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);	//信任任何证书;
				//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);	//只信任颁发的证书;
				//curl_setopt($ch, CURLOPT_CAINFO, $location.'call_center.cer');	//颁发的受信任的证书
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);	//检查证书中是否设置域名,0不验证;
			}
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			$output = curl_exec($ch);
			$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($status != 200){
				$output = (object)array(
					'code' => $status,
					'errno' => curl_errno($ch),
					'error' => curl_error($ch)
				);
				$output = json_encode($output);
			}else{
				$output = array(
                     'code'=>0
				);
				$output = json_encode($output);
			}
			curl_close($ch);
			print_r($output);
		}
	}

	public function getoneMessage($data){
		static $arr = [];
        foreach ($data as $key => $value) {
        	if (is_array($value)) {
        		$this->getoneMessage($value);
        	}else{
        		$arr[] = $value;
        	}
        }
        return $arr;
	}

}
