<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\OrderAdopt;
use app\models\Order;
use app\models\Forage;
use app\models\ForageOffer;
use app\models\Species;
use app\models\Product;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class C_adoptController extends Controller
{
	public function actionSpecieslist(){
        $species = Species::find()->where(['parent_id'=>0,'is_use'=>1])->asArray()->all();
        $this->layout = 'layout1';
        return $this->render('specieslist',['species'=>$species]);
	}
	public function actionSpeciesjson($page=1,$size=9,$species_id){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$species_id = (int)$species_id;

		$data['total'] = Species::find()->where(['parent_id'=>$species_id,'is_use'=>1])->count();
		$data['data'] = Species::find()
                            ->offset($offset)
                            ->limit($size)
                            ->where(['parent_id'=>$species_id,'is_use'=>1])
                            ->asArray()
                            ->all();

    foreach ($data['data'] as $key => $value) {
      if (mb_strlen(strip_tags(trim($value['introduce'])))>18) {
        $data['data'][$key]['introduce'] = mb_substr(strip_tags(trim($value['introduce'])), 0,18,'utf-8').'……'.'<a href=javascript:; title='.$value['id'].'>查看全部</a>';
      }
      if (mb_strlen(strip_tags(trim($value['special'])))>35) {
        $data['data'][$key]['special'] = mb_substr(strip_tags(trim($value['special'])), 0,35,'utf-8').'……'.'<a href=javascript:; rel='.$value['id'].'>查看全部</a>';
      }
    }

		print_r(json_encode($data));

	}

	public function actionList($species_id){
		$species_id = (int)$species_id;
		$species = Species::findOne($species_id);

		$this->layout = 'layout1';
		return $this->render('list',['species'=>$species]);
	}

	public function actionJson($page=1,$size=12,$species_id){
		// Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
		$species_id = (int)$species_id;
        
        $data['total'] = Product::find()->where(['species_id'=>$species_id,'type'=>1,'status'=>1,'is_ok'=>1])->count();
		$Product = Product::find()
		          ->select(['id','farm_id','species_id','birthday','forage_id','foundation_weight','foundation_price','img_url'])
                  ->with(['species'=>function($query){
                  	$query->select('id,name');
                  },'farm'=>function($query){
  		        	$query->select('id,account_place,pca,farm_name');
  		          },'forage'])
                  ->limit($size)
                  ->offset($offset)
                  ->where(['species_id'=>$species_id,'type'=>1,'status'=>1,'is_ok'=>1])
                  ->orderBy('id desc')
                  ->asArray()
                  ->all();
	    foreach ($Product as $key => $value) {
            $Product[$key]['species'] = $value['species']['name'];
            $Product[$key]['farm_place'] = $value['farm']['pca'];
            $Product[$key]['farm_name'] = $value['farm']['farm_name'];
            $Product[$key]['forage'] = $value['forage']['name'];
            unset($Product[$key]['farm']);
        }

        $data['data'] = $Product;

        print_r(json_encode($data));


	}

	public function actionDetail($id){
    		Yii::$app->session['returnUrl'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        if (isset(Yii::$app->session['font_user'])) {
            $user_id = Yii::$app->session['font_user']['user_id'];
        }else{
            return $this->redirect(Yii::$app->request->hostInfo.'/c_login/tologin');
        }
    		$id = (int)$id;
    		$Product = Product::find()
    		          ->select(['id','farm_id','species_id','forage_id','name','birthday','foundation_weight','pre_weight','feed_time','feed_price','foundation_price','img_url','introduce','output','status'])
                  ->with(['species'=>function($query){
                  	$query->select('id,name');
                  },'farm'=>function($query){
  		        	    $query->select('id,account_place');
  		            },'forage'])
                  ->where(['id'=>$id])
                  ->orderBy('id desc')
                  ->asArray()
                  ->one();
        if ($Product['status']!=1) {
          // die('商品已被购买');
        }
    		$Product['species'] = $Product['species']['name'];
        $Product['farm_place'] = $Product['farm']['account_place'];
        $Product['end_time'] = date('Y-m-d',strtotime($Product['birthday'])+3600*24*$Product['feed_time']);
        unset($Product['farm']);

        // $Forage = Forage::find()
        //          ->select(['id','type_id'])
        //          ->with(['forage'=>function($query){
        //          	$query->select(['id','name']);
        //          }])
        //          ->where(['product_id'=>$id])
        //          ->asArray()
        //          ->all();
        // foreach ($Forage as $key => $value) {
        // 	$Forage[$key]['name'] = $value['forage']['name'];
        // 	$Forage[$key]['price'] = ForageOffer::find()->where(['forage_id'=>$value['type_id'],'farm_id'=>$Product['farm_id']])->one()->price;
        // 	unset($Forage[$key]['forage']);
        // }

        $data['product'] = $Product;
        // $data['forage'] = $Forage;

        $this->layout = 'layout1';
        return $this->render('detail',['data'=>$data]);
	}
}