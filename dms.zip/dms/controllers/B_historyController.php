<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\ForageType;
use app\models\Species;

/**
* 
*/
class B_historyController extends Controller
{

	public function actionIndex(){
		$this->layout = 'layout2';
		return $this->render('index');
	}
	
	public function actionJson($page=1,$size=10){
		$page = (int)$page;
		$size = (int)$size;
		$offset = $size*($page-1);
        
        $user_id = Yii::$app->session['farm_user']['user_id'];

		$data['total'] = Product::find()->where('status=6 or status=7')->andWhere("farm_id=$user_id")->count();

		$data['data'] = Product::find()
		                ->select(['id','farm_id','species_id','img_url','name','start_time','end_time','kill_time','output','all_price'])
		                ->with(['species','farm'=>function($query){
		                	$query->select(['id','username']);
		                }])
		                ->limit($size)
		                ->offset($offset)
		                ->where('status=6 or status=7')
		                ->andWhere("farm_id=$user_id")
		                ->orderBy('id desc')
		                ->asArray()
		                ->all();
        foreach ($data['data'] as $key => $value) {
        	$data['data'][$key]['species'] = $value['species']['name'];
        	$data['data'][$key]['farm'] = $value['farm']['username'];
        }
		
		print_r(json_encode($data));
	}
}