<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Question;
use app\models\QuestionType;
use yii\web\Response;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class A_questionController extends Controller
{  	

	public function behaviors(){
         return [
            'admin' => [
                'class' => 'app\component\AdminFilter'//调用过滤器
            ]
        ];
    }
    
	public function actionAddtype(){
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Type = new QuestionType;
			$Type->name = $post['name'];
			if ($Type->save()) {
				echo '{"code":0}';
			}else{
				echo '{"code":1}';
			}
		}
	}

	public function actionEdittype($id){
		$id = (int)$id;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Type = QuestionType::findOne($id);
			$Type->name = $post['name'];
			if ($Type->save()) {
				echo '{"code":0}';
			}else{
				echo '{"code":1}';
			}
		}
	}

	public function actionDeltype($id){
		$id = (int)$id;
		$Type = QuestionType::findOne($id);
		if (!is_null($Type)) {
			if ($Type->delete()) {
				echo '{"code":0}';
			}else{
				echo '{"code":1}';
			}
		}else{
			echo '{"code":0}';
		}

	}

	public function actionTypejson(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$Type = QuestionType::find()->asArray()->all();

		return $Type;
	}

	public function actionAdd(){
		Yii::$app->response->format = Response::FORMAT_JSON;
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Question = new Question;
			$add_status = $Question->addQuestion($post);

			return $add_status;
		}else{
			return ['code'=>1,'data'=>'请求方式错误'];
		}
	}

	public function actionEdit($id){
		$id = (int)$id;
		$Question = Question::findOne($id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();

			$edit_status = $Question->editQuestion($post);

			if ($edit_status['code']==0) {
				echo '{"code":0}';
			}else{
				echo '{"code":1}';
			}
			return;
		}
		if (!is_null($Question)) {
			print_r(json_encode($Question->attributes));
		}else{
			print_r(json_encode([]));
		}

	}

	public function actionDel($id){
		$id = (int)$id;
		$Question = Question::findOne($id);
		if (!is_null($Question)) {
			if ($Question->delete()) {
				echo '{"code":0}';
			}else{
				echo '{"code":1}';
			}
		}else{
			echo '{"code":0}';
		}
	}

	public function actionBatchdel(){
        Yii::$app->response->format = Response::FORMAT_JSON;
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();
            $tr = Yii::$app->db->beginTransaction();
            try{
                foreach ($post['ids'] as $key => $value) {
                    $Question = Question::findOne($value);
                    if (!$Question->delete()) {
                        throw new Exception("删除失败");    
                    }
                }
                $tr->commit();
            }catch (\Exception $e){
                $tr->rollBack();
                $err = [
                    'code' => $e->getCode(),
                    'msg'  => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'   => $e->getLine()
                ];
                return ['code'=>1,'data'=>$err['msg']];
            }
            return ['code'=>0];
        }
    }


	public function actionJson($page=1,$size=5,$type_id=null,$start_time=null,$end_time=null){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$page = (int)$page;
		$size = (int)$size;
        $offset = $size*($page-1);

        if ($start_time!=null) {
            $start_time = strtotime($start_time);
        }else{
        	$start_time = 0;
        }

        if ($end_time!=null) {
        	$end_time = strtotime($end_time)+3600*24;
        }else{
        	$end_time = time();
        }

        $Type = QuestionType::find()->asArray()->all();
        
        if (!is_null($type_id)) {
        	 $data['total'] = Question::find()->where(['type_id'=>$type_id])->count();
        	 $data['data'] = Question::find()
                ->select(['id','title','answer','update_time','important','type_id'])
                ->orderBy('id desc')
                ->limit($size)
                ->offset($offset)
                ->where(['type_id'=>$type_id])
                ->andWhere("update_time between $start_time and $end_time")
                ->asArray()
                ->all();
        }else{
        	 $data['total'] = Question::find()->count();
        	 $data['data'] = Question::find()
                ->select(['id','title','answer','update_time','important','type_id'])
                ->where("update_time between $start_time and $end_time")
                ->orderBy('id desc')
                ->limit($size)
                ->offset($offset)
                ->asArray()
                ->all();
        }

        foreach ($data['data'] as $key => $value) {
        	foreach ($Type as $k => $v) {
        		if ($value['type_id']==$v['id']) {
        			$data['data'][$key][$v['name']] = 1;
        		}else{
        			$data['data'][$key][$v['name']] = 0;
        		}
        	}
        }

       
        return $data;
	}

	public function actionChangetype($id,$type){
		Yii::$app->response->format = Response::FORMAT_JSON;
		$type_id = QuestionType::find()->where(['name'=>$type])->one()->id;
		$Question = Question::findOne($id);
		$Question->type_id = $type_id;
		if ($Question->save()) {
			return ['code'=>0];
		}else{
			return ['code'=>1,'data'=>$Question->getErrors()];
		}
	}

	public function actionImportant($id,$important){
		Yii::$app->response->format = Response::FORMAT_JSON;
        $id = (int)$id;
        $important = (int)$important;

        $Question = Question::findOne($id);
        $Question->important = $important;
        if ($Question->save()) {
        	print_r(json_encode(['code'=>0]));
        }else{
        	print_r(json_encode(['code'=>1,'data'=>$Question->getErrors()]));
        }
	}
}