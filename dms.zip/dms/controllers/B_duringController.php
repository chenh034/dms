<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\FarmMessage;
use app\models\FarmResult;
use app\models\Species;
use app\models\Dorm;
use app\models\ProductParam;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');

/**
* 
*/
class B_duringController extends Controller
{
	public function behaviors(){
	     return [
	        'farm' => [
	            'class' => 'app\component\FarmFilter'//调用过滤器
	        ]
	    ];
	}

	
	public function actionList(){
        $this->layout = 'layout2';
        return $this->render('list');
	}

	public function actionJson($page=1,$size=10){
		$farm_id = Yii::$app->session['farm_user']['user_id'];
		$size = (int)$size;
		$page = (int)$page;
		$offset = $size*($page-1);
        
        $total = Product::find()->where(['is_ok'=>1,'status'=>3])->count();
		$data = Product::find()
		        ->select(['id','species_id','dorm','name','update_time'])
		        ->with(['species'=>function($query){
	                	$query->select('id,name');
	                },'message'=>function($query){
                        $query->where(['confirm'=>0]);
	                },'dorm']
                )
		        ->orderBy('id desc')
		        ->offset($offset)
		        ->limit($size)
		        ->where(['farm_id'=>$farm_id,'is_ok'=>1,'status'=>3])
		        ->asArray()
		        ->all();


        foreach ($data as $key => $value) {
        	$data[$key]['update_time'] = date('Y-m-d',$value['update_time']);
        	$message = [];
        	foreach ($value['message'] as $k => $v) {
        		if ($v['forage']!=null) {
        			$temp = [];
        			$temp['id'] = $v['mid'];
        			$temp['content'] = '饲料改动';
        			array_push($message, $temp);
        		}
        		if ($v['feed_time']!=null) {
        			$temp = [];
        			$temp['id'] = $v['mid'];
        			$temp['content'] = '宰杀时间改动';
        			array_push($message, $temp);
        		}
        		if ($v['kill_time']!=null) {
        			$temp = [];
        			$temp['id'] = $v['mid'];
        			$temp['content'] = '宰杀通知';
        			array_push($message, $temp);
        		}
        	}
        	$data[$key]['message'] = $message;
        	if (!is_null($value['dorm'])) {
        		$data[$key]['dorm'] = $value['dorm']['name'];
        	}else{
        		$data[$key]['dorm'] = '分配牧舍';
        	}
        }
        $Info['total'] = $total;
        $Info['data'] = $data;
        print_r(json_encode($Info));
	}

	public function actionToupdate($id){
		$id = (int)$id;
		$Product = Product::find()
		           ->with(['param'=>function($query){
		           	  $query->orderBy('id desc');
		           }])
		           ->where(['id'=>$id])
		           ->asArray()
		           ->one();
		$Product['food_intake'] = $Product['param'][0]['food_intake'];
		$Product['activity'] = $Product['param'][0]['activity'];
		$Product['sleep'] = $Product['param'][0]['sleep'];
		$Product['fat_ratio'] = $Product['param'][0]['fat_ratio'];
		$Product['now_weight'] = $Product['param'][0]['now_weight'];
		$Product['update_time'] = $Product['param'][0]['update_time'];

		unset($Product['param']);

		$this->layout = 'layout2';
		return $this->render('update',['product'=>$Product]);
	}

	public function actionUpdate($id){
		$id = (int)$id;
		$Product = Product::findOne($id);
		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$update_time = str_replace('/', '-', $post['update_time']);
			$Product->advice = $post['advice'];
			$Product->save();
			$update_status = $Product->updateInfo($post);

			if ($update_status['code']==0) {
				Yii::$app->session->setFlash('status','修改成功');
				return $this->redirect(['toupdate','id'=>$id]);
			}else{
				Yii::$app->session->setFlash('status','修改失败');
				return $this->redirect(['toupdate','id'=>$id]);
			}

		}
	}

	public function actionMessage($status){
		if ($status=='t') {
			$condition = 'update_time='.date('Y-m-d',time()).' and confirm=0';
			Yii::$app->session->setFlash('date_message',date('Y-m-d',time()));
		}else if ($status=='h') {
			$condition = 'update_time!='.date('Y-m-d',time()).' and confirm=0';
			Yii::$app->session->setFlash('date_message','历史');
		}else{
			$condition = '';
			Yii::$app->session->setFlash('date_message','全部');
		}
		$message = FarmMessage::find()
		->select('mid,farm_id,product_id,MAX(forage) AS forage,MAX(feed_time) AS feed_time,MAX(kill_time) AS kill_time,MAX(log) AS log,feed,update_time')
		->with(['product'=>function($query){
			$query->select(['id','species_id','dorm','name']);
		}])->where($condition)
		->groupBy('product_id')
		->orderBy('mid desc')
		->asArray()
		->all();

		foreach ($message as $key => $value) {
			$message[$key]['species'] = Species::findOne($value['product']['species_id'])->name;
		}
        $this->layout = 'layout2';
        return $this->render('message',['message'=>$message]);
	}

	public function actionToresult($id){
		$id = (int)$id;
		$Product = Product::find()
		->select(['id','species_id','name','dorm'])
		->with('species')
		->where(['id'=>$id])
		->asArray()
		->one();

		$this->layout = 'layout2';
		return $this->render('result',['product'=>$Product]);
	}

	public function actionResult($id){
		$id = (int)$id;

		$FarmResult = FarmResult::find()->where(['product_id'=>$id])->one();
		if (is_null($FarmResult)) {
			$FarmResult = new FarmResult;
		}
		$Product = Product::findOne($id);

		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$post['product_id'] = $id;
			$post['farm_id'] = Yii::$app->session['farm_user']['user_id'];

			$update_status = $FarmResult->updateResult($post);

			if ($update_status['code'] == 0) {
				$Product->output = $post['output'];
				$Product->status = 4;
				$Product->save();
				return $this->redirect('list');
			}else{
				Yii::$app->session->setFlash('result','修改失败');
				return $this->redirect(['result','id'=>$id]);
			}
		}

	}
    
    public function actionTobatch(){
    	if (Yii::$app->request->isPost) {
    		$post = Yii::$app->request->post();
    		$ids = '('.implode(',', $post['select']).')';
            
    		$data = Product::find()
    		        ->with(['species','param'=>function($query){
    		        	$query->orderBy('id desc');
    		        }])
    		        ->where('id In '.$ids)
    		        ->asArray()
    		        ->all();
    		foreach ($data as $key => $value) {
    			$data[$key]['now_weight'] = $value['param'][0]['now_weight'];
    			$data[$key]['food_intake'] = $value['param'][0]['food_intake'];
    			$data[$key]['sleep'] = $value['param'][0]['sleep'];
    			$data[$key]['fat_ratio'] = $value['param'][0]['fat_ratio'];
    			$data[$key]['activity'] = $value['param'][0]['activity'];
    		}
    		unset($data['param']);
    		$this->layout = 'layout2';
    		return $this->render('batch',['data'=>$data]);
    	}
    }

	public function actionBatch(){

		$post = Yii::$app->request->post();
		$time = str_replace('/', '-', $post['update_time']);
		$time = strtotime($post['update_time']);

		foreach ($post['info'] as $key => $value) {
			$data[$key]['product_id'] = $value['id'];
			$data[$key]['food_intake'] = $value['food_intake'];
			$data[$key]['activity'] = $value['activity'];
			$data[$key]['sleep'] = $value['sleep'];
			$data[$key]['fat_ratio'] = $value['fat_ratio'];
			$data[$key]['now_weight'] = $value['now_weight'];
			$data[$key]['update_time'] = $time;
		}
        

		$rs = Yii::$app->db->createCommand()
			             ->batchInsert(ProductParam::tableName(),['product_id','food_intake','activity','sleep','fat_ratio','now_weight','update_time'],$data)
			             ->execute();

		if ($rs) {
			Yii::$app->session->setFlash('status','修改成功');
			return $this->redirect('list');
		}else{
			Yii::$app->session->setFlash('status','修改失败');
			return $this->redirect('list');
		}

		//       $now_weight = $food_intake = $activity = $sleep = $fat_ratio = $update_time = '';
  //       $ids = [];
	 //    foreach ($post['info'] as $key => $value) {
	 //    	$now_weight .= sprintf("WHEN %d THEN '%s' ", $value['id'], $value['now_weight']);
	 //    	$food_intake .= sprintf("WHEN %d THEN '%s' ", $value['id'], $value['food_intake']);
	 //    	$activity .= sprintf("WHEN %d THEN '%s' ", $value['id'], $value['activity']);
	 //    	$sleep .= sprintf("WHEN %d THEN '%s' ", $value['id'], $value['sleep']);
	 //    	$fat_ratio .= sprintf("WHEN %d THEN '%s' ", $value['id'], $value['fat_ratio']);
	 //    	$update_time .= sprintf("WHEN %d THEN '%s' ", $value['id'], $time);
	 //    	$ids[]= $value['id'];
	 //    }
        
  //       $ids = implode(',', $ids);
		// $sql = 'UPDATE '.ProductParam::tableName().' SET ';
		// $sql.= 'now_weight = CASE product_id '.$now_weight.'END, ';
		// $sql.= 'food_intake = CASE product_id '.$food_intake.'END, ';
		// $sql.= 'activity = CASE product_id '.$activity.'END, ';
		// $sql.= 'sleep = CASE product_id '.$sleep.'END, ';
		// $sql.= 'fat_ratio = CASE product_id '.$fat_ratio.'END, ';
		// $sql.= 'update_time = CASE product_id '.$update_time.'END ';
		// $sql.= 'WHERE product_id IN ('.$ids.')';

	}

	public function actionAssigndorm($id){
		$id = (int)$id;
		$user_id = Yii::$app->session['farm_user']['user_id'];

		if (Yii::$app->request->isPost) {
			$post = Yii::$app->request->post();
			$Product = Product::findOne($id);
			$Product->dorm = $post['dorm_id'];
			if ($Product->save()) {
				return $this->redirect(['list']);
			}else{
				return $this->redirect(['list']);
			}
		}
		$Dorm = Dorm::find()->where(['farm_id'=>$user_id])->asArray()->all();

		$this->layout = 'layout2';
		return $this->render('assigndorm',['dorm'=>$Dorm,'product_id'=>$id]);
	}
}