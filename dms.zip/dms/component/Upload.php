<?php 

namespace app\component;

use crazyfd\qiniu\Qiniu;

/**
* 
*/
class Upload
{

	const AK = 'C1TMsgCZd50QiAnTq7i-3LFj5RnDbFfgVCSLDLZV';
    const SK = 'WMebdPN1pzZsjqz2i5OkIkvRaN2iJTD50Y7aSL-Q';
    const DOMAIN = 'oho3gx15s.bkt.clouddn.com';
    const BUCKET = 'dms-resource';
	
	public function uploadPic(){
		if ($_FILES['file']['error'] > 0) {
			return false;
		}
		$qiniu = new Qiniu(self::AK, self::SK, self::DOMAIN, self::BUCKET);
		$key = uniqid();
        $qiniu->uploadFile($_FILES['file']['tmp_name'], $key);
        $img_url = $qiniu->getLink($key);

        return $img_url;
	}

	public function delPic($link){
		$qiniu = new Qiniu(self::AK, self::SK, self::DOMAIN, self::BUCKET);
        $qiniu->delete(basename($link));
	}
}