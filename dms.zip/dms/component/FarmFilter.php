<?php
namespace app\component;
use Yii;
use yii\base\Action;
use yii\base\ActionFilter;
use yii\helpers\Url;
class FarmFilter extends ActionFilter
{
    //在action之前运行，可用来过滤输入
    public function beforeAction($action) {
    	if (isset(Yii::$app->session['farm_user'])) {
            return true;
        }else{
        	$url = Yii::$app->request->hostInfo.'/b_login/tologin';
            return Yii::$app->getResponse()->redirect(Url::to($url), 302);
        }
    }
    //在action之后运行，可用来过滤输出
    public function afterAction($action, $result) {
        return $result;
    }
}