<?php
namespace app\component;
use Yii;
use yii\base\Action;
use yii\base\ActionFilter;
use yii\helpers\Url;
class FontFilter extends ActionFilter
{
    //在action之前运行，可用来过滤输入
    public function beforeAction($action) {
    	if (isset(Yii::$app->session['font_user'])) {
            return true;
        }else{
            Yii::$app->session['returnUrl'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        	$url = Yii::$app->request->hostInfo.'/c_login/tologin';
            return Yii::$app->getResponse()->redirect(Url::to($url), 302);
        }
    }
    //在action之后运行，可用来过滤输出
    public function afterAction($action, $result) {
        return $result;
    }
}