<?php
namespace app\component;
use Yii;
use yii\base\Action;
use yii\base\ActionFilter;
use yii\helpers\Url;
class AdminFilter extends ActionFilter
{
    //在action之前运行，可用来过滤输入
    public function beforeAction($action) {
    	if (isset(Yii::$app->session['admin'])) {
            return true;
        }else{
        	// echo '{"code":2}';
            return true;
        }
    }
    //在action之后运行，可用来过滤输出
    public function afterAction($action, $result) {
        return $result;
    }
}