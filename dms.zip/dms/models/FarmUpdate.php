<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\FarmUser;

/**
* 
*/
class FarmUpdate extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%farm_update}}";
	}

	public function rules(){
		return [
		    ['farm_id','safe'],
            ['name','safe'],
            ['cellphone','safe'],
            ['email','safe'],
            ['id_number','safe'],
            ['farm_name','safe'],
            ['area_id','safe'],
            ['detail_place','safe'],
		];
	}

	public function getFarm(){
          return $this->hasOne(FarmUser::className(),['id'=>'farm_id']);
	}
	
}