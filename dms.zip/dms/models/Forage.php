<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\ForageType;
use app\models\ForageOffer;

/**
* 
*/
class Forage extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%forage}}";
	}

	public function rules(){
		return [
           ['type_id','required','message'=>'饲料类别id不能为空'],
           ['product_id','required','message'=>'产品id不能为空'],
           ['farm_id','required','message'=>'养殖户id不能为空']
		];
	}

	public function getForage(){
		return $this->hasOne(ForageType::className(),['id'=>'type_id']);
	}
	
}