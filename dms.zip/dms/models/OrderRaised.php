<?php

namespace app\models;

use yii\db\ActiveRecord;
use app\models\Setmeal;

class OrderRaised extends ActiveRecord
{
    public function rules()
    {
        return [
            [['setmeal_id', 'price', 'order_id', 'createtime'],'required'],
        ];
    }

    public static function tableName()
    {
        return "{{%order_raised}}";
    }

    public function add($data)
    {
        if ($this->load($data,'') && $this->save()) {
            return ['code'=>0];
        }
        return ['code'=>1,'data'=>$this->getErrors()];
    }

    public function getSetmeal(){
        return $this->hasOne(Setmeal::className(),['id'=>'setmeal_id']);
    }



}
