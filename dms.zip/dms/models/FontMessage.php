<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\Product;

/**
* 
*/
class FontMessage extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%font_message}}";
	}

	public function getProduct(){
		return $this->hasOne(Product::className(),['id'=>'product_id']);
	}
	
}