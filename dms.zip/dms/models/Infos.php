<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
* 
*/
class Infos extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%infos}}";
	}
	
}