<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
* 
*/
class Area extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%area}}";
	}
	
}