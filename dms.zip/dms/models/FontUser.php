<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
* 
*/
class FontUser extends ActiveRecord
{
	public static $sid = '654adee37b23176e6bc069383595d131';
	public static $token = 'c61dfffaab33a55b228d9408a7e506fe';
	public static $appId = '44f164e32fcc4620a3d5de325db5e5c1';
    public static $url = 'https://api.ucpaas.com/2014-06-30/Accounts/';
    public static $templateId1 = 37383;
    public static $templateId2 = 37385;

	public static function tableName(){
		return "{{%font_user}}";
	}

	public function rules(){
		return [
            ['username','required','message'=>'用户名账号不能为空','on'=>['login']],
            ['password','required','message'=>'用户名密码不能为空','on'=>['login']],
            ['nickname','safe','on'=>['edit']],
            ['head_url','safe'],
            ['password','validatePass','on'=>['login']],
		];
	}
	

	public function validatePass(){
		if (!$this->hasErrors()) {
			$data = self::find()
			        ->where('username = :username and password = :password',[":username"=>$this->username,":password"=>md5($this->password)])
			        ->one();

			if (is_null($data)) {
				$this->addError('password','用户名或密码错误');
			}else{
				$this->id = $data->id;
				$this->head_url = $data->head_url;
			}
		};

	}

	public function login($data){
		$this->scenario = "login";
		if ($this->load($data,'') && $this->validate()) {
			 return ['code'=>0,'data'=>['head_url'=>$this->head_url,'user_id'=>$this->id]];
		}else{
			 return ['code'=>1,'data'=>$this->getErrors()];
		}
	}

	static public function encrypt($string,$operation,$key=''){
		$key=md5($key);
	    $key_length=strlen($key);
	    $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
	    $string_length=strlen($string);
	    $rndkey=$box=array();
	    $result='';
	    for($i=0;$i<=255;$i++){
	        $rndkey[$i]=ord($key[$i%$key_length]);
	        $box[$i]=$i;
	    }
	    for($j=$i=0;$i<256;$i++){
	        $j=($j+$box[$i]+$rndkey[$i])%256;
	        $tmp=$box[$i];
	        $box[$i]=$box[$j];
	        $box[$j]=$tmp;
	    }
	    for($a=$j=$i=0;$i<$string_length;$i++){
	        $a=($a+1)%256;
	        $j=($j+$box[$a])%256;
	        $tmp=$box[$a];
	        $box[$a]=$box[$j];
	        $box[$j]=$tmp;
	        $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
	    }
	    if($operation=='D'){
	        if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8)){
	            return substr($result,8);
	        }else{
	            return'';
	        }
	    }else{
	        return str_replace('=','',base64_encode($result));
	    }
	}
}