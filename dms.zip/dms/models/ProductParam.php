<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
* 
*/
class ProductParam extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%product_param}}";
	}
	
}