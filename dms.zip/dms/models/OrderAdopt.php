<?php

namespace app\models;

use yii\db\ActiveRecord;
use app\models\ForageType;

class OrderAdopt extends ActiveRecord
{
    public function rules()
    {
        return [
            // [['forage_id', 'start_time','end_time', 'order_id'],'required'],
        ];
    }

    public static function tableName()
    {
        return "{{%order_adopt}}";
    }

    public function getForage(){
        return $this->hasOne(ForageType::className(),['id'=>'forage_id']);
    }

    public function add($data)
    {
        if ($this->load($data,'') && $this->save()) {
            return ['code'=>0];
        }
        return ['code'=>1,'data'=>$this->getErrors()];
    }



}
