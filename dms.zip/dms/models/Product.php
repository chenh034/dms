<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\Species;
use app\models\ForageType;
use app\models\Setmeal;
use app\models\FarmMessage;
use app\models\FarmResult;
use app\models\FarmUser;
use app\models\Order;
use app\models\Dorm;
use app\models\ProductParam;

/**
* 
*/
class Product extends ActiveRecord
{   
	const AK = 'C1TMsgCZd50QiAnTq7i-3LFj5RnDbFfgVCSLDLZV';
    const SK = 'WMebdPN1pzZsjqz2i5OkIkvRaN2iJTD50Y7aSL-Q';
    const DOMAIN = 'oho3gx15s.bkt.clouddn.com';
    const BUCKET = 'dms-resource';
	
	public static function tableName(){
		return "{{%product}}";
	}

	public function rules(){
		return [
           ['farm_id','required','message'=>'所属养殖户不能为空','on'=>['add_1','add_2']],
           ['name','required','message'=>'编号不能为空','on'=>['add_1','add_2']],
           ['birthday','required','message'=>'出生日期不能为空','on'=>['add_1','add_2']],
           ['species_id','required','message'=>'所属物种不能为空','on'=>['add_1','add_2']],
           ['forage_id','required','message'=>'饲料不能为空','on'=>['add_1','add_2']],
           ['foundation_weight','required','message'=>'当前体重不能为空','on'=>['add_1','add_2']],
           ['pre_weight','required','message'=>'预计出肉不能为空','on'=>['add_1','add_2']],
           ['now_weight','safe'],
           ['type','required','message'=>'产品种类不能为空','on'=>['add_1','add_2']],
           ['foundation_price','required','message'=>'定价不能为空','on'=>['add_1']],
           ['feed_price','required','message'=>'养殖费用不能为空','on'=>['add_1']],
           ['introduce','required','message'=>'介绍不能为空','on'=>['add_1','add_2']],
           ['img_url','required','message'=>'图片不能为空','on'=>['add_1','add_2']],
           ['feed_time','required','message'=>'养殖时间不能为空','on'=>['add_1','add_2']],
           ['start_time','safe'],
           ['end_time','safe'],
           ['setmeal_info','safe','message'=>'套餐介绍不能为空','on'=>['add_2']],
           ['dorm','required','message'=>'猪舍不能为空','on'=>['assign_dorm']],
           ['advice','safe'],
           ['update_time','safe'],
           ['output','safe'],
           ['rate','safe'],
           ['status','safe'],
           ['is_ok','safe'],
		];
	}

	public function getSpecies(){
		return $this->hasOne(Species::className(),['id'=>'species_id']);
	}

	public function getSetmeal(){
		return $this->hasMany(Setmeal::className(),['product_id'=>'id']);
	}

	public function getMessage(){
		return $this->hasMany(FarmMessage::className(),['product_id'=>'id']);
	}
	public function getForage(){
		return $this->hasOne(ForageType::className(),['id'=>'forage_id']);
	}

	public function getResult(){
		return $this->hasOne(FarmResult::className(),['product_id'=>'id']);
	}

	public function getFarm(){
		return $this->hasOne(FarmUser::className(),['id'=>'farm_id']);
	}

	public function getUser(){
		return $this->hasMany(Order::className(),['product_id'=>'id']);
	}

	public function getDorm(){
		return $this->hasOne(Dorm::className(),['id'=>'dorm']);
	}

	public function getParam(){
		return $this->hasMany(ProductParam::className(),['product_id'=>'id']);
	}

	public function addProduct($data){
		if ($data['type'] == 1) {
		    $this->scenario = "add_1";			
		}else if ($data['type'] == 2) {
			$this->scenario = "add_2";
		}
		if ($this->load($data,'')) {
			$this->update_time = time();
			if ($this->save()) {
				$ProductParam = new ProductParam;
				$ProductParam->product_id = $this->id;
				$ProductParam->now_weight = $data['foundation_weight'];
				$ProductParam->update_time = time();
				$ProductParam->save();
				return ['code'=>0,'data'=>['product_id'=>$this->id]];
			}else{
				return ['code'=>1,'data'=>$this->getErrors()];
			}
		}
	}

	public function editProduct($data){
		if ($data['type'] == 1) {
		    $this->scenario = "add_1";			
		}else if ($data['type'] == 2) {
			$this->scenario = "add_2";
		}
		if ($this->load($data,'')) {
			$this->update_time = time();
			if ($this->save()) {
				return ['code'=>0,'data'=>['product_id'=>$this->id]];
			}else{
				return ['code'=>1,'data'=>$this->getErrors()];
			}
		}
	}

	public function updateInfo($data){
		$ProductParam = new ProductParam;
		$ProductParam->product_id = $this->id;
		$ProductParam->update_time = strtotime($data['update_time']);
		$ProductParam->food_intake = $data['food_intake'];
		$ProductParam->now_weight = $data['now_weight'];
		$ProductParam->activity = $data['activity'];
		$ProductParam->sleep = $data['sleep'];
		$ProductParam->fat_ratio = $data['fat_ratio'];
	    if ($ProductParam->save()) {
	    	return ['code'=>0];
	    }else{
	    	return ['code'=>1,'data'=>$ProductParam->getErrors()];
	    }
	}
	
}