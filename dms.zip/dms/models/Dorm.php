<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\Product;

/**
* 
*/
class Dorm extends ActiveRecord
{
	const appKey = '62455a1ee1c44c0698210595fff43ccf';
	const appSecret = '1ffd8e8ec7dca0347bb8d973bbb764bc';
	
	public static function tableName(){
		return "{{%dorm}}";
	}

	
}