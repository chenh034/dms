<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
* 
*/
class IndexImg extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%index_img}}";
	}

	public function rules(){
		return [
           ['title','safe'],
           ['target','safe'],
           ['img_url','required','message'=>'图片不能为空']
		];
	}

	public function add($data){
		if ($this->load($data,'')) {
			if ($this->save()) {
				return ['code'=>0];
			}else{
				return ['code'=>1,'data'=>$this->getErrors()];
			}
		}
	}

	public function edit($data){
		if ($this->load($data,'')) {
			if ($this->save()) {
				return ['code'=>0];
			}else{
				return ['code'=>1,'data'=>$this->getErrors()];
			}
		}
	}
	
}