<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use app\models\ForageType;

/**
* 
*/
class ForageOffer extends ActiveRecord
{
	
	public static function tableName(){
		return "{{%forage_offer}}";
	}

	public function getForage(){
          return $this->hasOne(ForageType::className(),['id'=>'forage_id']);
	}
	
}