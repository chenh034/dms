<?php
namespace app\models;

use app\models\Order;
use app\models\Product;
use app\models\OrderRaised;
use app\models\OrderAdopt;
use app\models\FarmMessage;
use app\AliPay\AlipayPay;

class Pay{
    public static function alipay($order_id)
    {
        $Order = Order::findOne($order_id);
        $amount = $Order->amount;
        if (!empty($amount)) {
            $alipay = new AlipayPay();
            $giftname = "典牧署";
            $Product = Product::findOne($Order->product_id);
            $body = $Product->species->name.'-'.$Product->name;

            $showUrl = "http://www.i-great.cn";
            $html = $alipay->requestPay($order_id, $giftname, $amount, $body, $showUrl);
            echo $html;
        }

    }

    public static function alipay1($order_id){
        // 
        $data['out_trade_no'] = $order_id;
        $data['trade_status'] = 'TRADE_SUCCESS';
        $data['trade_no'] = '2016122821001004270214943070';
        // $result = self::notify_test($data);
        $result = self::notify($data);
        return $result;
    }

    public static function alipay_f($product_id,$new_forage_id,$new_forage,$pay_price)
    {
        $amount = 0.01;
        if (!empty($amount)) {
            $alipay = new AlipayPay();
            $order_id = time().'1'.'/'.$product_id.'/'.$new_forage_id;
            $giftname = "典牧署";
            $body = '饲料更改为-'.$new_forage;

            $showUrl = "http://60.205.189.30";
            $html = $alipay->requestPay($order_id, $giftname, $amount, $body, $showUrl);
            echo $html;
        }

    }

    public static function alipay2($product_id,$new_forage_id,$new_forage,$pay_price){
        // 
        $data['out_trade_no'] = time().'1'.'/'.$product_id.'/'.$new_forage_id;
        $data['trade_status'] = 'TRADE_SUCCESS';
        $data['trade_no'] = '2016122821001004270214943070';
        // $result = self::notify_test($data);
        $result = self::notify($data);
        return $result;
    }

    public static function alipay_t($product_id,$feed_time,$pay_price)
    {
        $amount = 0.01;
        if (!empty($amount)) {
            $alipay = new AlipayPay();
            $order_id = time().'2'.'/'.$product_id.'/'.$feed_time;
            $giftname = "典牧署";
            $body = '养殖时间更改至-'.$feed_time;

            $showUrl = "http://60.205.189.30";
            $html = $alipay->requestPay($order_id, $giftname, $amount, $body, $showUrl);
            echo $html;
        }

    }

    public static function alipay3($product_id,$feed_time,$pay_price){
        // 
        $data['out_trade_no'] = time().'2'.'/'.$product_id.'/'.$feed_time;
        $data['trade_status'] = 'TRADE_SUCCESS';
        $data['trade_no'] = '2016122821001004270214943070';
        // $result = self::notify_test($data);
        $result = self::notify($data);
        return $result;
    }

    public static function notify_test($data){
        $out_trade_no = $data['out_trade_no'];
        $trade_no = $data['trade_no'];
        $trade_status = $data['trade_status'];
        $status = Order::PAYFAILED;
        if ($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
            if (strlen($out_trade_no)>10) {
                $out = substr($out_trade_no, 10);
                $out_arr = explode('/', $out);
                $type = $out_arr[0];
                if ($type==1) {
                    $product_id = $out_arr[1];
                    $forage_id = $out_arr[2];
                    $Product = Product::findOne($product_id);
                    $FarmMessage = new FarmMessage;
                    $FarmMessage->product_id = $product_id;
                    $FarmMessage->farm_id = $Product->farm_id;
                    $FarmMessage->forage = ForageType::findOne($forage_id)->name;
                    $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                    $FarmMessage->save();
                }else if ($type==2) {
                    $product_id = $out_arr[1];
                    $feed_time = $out_arr[2];
                    $Product = Product::findOne($product_id);
                    $FarmMessage = new FarmMessage;
                    $FarmMessage->product_id = $product_id;
                    $FarmMessage->farm_id = $Product->farm_id;
                    $FarmMessage->feed_time = $feed_time;
                    $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                    $FarmMessage->save();
                }
                
            }else{
                $status = Order::PAYSUCCESS;
                $Order = Order::find()->where('id = :oid', [':oid' => $out_trade_no])->one();
                if (!$Order) {
                    return false;
                }
                if ($Order->status == Order::CHECKORDER) {
                    Order::updateAll(['status' => $status, 'tradeno' => $trade_no, 'tradeext' => json_encode($data)], 'id = :oid', [':oid' => $Order->id]);
                    if ($Order->product_type==1) {
                        $Detail = OrderAdopt::find()->where(['order_id'=>$Order->id])->one();
                        $Product = Product::findOne($Order->product_id);
                        $Product->feed_time = $Product->feed_time+$Detail->time_add;
                        $Product->all_price = $Product->foundation_price+$Product->feed_price*$Detail->time_add;
                        // $Product->start_time = $Detail->start_time;
                        // $Product->end_time = $Detail->end_time;
                        // $Product->forage_id = $Detail->forage_id;
                        $Product->status = 2;
                        $Product->save();

                        $FarmMessage = new FarmMessage;
                        $FarmMessage->product_id = $Order->product_id;
                        $FarmMessage->farm_id = $Product->farm_id;
                        $FarmMessage->feed = 1;
                        $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                        $FarmMessage->save();

                    }else if ($Order->product_type==2) {
                        $rate_plus = 0;
                        $setmeal_total = Setmeal::find()->where(['product_id'=>$Order->product_id])->count();
                        $setmeals = OrderRaised::find()->where(['order_id'=>$Order->id])->asArray()->all();
                        foreach ($setmeals as $key => $value) {
                            $rate_plus+=1;
                            $model = Setmeal::findOne($value['setmeal_id']);
                            $model->buy = 1;
                            $model->save();
                        }
                        $Product = Product::findOne($Order->product_id);
                        $Product->rate +=$rate_plus;
                        if ($Product->rate>=$setmeal_total) {
                            $Product->status = 2;
                        }
                        $Product->save();

                        $FarmMessage = new FarmMessage;
                        $FarmMessage->product_id = $Order->product_id;
                        $FarmMessage->farm_id = $Product->farm_id;
                        $FarmMessage->feed = 1;
                        $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                        $FarmMessage->save();
                    }
                } else {
                    return false;
                }
            }
        }
        return true;
    }


    public static function notify($data)
    {
        $alipay = new AlipayPay();
        $verify_result = $alipay->verifyNotify();
        if ($verify_result) {
            $out_trade_no = $data['out_trade_no'];
            $trade_no = $data['trade_no'];
            $trade_status = $data['trade_status'];
            $status = Order::PAYFAILED;
            if ($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
                if (strlen($out_trade_no)>10) {
                    $out = substr($out_trade_no, 10);
                    $out_arr = explode('/', $out);
                    $type = $out_arr[0];
                    if ($type==1) {
                        $product_id = $out_arr[1];
                        $forage_id = $out_arr[2];
                        $Product = Product::findOne($product_id);
                        $FarmMessage = new FarmMessage;
                        $FarmMessage->product_id = $product_id;
                        $FarmMessage->farm_id = $Product->farm_id;
                        $FarmMessage->forage = ForageType::findOne($forage_id)->name;
                        $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                        $FarmMessage->save();
                    }else if ($type==2) {
                        $product_id = $out_arr[1];
                        $feed_time = $out_arr[2];
                        $Product = Product::findOne($product_id);
                        $FarmMessage = new FarmMessage;
                        $FarmMessage->product_id = $product_id;
                        $FarmMessage->farm_id = $Product->farm_id;
                        $FarmMessage->feed_time = $feed_time;
                        $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                        $FarmMessage->save();
                    }
                    
                }else{
                    $status = Order::PAYSUCCESS;
                    $Order = Order::find()->where('id = :oid', [':oid' => $out_trade_no])->one();
                    if (!$Order) {
                        return false;
                    }
                    if ($Order->status == Order::CHECKORDER) {
                        Order::updateAll(['status' => $status, 'tradeno' => $trade_no, 'tradeext' => json_encode($data)], 'id = :oid', [':oid' => $Order->id]);
                        if ($Order->product_type==1) {
                            $Detail = OrderAdopt::find()->where(['order_id'=>$Order->id])->one();
                            $Product = Product::findOne($Order->product_id);
                            $Product->feed_time = $Product->feed_time+$Detail->time_add;
                            $Product->all_price = $Product->foundation_price+$Product->feed_price*$Detail->time_add;
                            // $Product->start_time = $Detail->start_time;
                            // $Product->end_time = $Detail->end_time;
                            // $Product->forage_id = $Detail->forage_id;
                            $Product->status = 2;
                            $Product->save();

                            $FarmMessage = new FarmMessage;
                            $FarmMessage->product_id = $Order->product_id;
                            $FarmMessage->farm_id = $Product->farm_id;
                            $FarmMessage->feed = 1;
                            $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                            $FarmMessage->save();

                        }else if ($Order->product_type==2) {
                            $rate_plus = 0;
                            $setmeal_total = Setmeal::find()->where(['product_id'=>$Order->product_id])->count();
                            $setmeals = OrderRaised::find()->where(['order_id'=>$Order->id])->asArray()->all();
                            foreach ($setmeals as $key => $value) {
                                $rate_plus+=1;
                                $model = Setmeal::findOne($value['setmeal_id']);
                                $model->buy = 1;
                                $model->save();
                            }
                            $Product = Product::findOne($Order->product_id);
                            $Product->rate +=$rate_plus;
                            if ($Product->rate>=$setmeal_total) {
                                $Product->status = 2;
                            }
                            $Product->save();

                            $FarmMessage = new FarmMessage;
                            $FarmMessage->product_id = $Order->product_id;
                            $FarmMessage->farm_id = $Product->farm_id;
                            $FarmMessage->feed = 1;
                            $FarmMessage->update_time = date('Y-m-d H:i:s',time());
                            $FarmMessage->save();
                        }
                    } else {
                        return false;
                    }
                }
            }
            return true;
        } else {
            return false;
        }
    }






}
